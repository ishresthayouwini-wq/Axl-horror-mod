#version 150

uniform sampler2D DiffuseSampler;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec3 c = texture(DiffuseSampler, texCoord).rgb;
    float g = dot(c, vec3(0.299, 0.587, 0.114));        // black and white
    g = clamp((g - 0.5) * 1.2 + 0.5, 0.0, 1.0);          // a little extra contrast
    fragColor = vec4(vec3(g), 1.0);
}
