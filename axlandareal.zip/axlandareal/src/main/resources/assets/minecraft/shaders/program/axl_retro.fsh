#version 150

uniform sampler2D DiffuseSampler;
uniform vec2 OutSize;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    // snap to blocks so the picture is about 240 lines tall, whatever the screen size
    float block = floor(max(2.0, OutSize.y / 240.0));
    vec2 grid = OutSize / block;
    vec2 uv = (floor(texCoord * grid) + 0.5) / grid;

    vec3 c = texture(DiffuseSampler, uv).rgb;
    c = floor(c * 5.0 + 0.5) / 5.0;                      // limited palette: 6 levels per colour
    c = c * vec3(1.0, 0.62, 0.62) + vec3(0.07, 0.0, 0.0); // blood-red cast
    float line = mod(floor(gl_FragCoord.y / block), 2.0);
    c *= 1.0 - 0.12 * line;                              // faint CRT scanlines
    fragColor = vec4(c, 1.0);
}
