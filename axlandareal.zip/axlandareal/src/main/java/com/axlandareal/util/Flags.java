package com.axlandareal.util;

import com.axlandareal.AxlAndAReal;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** "Only once per player" markers, stored in the player's saved data and kept through death. */
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID)
public final class Flags {
    public static final String NIGHTMARE = "axlandareal_nightmare_done";
    public static final String MSG_HOUSE = "axlandareal_msg_house";
    public static final String MSG_BUILD = "axlandareal_msg_build";
    public static final String LORE_GIVEN = "axlandareal_lore_given";
    private static final String[] ALL = {NIGHTMARE, MSG_HOUSE, MSG_BUILD, LORE_GIVEN};

    private Flags() {}

    public static boolean has(Player p, String key) {
        return p.getPersistentData().getBoolean(key);
    }

    public static void set(Player p, String key) {
        p.getPersistentData().putBoolean(key, true);
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        for (String k : ALL) {
            if (has(e.getOriginal(), k)) set(e.getEntity(), k);
        }
    }
}
