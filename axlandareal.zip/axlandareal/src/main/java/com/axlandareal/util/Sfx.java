package com.axlandareal.util;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

/** Plays a sound to ONE player only (other players hear nothing). */
public final class Sfx {
    private Sfx() {}

    public static boolean online(ServerPlayer p) {
        return p.getServer() != null && p.getServer().getPlayerList().getPlayer(p.getUUID()) == p;
    }

    public static void playAt(ServerPlayer p, SoundEvent sound, SoundSource source,
                              double x, double y, double z, float volume, float pitch) {
        if (!online(p)) return;
        Holder<SoundEvent> holder = BuiltInRegistries.SOUND_EVENT.wrapAsHolder(sound);
        p.connection.send(new ClientboundSoundPacket(holder, source, x, y, z, volume, pitch, p.getRandom().nextLong()));
    }

    public static void playToSelf(ServerPlayer p, SoundEvent sound, SoundSource source, float volume, float pitch) {
        playAt(p, sound, source, p.getX(), p.getY(), p.getZ(), volume, pitch);
    }
}
