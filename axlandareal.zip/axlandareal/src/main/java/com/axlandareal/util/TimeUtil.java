package com.axlandareal.util;

import net.minecraft.world.level.Level;

public final class TimeUtil {
    private TimeUtil() {}

    /** Daytime only exists in the Overworld; every other dimension counts as "night". */
    public static boolean isDay(Level level) {
        return level.dimension() == Level.OVERWORLD && level.isDay();
    }
}
