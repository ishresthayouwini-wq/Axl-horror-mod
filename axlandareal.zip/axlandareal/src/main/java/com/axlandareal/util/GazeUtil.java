package com.axlandareal.util;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** "Is the player looking at it?" helpers. Alignment is cos(angle between view ray and target). */
public final class GazeUtil {
    /** ~57 degrees off-centre: roughly the edge of a normal FOV. */
    public static final double IN_VIEW = 0.55D;
    /** ~14 degrees off-centre: staring straight at it. */
    public static final double DIRECT = 0.97D;

    private GazeUtil() {}

    public static double alignment(Player viewer, Entity target) {
        Vec3 look = viewer.getViewVector(1.0F).normalize();
        Vec3 to = target.getBoundingBox().getCenter().subtract(viewer.getEyePosition()).normalize();
        return look.dot(to);
    }

    /** On screen (or nearly) and not hidden behind terrain. */
    public static boolean inView(Player viewer, Entity target) {
        return alignment(viewer, target) > IN_VIEW && viewer.hasLineOfSight(target);
    }

    public static boolean directGaze(Player viewer, Entity target) {
        return alignment(viewer, target) > DIRECT && viewer.hasLineOfSight(target);
    }
}
