package com.axlandareal.network;

import com.axlandareal.client.ClientHauntHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: "show this scare". Text is only used by the RED_TEXT types. */
public record HauntPacket(Type type, String text) {

    public enum Type {
        RED_TEXT, RED_TEXT_CHAT,
        JUMPSCARE_HELP, JUMPSCARE_STEVE,
        FAKE_WEBCAM, FAKE_MALWARE, FAKE_TAUNT, FAKE_CRASH,
        CAMERA_LOCK, CAMERA_UNLOCK, AXL_FACE,
        RETRO, RED_WATER, HEAVY_FOG, ENVIRONMENT, ENVIRONMENT_RETRO, CONTROLLED, CONTROL_END,
        HALLUCINATION_RUSH, HALLUCINATION_EYES, HALLUCINATION_STARE
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeEnum(type);
        buf.writeUtf(text, 128);
    }

    public static HauntPacket decode(FriendlyByteBuf buf) {
        return new HauntPacket(buf.readEnum(Type.class), buf.readUtf(128));
    }

    public static void handle(HauntPacket msg, Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHauntHandler.handle(msg));
        ctx.get().setPacketHandled(true);
    }
}
