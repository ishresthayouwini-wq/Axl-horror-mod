package com.axlandareal.network;

import com.axlandareal.AxlAndAReal;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(AxlAndAReal.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private ModNetwork() {}

    public static void register() {
        CHANNEL.messageBuilder(HauntPacket.class, 0, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(HauntPacket::encode)
                .decoder(HauntPacket::decode)
                .consumerMainThread(HauntPacket::handle)
                .add();
    }

    public static void sendTo(ServerPlayer player, HauntPacket packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }
}
