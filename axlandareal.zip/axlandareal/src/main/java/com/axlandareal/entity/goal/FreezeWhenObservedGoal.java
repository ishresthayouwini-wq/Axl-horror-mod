package com.axlandareal.entity.goal;

import com.axlandareal.entity.AbstractHauntEntity;
import com.axlandareal.util.GazeUtil;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/** Highest-priority goal: the instant the victim looks, stop dead and stare back. */
public class FreezeWhenObservedGoal extends Goal {
    private final AbstractHauntEntity mob;
    private int stareTicks;

    public FreezeWhenObservedGoal(AbstractHauntEntity mob) {
        this.mob = mob;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }

    @Override
    public boolean canUse() {
        ServerPlayer p = mob.getHauntTarget();
        return p != null && GazeUtil.inView(p, mob);
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        stareTicks = 0;
        mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        ServerPlayer p = mob.getHauntTarget();
        if (p == null) return;
        mob.getNavigation().stop();
        mob.setDeltaMovement(0.0D, mob.getDeltaMovement().y, 0.0D);
        mob.getLookControl().setLookAt(p, 30.0F, 30.0F);
        if (++stareTicks >= mob.getStareThreshold()) {
            stareTicks = 0;
            mob.onStaredAt(p);
        }
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }
}
