package com.axlandareal.entity;

import com.axlandareal.entity.goal.FreezeWhenObservedGoal;
import com.axlandareal.entity.goal.StalkAtDistanceGoal;
import com.axlandareal.network.HauntPacket;
import com.axlandareal.registry.ModSounds;
import com.axlandareal.world.HauntDirector;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.level.Level;

/**
 * Tall Steve: a Weeping-Angel. Fast when unobserved, motionless when watched.
 * Looking at him for one second, or letting him reach 5 blocks, triggers the
 * blackout + face jumpscare (subject to the safety check in HauntDirector).
 */
public class TallSteveEntity extends AbstractHauntEntity {
    private int moanTicks = 100;

    public TallSteveEntity(EntityType<? extends TallSteveEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new FreezeWhenObservedGoal(this));
        goalSelector.addGoal(2, new StalkAtDistanceGoal(this, 4.0D, 4.0D, 1.5D));
    }

    @Override
    public int getStareThreshold() {
        return 20;
    }

    @Override
    public void onStaredAt(ServerPlayer viewer) {
        HauntDirector.tryJumpscare(viewer, HauntPacket.Type.JUMPSCARE_STEVE, false);
        vanish(false);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (isRemoved()) return;
        ServerPlayer p = getHauntTarget();
        if (p == null) return;

        if (distanceToSqr(p) < 25.0D) {
            onStaredAt(p);
            return;
        }
        if (--moanTicks <= 0) {
            moanTicks = 200 + random.nextInt(200);
            level().playSound(null, blockPosition(), ModSounds.STATIC_BURST.get(), SoundSource.HOSTILE, 1.5F, 0.5F);
        }
    }
}
