package com.axlandareal.entity;

import com.axlandareal.entity.goal.FreezeWhenObservedGoal;
import com.axlandareal.entity.goal.MirrorPlayerGoal;
import com.axlandareal.entity.goal.StalkAtDistanceGoal;
import com.axlandareal.network.HauntPacket;
import com.axlandareal.network.ModNetwork;
import com.axlandareal.world.HauntDirector;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.level.Level;

/**
 * Axl: keeps his distance, creeps closer when unobserved, alternates between
 * "stalk" and "mirror" phases, and fires small psychological events nearby.
 * Stare at him too long (or hit him) and he's gone.
 */
public class AxlEntity extends AbstractHauntEntity {
    private boolean mirroring;
    private int phaseTicks = 400;
    private int eventTicks = 600;

    public AxlEntity(EntityType<? extends AxlEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new FreezeWhenObservedGoal(this));
        goalSelector.addGoal(2, new MirrorPlayerGoal(this));
        goalSelector.addGoal(3, new StalkAtDistanceGoal(this, 16.0D, 6.0D, 1.1D));
    }

    public boolean isMirroring() {
        return mirroring;
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        ServerPlayer p = getHauntTarget();
        if (p == null || isRemoved()) return;

        if (--phaseTicks <= 0) {
            mirroring = !mirroring;
            phaseTicks = mirroring ? 300 + random.nextInt(300) : 600 + random.nextInt(600);
        }
        if (--eventTicks <= 0 && distanceToSqr(p) < 48.0D * 48.0D) {
            eventTicks = 500 + random.nextInt(600);
            HauntDirector.fireMinor(p);
        }
    }

    @Override
    public int getStareThreshold() {
        return 50; // 2.5s of eye contact
    }

    @Override
    public void onStaredAt(ServerPlayer viewer) {
        if (distanceToSqr(viewer) < 12.0D * 12.0D) {
            HauntDirector.tryJumpscare(viewer, HauntPacket.Type.JUMPSCARE_HELP, false);
        } else {
            HauntDirector.sendRedText(viewer);
        }
        vanish(true);
    }

    @Override
    protected void onAttackedByPlayer(ServerPlayer attacker) {
        ModNetwork.sendTo(attacker, new HauntPacket(HauntPacket.Type.RED_TEXT_CHAT, "Help me Abreal this is not a joke"));
        vanish(true);
    }
}
