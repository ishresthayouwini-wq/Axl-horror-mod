package com.axlandareal.entity;

import com.axlandareal.network.HauntPacket;
import com.axlandareal.network.ModNetwork;
import com.axlandareal.util.GazeUtil;
import com.axlandareal.world.HauntDirector;
import com.axlandareal.world.TickScheduler;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * The mining ambush. Axl simply stands there until the victim has SEEN him; then the
 * moment they move, place a block, or look away, the trap springs:
 *   LOCK   - camera locks on him, he snaps into a T-pose
 *   ASCEND - he shoots straight up through the ceiling
 *   DIVE   - he comes back down at the player very fast
 *   -> client shows the Axl face + scream, then the video, then a distorted sound.
 */
public class AxlAmbushEntity extends AbstractHauntEntity {
    private enum Stage { WATCH, LOCK, ASCEND, DIVE }

    private Stage stage = Stage.WATCH;
    private int stageTicks;
    private int watchTicks;
    private int seenTicks;
    private boolean seenOnce;
    private boolean placedBlock;
    private Vec3 baseline = Vec3.ZERO;

    public AxlAmbushEntity(EntityType<? extends AxlAmbushEntity> type, Level level) {
        super(type, level);
    }

    @Override
    public int getStareThreshold() {
        return Integer.MAX_VALUE; // no stare goal on this entity
    }

    @Override
    public void onStaredAt(ServerPlayer viewer) {
        // unused: the ambush has its own state machine
    }

    /** Called by the block-place event. Only counts after the victim has seen him. */
    public void notifyPlaced() {
        if (seenOnce) placedBlock = true;
    }

    @Override
    protected void onAttackedByPlayer(ServerPlayer attacker) {
        if (stage == Stage.WATCH) startLock(attacker);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        ServerPlayer p = getHauntTarget();
        if (p == null || isRemoved()) return;

        switch (stage) {
            case WATCH -> {
                getLookControl().setLookAt(p, 60.0F, 60.0F);
                watchTicks++;
                boolean inView = GazeUtil.inView(p, this);
                if (!seenOnce) {
                    if (inView && ++seenTicks >= 12) {
                        seenOnce = true;
                        baseline = p.position();
                    } else if (watchTicks > 20 * 30) {
                        vanish(false); // never noticed him
                    }
                } else {
                    boolean moved = p.position().subtract(baseline).horizontalDistanceSqr() > 0.09D;
                    if (moved || placedBlock || !inView) startLock(p);
                }
            }
            case LOCK -> {
                setDeltaMovement(Vec3.ZERO);
                if (++stageTicks >= 36) {
                    stage = Stage.ASCEND;
                    stageTicks = 0;
                    this.noPhysics = true;
                    setNoGravity(true);
                }
            }
            case ASCEND -> {
                this.noPhysics = true;
                setDeltaMovement(0.0D, 0.9D, 0.0D);
                if (++stageTicks >= 24) {
                    stage = Stage.DIVE;
                    stageTicks = 0;
                }
            }
            case DIVE -> {
                this.noPhysics = true;
                Vec3 mid = position().add(0.0D, getBbHeight() / 2.0D, 0.0D);
                Vec3 toPlayer = p.getEyePosition().subtract(mid);
                if (toPlayer.length() < 2.0D || ++stageTicks > 60) {
                    finish(p);
                } else {
                    setDeltaMovement(toPlayer.normalize().scale(2.6D));
                }
            }
        }
    }

    private void startLock(ServerPlayer p) {
        stage = Stage.LOCK;
        stageTicks = 0;
        setTPose(true);
        ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.CAMERA_LOCK, Integer.toString(getId())));
        // safety net: the client always gets an unlock, even if this entity is removed early
        TickScheduler.schedule(140, () -> ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.CAMERA_UNLOCK, "")));
    }

    private void finish(ServerPlayer p) {
        ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.AXL_FACE, ""));
        ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.CAMERA_UNLOCK, ""));
        HauntDirector.markJumpscare(p);
        vanish(false);
    }
}
