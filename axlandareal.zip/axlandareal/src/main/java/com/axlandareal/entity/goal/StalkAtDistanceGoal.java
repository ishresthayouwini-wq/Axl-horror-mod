package com.axlandareal.entity.goal;

import com.axlandareal.entity.AbstractHauntEntity;
import com.axlandareal.util.GazeUtil;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/**
 * Weeping-Angel style approach: only moves while the victim is NOT looking.
 * It holds at startDist, then creeps closer by 1 block every 2 seconds
 * down to floorDist.
 */
public class StalkAtDistanceGoal extends Goal {
    private final AbstractHauntEntity mob;
    private final double startDist, floorDist, speed;
    private int creepTicks, repathTicks;

    public StalkAtDistanceGoal(AbstractHauntEntity mob, double startDist, double floorDist, double speed) {
        this.mob = mob;
        this.startDist = startDist;
        this.floorDist = floorDist;
        this.speed = speed;
        setFlags(EnumSet.of(Flag.MOVE));
    }

    private double holdDistance() {
        return Math.max(floorDist, startDist - creepTicks / 40.0D);
    }

    @Override
    public boolean canUse() {
        if (!mob.wantsToApproach()) return false;
        ServerPlayer p = mob.getHauntTarget();
        return p != null && !GazeUtil.inView(p, mob) && mob.distanceTo(p) > holdDistance();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void tick() {
        ServerPlayer p = mob.getHauntTarget();
        if (p == null) return;
        creepTicks++;
        if (--repathTicks <= 0) {
            repathTicks = 8;
            double pace = speed * mob.getSpeedScale();
            if (pace < 0.05D) mob.getNavigation().stop();   // the clone stands still when the original does
            else mob.getNavigation().moveTo(p, pace);
        }
    }

    @Override
    public void stop() {
        mob.getNavigation().stop();
    }
}
