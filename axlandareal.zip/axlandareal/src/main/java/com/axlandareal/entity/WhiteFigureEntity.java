package com.axlandareal.entity;

import com.axlandareal.world.Symptoms;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Weakness + nearby farm animals silently disappear (sometimes lava floats in the air). */
public class WhiteFigureEntity extends FigureEntity {
    public WhiteFigureEntity(EntityType<? extends WhiteFigureEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void haunt(ServerPlayer victim) {
        victim.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 20 * 20, 1, false, false, false));
        Symptoms.vanishLivestock(victim);
        if (random.nextFloat() < 0.25F) Symptoms.floatingLava(victim);
    }
}
