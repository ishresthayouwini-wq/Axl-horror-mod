package com.axlandareal.entity;

import com.axlandareal.util.TimeUtil;
import com.axlandareal.world.Symptoms;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Nearby farm animals silently disappear (sometimes lava floats in the air). */
public class WhiteFigureEntity extends FigureEntity {
    public WhiteFigureEntity(EntityType<? extends WhiteFigureEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected boolean canExistNow() {
        return TimeUtil.isDay(level());
    }

    @Override
    protected void haunt(ServerPlayer victim) {
        Symptoms.vanishLivestock(victim);
        if (random.nextFloat() < 0.25F) Symptoms.floatingLava(victim);
    }
}
