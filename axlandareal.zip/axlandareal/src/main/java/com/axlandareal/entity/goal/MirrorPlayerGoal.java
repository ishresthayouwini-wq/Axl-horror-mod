package com.axlandareal.entity.goal;

import com.axlandareal.entity.AxlEntity;
import com.axlandareal.util.GazeUtil;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * While unobserved, Axl copies the victim: opposite horizontal movement, jumps,
 * sneaking, sprinting, arm swings, and a flipped facing direction.
 * Uses position deltas because a ServerPlayer's deltaMovement is unreliable.
 */
public class MirrorPlayerGoal extends Goal {
    private final AxlEntity mob;
    private Vec3 lastPlayerPos;

    public MirrorPlayerGoal(AxlEntity mob) {
        this.mob = mob;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (!mob.isMirroring()) return false;
        ServerPlayer p = mob.getHauntTarget();
        return p != null && mob.distanceTo(p) < 48.0F && !GazeUtil.inView(p, mob);
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        mob.getNavigation().stop();
        ServerPlayer p = mob.getHauntTarget();
        lastPlayerPos = p != null ? p.position() : null;
    }

    @Override
    public void tick() {
        ServerPlayer p = mob.getHauntTarget();
        if (p == null || lastPlayerPos == null) return;

        Vec3 now = p.position();
        Vec3 delta = now.subtract(lastPlayerPos);
        lastPlayerPos = now;

        double vy = mob.getDeltaMovement().y;
        if (delta.y > 0.2D && mob.onGround()) vy = 0.42D; // mirrored jump
        mob.setDeltaMovement(-delta.x, vy, -delta.z);

        float yaw = p.getYRot() + 180.0F;
        mob.setYRot(yaw);
        mob.yBodyRot = yaw;
        mob.yHeadRot = yaw;
        mob.setXRot(-p.getXRot());

        mob.setShiftKeyDown(p.isShiftKeyDown());
        mob.setSprinting(p.isSprinting());
        if (p.swinging && !mob.swinging) mob.swing(InteractionHand.MAIN_HAND);
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }
}
