package com.axlandareal.entity;

import com.axlandareal.entity.goal.FreezeWhenObservedGoal;
import com.axlandareal.entity.goal.StalkAtDistanceGoal;
import com.axlandareal.world.Symptoms;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Axl's multiplayer trick. Copies one player (the "original"): skin, name, armor, held items, pace, sneaking,
 * sprinting and arm swings, and repeats what the original says in chat as a whisper to the victim.
 * It walks toward a DIFFERENT player (the "victim"): Player1's clone only ever goes to Player2, 3 or 4,
 * never to Player1. It only exists while the two are far apart.
 */
public class PlayerCloneEntity extends AbstractHauntEntity {
    /** If the original and the victim come closer than this, the illusion is over. */
    private static final float REUNITED_DISTANCE = 32.0F;
    private static final EquipmentSlot[] GEAR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET,
            EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND};

    private static final EntityDataAccessor<Optional<UUID>> DATA_CLONE_OF =
            SynchedEntityData.defineId(PlayerCloneEntity.class, EntityDataSerializers.OPTIONAL_UUID);

    /** Clones that are alive right now (the chat handler needs to find them). */
    private static final Set<PlayerCloneEntity> ACTIVE = new HashSet<>();

    private String cloneName = "";
    private int ticks;
    private double speedScale = 1.0D;
    private Vec3 lastSample = Vec3.ZERO;
    private boolean sampled;

    public PlayerCloneEntity(EntityType<? extends PlayerCloneEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_CLONE_OF, Optional.empty());
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new FreezeWhenObservedGoal(this));
        goalSelector.addGoal(2, new StalkAtDistanceGoal(this, 14.0D, 5.0D, 1.0D));
    }

    /** Whose skin this wears (read on the client by the renderer). */
    public Optional<UUID> getCloneOf() {
        return this.entityData.get(DATA_CLONE_OF);
    }

    public String getCloneName() {
        return cloneName;
    }

    /** Snapshot of the living clones, safe to loop over. */
    public static List<PlayerCloneEntity> active() {
        ACTIVE.removeIf(c -> c.isRemoved() || !c.isAlive());
        return new ArrayList<>(ACTIVE);
    }

    /**
     * Copy 'original'. Refuses, and removes itself, if the original IS the victim, so a player can never be
     * sent their own clone.
     */
    public boolean setCloneOf(ServerPlayer original, ServerPlayer victim) {
        if (original.getUUID().equals(victim.getUUID())) {
            discard();
            return false;
        }
        setHauntTarget(victim);
        this.entityData.set(DATA_CLONE_OF, Optional.of(original.getUUID()));
        this.cloneName = original.getGameProfile().getName();
        setCustomName(Component.literal(cloneName));
        setCustomNameVisible(true);
        copyGear(original);
        ACTIVE.add(this);
        return true;
    }

    private void copyGear(ServerPlayer original) {
        for (EquipmentSlot slot : GEAR) {
            ItemStack theirs = original.getItemBySlot(slot);
            if (!ItemStack.matches(getItemBySlot(slot), theirs)) setItemSlot(slot, theirs.copy());
            setDropChance(slot, 0.0F);
        }
    }

    /** Strict: only the assigned victim, never "whoever is nearest" (that could be the original). */
    @Nullable
    @Override
    public ServerPlayer getHauntTarget() {
        UUID id = getTargetId();
        if (level().isClientSide || id == null) return null;
        Player p = level().getPlayerByUUID(id);
        return p instanceof ServerPlayer sp && !sp.isSpectator() ? sp : null;
    }

    /** How fast to walk: the original's pace (0 = the original is standing still, so the clone stops too). */
    @Override
    public double getSpeedScale() {
        return speedScale;
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (isRemoved() || ++ticks % 5 != 0) return;

        ServerPlayer victim = getHauntTarget();
        UUID originalId = getCloneOf().orElse(null);
        MinecraftServer server = ((ServerLevel) level()).getServer();
        ServerPlayer original = originalId == null ? null : server.getPlayerList().getPlayer(originalId);

        if (victim == null || original == null || original == victim
                || original.level() != victim.level()
                || original.distanceTo(victim) < REUNITED_DISTANCE) {
            vanish(false);
            return;
        }

        // copy the original's movement: pace (walk 4.3 blocks/s = 1.0), sneaking, sprinting, arm swings
        Vec3 pos = original.position();
        if (!sampled) {
            sampled = true;
            lastSample = pos;
        }
        double blocksPerSecond = pos.subtract(lastSample).horizontalDistance() * 4.0D;   // sampled every 0.25 s
        lastSample = pos;
        speedScale = Mth.clamp(blocksPerSecond / 4.3D, 0.0D, 1.6D);

        setShiftKeyDown(original.isShiftKeyDown());
        setSprinting(original.isSprinting());
        if (original.swinging && !this.swinging) swing(InteractionHand.MAIN_HAND);

        copyGear(original);   // follows armor / item changes
    }

    @Override
    public int getStareThreshold() {
        return 60; // 3 seconds of staring
    }

    @Override
    public void onStaredAt(ServerPlayer viewer) {
        Symptoms.whisperFrom(viewer, cloneName, "Your friend " + cloneName + " is going to betray you");
        vanish(true);
    }
}
