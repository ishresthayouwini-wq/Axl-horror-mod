package com.axlandareal.entity;

import com.axlandareal.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * Shared base for every haunt entity: invulnerable, silent, bound to one "victim"
 * player, and despawns itself. Subclasses define what happens when the victim
 * keeps it in view long enough (onStaredAt).
 *
 * GOTCHA: Mob's constructor calls registerGoals() before subclass fields are
 * initialised, so goals must read subclass state lazily (wantsToApproach(), etc.).
 */
public abstract class AbstractHauntEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> DATA_TPOSE =
            SynchedEntityData.defineId(AbstractHauntEntity.class, EntityDataSerializers.BOOLEAN);

    @Nullable
    private UUID targetId;
    protected int lifetime;

    protected AbstractHauntEntity(EntityType<? extends AbstractHauntEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
        this.setPersistenceRequired();
        this.setInvulnerable(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.FOLLOW_RANGE, 96.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    /** Ticks the victim must keep this entity in view before onStaredAt fires. */
    public abstract int getStareThreshold();

    public abstract void onStaredAt(ServerPlayer viewer);

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_TPOSE, false);
    }

    public boolean isTPose() {
        return this.entityData.get(DATA_TPOSE);
    }

    public void setTPose(boolean value) {
        this.entityData.set(DATA_TPOSE, value);
    }

    /** Day/night restrictions: when this turns false the entity quietly disappears. */
    protected boolean canExistNow() {
        return true;
    }

    /** Whether the stalk goal may walk this entity toward the victim. */
    public boolean wantsToApproach() {
        return true;
    }

    protected int getMaxLifetime() {
        return 20 * 60 * 4;
    }

    protected void onAttackedByPlayer(ServerPlayer attacker) {
        vanish(true);
    }

    /** Multiplier for how fast this entity walks toward its victim (the clone copies another player's pace). */
    public double getSpeedScale() {
        return 1.0D;
    }

    @Nullable
    protected UUID getTargetId() {
        return targetId;
    }

    public void setHauntTarget(Player player) {
        this.targetId = player.getUUID();
    }

    @Nullable
    public ServerPlayer getHauntTarget() {
        if (level().isClientSide) return null;
        if (targetId != null && level().getPlayerByUUID(targetId) instanceof ServerPlayer sp && !sp.isSpectator()) {
            return sp;
        }
        return level().getNearestPlayer(this, 96.0D) instanceof ServerPlayer near ? near : null;
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        lifetime++;
        ServerPlayer target = getHauntTarget();
        if (target == null || lifetime > getMaxLifetime() || distanceToSqr(target) > 128.0D * 128.0D || !canExistNow()) {
            vanish(false);
        }
    }

    public void vanish(boolean withEffects) {
        if (withEffects && level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + getBbHeight() / 2, getZ(),
                    25, 0.3D, getBbHeight() / 3.0D, 0.3D, 0.02D);
            sl.playSound(null, blockPosition(), ModSounds.STATIC_BURST.get(), SoundSource.HOSTILE,
                    0.8F, 0.7F + random.nextFloat() * 0.4F);
        }
        discard();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        // /kill and the void still work; players just make it flinch away.
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        if (source.getEntity() instanceof ServerPlayer sp) onAttackedByPlayer(sp);
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return false;
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return null;
    }
}
