package com.axlandareal.entity;

import com.axlandareal.entity.goal.FreezeWhenObservedGoal;
import com.axlandareal.entity.goal.StalkAtDistanceGoal;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.level.Level;

/**
 * Base for the Black/White Figures. They spawn in the victim's peripheral vision.
 * Passive figures simply vanish (with their curse) when finally looked at.
 * Active figures (35%) also creep up while unobserved and curse you at 3 blocks.
 */
public abstract class FigureEntity extends AbstractHauntEntity {
    private final boolean active;

    protected FigureEntity(EntityType<? extends FigureEntity> type, Level level) {
        super(type, level);
        this.active = level.random.nextFloat() < 0.35F;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new FreezeWhenObservedGoal(this));
        goalSelector.addGoal(2, new StalkAtDistanceGoal(this, 3.0D, 2.0D, 1.0D));
    }

    @Override
    public boolean wantsToApproach() {
        return active; // read lazily: field isn't set yet when registerGoals() runs
    }

    /** The effect / anomaly this figure inflicts. */
    protected abstract void haunt(ServerPlayer victim);

    @Override
    public int getStareThreshold() {
        return 10; // half a second
    }

    @Override
    public void onStaredAt(ServerPlayer viewer) {
        haunt(viewer);
        vanish(true);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (isRemoved() || !active) return;
        ServerPlayer p = getHauntTarget();
        if (p != null && distanceToSqr(p) < 9.0D) onStaredAt(p);
    }
}
