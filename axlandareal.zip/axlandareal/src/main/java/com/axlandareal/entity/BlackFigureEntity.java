package com.axlandareal.entity;

import com.axlandareal.util.TimeUtil;
import com.axlandareal.world.Symptoms;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** The player's hands stop cooperating for 45 s (blocked break/place/use). */
public class BlackFigureEntity extends FigureEntity {
    public BlackFigureEntity(EntityType<? extends BlackFigureEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected boolean canExistNow() {
        return !TimeUtil.isDay(level());
    }

    @Override
    protected void haunt(ServerPlayer victim) {
        Symptoms.applyInterference(victim, 20 * 45);
    }
}
