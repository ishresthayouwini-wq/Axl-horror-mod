package com.axlandareal.entity;

import com.axlandareal.world.Symptoms;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Blindness + the player's hands stop cooperating (blocked break/place/use). */
public class BlackFigureEntity extends FigureEntity {
    public BlackFigureEntity(EntityType<? extends BlackFigureEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void haunt(ServerPlayer victim) {
        // ambient=false, visible=false, showIcon=false -> no particles, no HUD icon
        victim.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 20 * 10, 0, false, false, false));
        Symptoms.applyInterference(victim, 20 * 45);
    }
}
