package com.axlandareal;

import com.axlandareal.config.AxlConfig;
import com.axlandareal.network.ModNetwork;
import com.axlandareal.registry.ModBlocks;
import com.axlandareal.registry.ModEntities;
import com.axlandareal.registry.ModItems;
import com.axlandareal.registry.ModSounds;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * Entry point. Every other @Mod.EventBusSubscriber class in this project
 * (HauntDirector, SymptomEvents, AxlCommand, ModBusEvents, ClientModEvents)
 * is auto-registered by Forge, so nothing else needs wiring here.
 */
@Mod(AxlAndAReal.MODID)
public class AxlAndAReal {
    public static final String MODID = "axlandareal";
    public static final Logger LOGGER = LogUtils.getLogger();

    public AxlAndAReal() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModBlocks.BLOCKS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModSounds.SOUNDS.register(modBus);

        ModNetwork.register();

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, AxlConfig.COMMON_SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, AxlConfig.CLIENT_SPEC);
    }
}
