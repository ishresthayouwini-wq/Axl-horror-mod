package com.axlandareal.config;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

public class AxlConfig {
    public static final ForgeConfigSpec COMMON_SPEC;
    public static final Common COMMON;
    public static final ForgeConfigSpec CLIENT_SPEC;
    public static final Client CLIENT;

    static {
        Pair<Common, ForgeConfigSpec> c = new ForgeConfigSpec.Builder().configure(Common::new);
        COMMON = c.getLeft();
        COMMON_SPEC = c.getRight();
        Pair<Client, ForgeConfigSpec> cl = new ForgeConfigSpec.Builder().configure(Client::new);
        CLIENT = cl.getLeft();
        CLIENT_SPEC = cl.getRight();
    }

    /** Server-side: what the haunting is allowed to do to the world. */
    public static class Common {
        public final ForgeConfigSpec.IntValue minEventSeconds, maxEventSeconds, jumpscareCooldownSeconds, environmentSeconds, retroEnvironmentSeconds, cloneMinDistance, controlledSeconds;
        public final ForgeConfigSpec.BooleanValue signs, whispers, brickWalls, anomalies, entities, kickAfterTallSteve, controlledHurtsPlayers;

        Common(ForgeConfigSpec.Builder b) {
            b.push("haunting");
            minEventSeconds = b.comment("Minimum seconds between haunt events, per player")
                    .defineInRange("minEventSeconds", 45, 10, 36000);
            maxEventSeconds = b.comment("Maximum seconds between haunt events, per player")
                    .defineInRange("maxEventSeconds", 150, 10, 36000);
            jumpscareCooldownSeconds = b.comment("Minimum seconds between full-screen jumpscares, per player")
                    .defineInRange("jumpscareCooldownSeconds", 600, 0, 86400);
            environmentSeconds = b.comment("How long the black-and-white environment change lasts (1.27 minutes = 76 s)")
                    .defineInRange("environmentSeconds", 76, 10, 600);
            retroEnvironmentSeconds = b.comment("How long the retro environment change lasts")
                    .defineInRange("retroEnvironmentSeconds", 32, 10, 600);
            cloneMinDistance = b.comment("Multiplayer: a clone of one player only appears for another player at least this many blocks away from the original")
                    .defineInRange("cloneMinDistance", 64, 16, 1000);
            controlledSeconds = b.comment("How long the \"controlled\" symptom lasts")
                    .defineInRange("controlledSeconds", 50, 10, 600);
            controlledHurtsPlayers = b.comment("The controlled player attacks everything, including other players. False = players are spared")
                    .define("controlledHurtsPlayers", true);
            signs = b.define("signs", true);
            whispers = b.define("whispers", true);
            brickWalls = b.define("brickWalls", true);
            anomalies = b.comment("Missing livestock, floating lava, interaction interference")
                    .define("anomalies", true);
            entities = b.comment("Allow Axl / Figures / Tall Steve to be spawned by the director")
                    .define("entities", true);
            kickAfterTallSteve = b.comment("Kick the player (\"mod is trying to hack your Internet\") after the Tall Steve jumpscare")
                    .define("kickAfterTallSteve", true);
            b.pop();
        }
    }

    /** Client-side comfort settings. Each player controls their own scares. */
    public static class Client {
        public final ForgeConfigSpec.BooleanValue jumpscares, fakeAlerts, floatingText, reduceFlashing, visualEffects, scareVideo, permanentFog, redMenu, scaryMenu;
        public final ForgeConfigSpec.IntValue fogDistance;

        Client(ForgeConfigSpec.Builder b) {
            b.push("comfort");
            jumpscares = b.comment("Full-screen jumpscares (red overlay, blackout + Tall Steve)")
                    .define("jumpscares", true);
            fakeAlerts = b.comment("Fake in-game alert/crash screens (purely cosmetic)")
                    .define("fakeAlerts", true);
            floatingText = b.define("floatingText", true);
            reduceFlashing = b.comment("Removes flicker, shake and scanlines from every effect")
                    .define("reduceFlashing", false);
            visualEffects = b.comment("Retro graphics, red water and hallucinations")
                    .define("visualEffects", true);
            permanentFog = b.comment("Heavy fog all the time, everywhere, even with no entity nearby")
                    .define("permanentFog", true);
            fogDistance = b.comment("How far you can see in the permanent fog (blocks). Lower = thicker")
                    .defineInRange("fogDistance", 36, 12, 96);
            scaryMenu = b.comment("Scary title screen: moving fog, watching eyes, blood, flickers, whispers, a rare flash, creepy ambience instead of the menu music")
                    .define("scaryMenu", true);
            redMenu = b.comment("Menu buttons turn red when the pointer is on them")
                    .define("redMenu", true);
            scareVideo = b.comment("The video played during the Axl ambush")
                    .define("scareVideo", true);
            b.pop();
        }
    }
}
