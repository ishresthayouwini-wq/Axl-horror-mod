package com.axlandareal.config;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

public class AxlConfig {
    public static final ForgeConfigSpec COMMON_SPEC;
    public static final Common COMMON;
    public static final ForgeConfigSpec CLIENT_SPEC;
    public static final Client CLIENT;

    static {
        Pair<Common, ForgeConfigSpec> c = new ForgeConfigSpec.Builder().configure(Common::new);
        COMMON = c.getLeft();
        COMMON_SPEC = c.getRight();
        Pair<Client, ForgeConfigSpec> cl = new ForgeConfigSpec.Builder().configure(Client::new);
        CLIENT = cl.getLeft();
        CLIENT_SPEC = cl.getRight();
    }

    /** Server-side: what the haunting is allowed to do to the world. */
    public static class Common {
        public final ForgeConfigSpec.IntValue minEventSeconds, maxEventSeconds, jumpscareCooldownSeconds;
        public final ForgeConfigSpec.BooleanValue signs, whispers, brickWalls, anomalies, entities;

        Common(ForgeConfigSpec.Builder b) {
            b.push("haunting");
            minEventSeconds = b.comment("Minimum seconds between haunt events, per player")
                    .defineInRange("minEventSeconds", 120, 10, 36000);
            maxEventSeconds = b.comment("Maximum seconds between haunt events, per player")
                    .defineInRange("maxEventSeconds", 420, 10, 36000);
            jumpscareCooldownSeconds = b.comment("Minimum seconds between full-screen jumpscares, per player")
                    .defineInRange("jumpscareCooldownSeconds", 600, 0, 86400);
            signs = b.define("signs", true);
            whispers = b.define("whispers", true);
            brickWalls = b.define("brickWalls", true);
            anomalies = b.comment("Missing livestock, floating lava, interaction interference")
                    .define("anomalies", true);
            entities = b.comment("Allow Axl / Figures / Tall Steve to be spawned by the director")
                    .define("entities", true);
            b.pop();
        }
    }

    /** Client-side comfort settings. Each player controls their own scares. */
    public static class Client {
        public final ForgeConfigSpec.BooleanValue jumpscares, fakeAlerts, floatingText, reduceFlashing;

        Client(ForgeConfigSpec.Builder b) {
            b.push("comfort");
            jumpscares = b.comment("Full-screen jumpscares (red overlay, blackout + Tall Steve)")
                    .define("jumpscares", true);
            fakeAlerts = b.comment("Fake in-game alert/crash screens (purely cosmetic)")
                    .define("fakeAlerts", true);
            floatingText = b.define("floatingText", true);
            reduceFlashing = b.comment("Removes flicker, shake and scanlines from every effect")
                    .define("reduceFlashing", false);
            b.pop();
        }
    }
}
