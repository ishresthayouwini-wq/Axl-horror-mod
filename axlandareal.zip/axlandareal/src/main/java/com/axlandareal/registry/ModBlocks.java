package com.axlandareal.registry;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.block.FloatingLavaBlock;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, AxlAndAReal.MODID);

    /** Lava-looking block that never flows and removes itself. No BlockItem on purpose. */
    public static final RegistryObject<Block> FLOATING_LAVA = BLOCKS.register("floating_lava", FloatingLavaBlock::new);

    private ModBlocks() {}
}
