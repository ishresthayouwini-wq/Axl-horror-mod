package com.axlandareal.registry;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.entity.AbstractHauntEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModBusEvents {
    private ModBusEvents() {}

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.AXL.get(), AbstractHauntEntity.createAttributes().build());
        e.put(ModEntities.PLAYER_CLONE.get(), AbstractHauntEntity.createAttributes().build());
        e.put(ModEntities.AXL_AMBUSH.get(), AbstractHauntEntity.createAttributes().build());
        e.put(ModEntities.BLACK_FIGURE.get(), AbstractHauntEntity.createAttributes().build());
        e.put(ModEntities.WHITE_FIGURE.get(), AbstractHauntEntity.createAttributes().build());
        e.put(ModEntities.TALL_STEVE.get(),
                AbstractHauntEntity.createAttributes().add(Attributes.MOVEMENT_SPEED, 0.4D).build());
    }

    @SubscribeEvent
    public static void creativeTabs(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            e.accept(ModItems.LORE_OF_AXL);
        }
        if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            e.accept(ModItems.AXL_SPAWN_EGG);
            e.accept(ModItems.BLACK_FIGURE_SPAWN_EGG);
            e.accept(ModItems.WHITE_FIGURE_SPAWN_EGG);
            e.accept(ModItems.TALL_STEVE_SPAWN_EGG);
        }
    }
}
