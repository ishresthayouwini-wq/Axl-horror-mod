package com.axlandareal.registry;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.entity.*;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AxlAndAReal.MODID);

    public static final RegistryObject<EntityType<AxlEntity>> AXL =
            reg("axl", AxlEntity::new, 0.6F, 1.8F);
    public static final RegistryObject<EntityType<PlayerCloneEntity>> PLAYER_CLONE =
            reg("player_clone", PlayerCloneEntity::new, 0.6F, 1.8F);
    public static final RegistryObject<EntityType<AxlAmbushEntity>> AXL_AMBUSH =
            reg("axl_ambush", AxlAmbushEntity::new, 0.6F, 1.8F);
    public static final RegistryObject<EntityType<BlackFigureEntity>> BLACK_FIGURE =
            reg("black_figure", BlackFigureEntity::new, 0.6F, 1.8F);
    public static final RegistryObject<EntityType<WhiteFigureEntity>> WHITE_FIGURE =
            reg("white_figure", WhiteFigureEntity::new, 0.6F, 1.8F);
    public static final RegistryObject<EntityType<TallSteveEntity>> TALL_STEVE =
            reg("tall_steve", TallSteveEntity::new, 0.8F, 3.8F);

    private ModEntities() {}

    private static <T extends AbstractHauntEntity> RegistryObject<EntityType<T>> reg(
            String name, EntityType.EntityFactory<T> factory, float w, float h) {
        return ENTITIES.register(name, () -> EntityType.Builder.of(factory, MobCategory.MONSTER)
                .sized(w, h)
                .clientTrackingRange(10)
                .fireImmune()
                .build(AxlAndAReal.MODID + ":" + name));
    }
}
