package com.axlandareal.registry;

import com.axlandareal.AxlAndAReal;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, AxlAndAReal.MODID);

    public static final RegistryObject<SoundEvent> TALL_STEVE_STING = reg("tall_steve_sting");
    public static final RegistryObject<SoundEvent> AXL_WHISPER = reg("axl_whisper");
    public static final RegistryObject<SoundEvent> STATIC_BURST = reg("static_burst");
    public static final RegistryObject<SoundEvent> AXL_SCREAM = reg("axl_scream");
    public static final RegistryObject<SoundEvent> HELP_STING = reg("help_sting");
    public static final RegistryObject<SoundEvent> DISTORTED = reg("distorted");
    public static final RegistryObject<SoundEvent> HEARTBEAT = reg("heartbeat");
    public static final RegistryObject<SoundEvent> ENV_AMBIENCE = reg("env_ambience");
    public static final RegistryObject<SoundEvent> RETRO_MUSIC = reg("retro_music");
    public static final RegistryObject<SoundEvent> MENU_AMBIENCE = reg("menu_ambience");
    public static final RegistryObject<SoundEvent> CONTROL_MUSIC = reg("control_music");
    public static final RegistryObject<SoundEvent> ENVIRONMENT_REVERSE = reg("environment_reverse");
    public static final RegistryObject<SoundEvent> NIGHTMARE_AMBIENCE = reg("nightmare_ambience");
    public static final RegistryObject<SoundEvent> SCARE_VIDEO_AUDIO = reg("scare_video_audio");

    private ModSounds() {}

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(AxlAndAReal.MODID, name)));
    }
}
