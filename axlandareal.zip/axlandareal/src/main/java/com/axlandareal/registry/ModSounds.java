package com.axlandareal.registry;

import com.axlandareal.AxlAndAReal;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, AxlAndAReal.MODID);

    public static final RegistryObject<SoundEvent> TALL_STEVE_STING = reg("tall_steve_sting");
    public static final RegistryObject<SoundEvent> AXL_WHISPER = reg("axl_whisper");
    public static final RegistryObject<SoundEvent> STATIC_BURST = reg("static_burst");

    private ModSounds() {}

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(AxlAndAReal.MODID, name)));
    }
}
