package com.axlandareal.registry;

import com.axlandareal.AxlAndAReal;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, AxlAndAReal.MODID);

    public static final RegistryObject<Item> AXL_SPAWN_EGG = ITEMS.register("axl_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.AXL, 0x111111, 0xAA0000, new Item.Properties()));
    public static final RegistryObject<Item> BLACK_FIGURE_SPAWN_EGG = ITEMS.register("black_figure_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.BLACK_FIGURE, 0x000000, 0x222222, new Item.Properties()));
    public static final RegistryObject<Item> WHITE_FIGURE_SPAWN_EGG = ITEMS.register("white_figure_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.WHITE_FIGURE, 0xFFFFFF, 0xBBBBBB, new Item.Properties()));
    public static final RegistryObject<Item> TALL_STEVE_SPAWN_EGG = ITEMS.register("tall_steve_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.TALL_STEVE, 0x00AAAA, 0x440000, new Item.Properties()));

    private ModItems() {}
}
