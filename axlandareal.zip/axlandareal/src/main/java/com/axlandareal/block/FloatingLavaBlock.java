package com.axlandareal.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;

/**
 * A "floating lava" illusion: lava texture, hurts on contact, never flows,
 * and deletes itself after ~40s so the haunting can't grief the world.
 */
public class FloatingLavaBlock extends Block {
    private static final int LIFETIME_TICKS = 20 * 40;

    public FloatingLavaBlock() {
        super(BlockBehaviour.Properties.of()
                .mapColor(MapColor.FIRE)
                .noCollission()
                .noOcclusion()
                .noLootTable()
                .strength(0.2F)
                .lightLevel(s -> 15)
                .pushReaction(PushReaction.DESTROY));
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moved) {
        if (!level.isClientSide) level.scheduleTick(pos, this, LIFETIME_TICKS);
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        level.removeBlock(pos, false);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!entity.fireImmune()) {
            entity.setSecondsOnFire(5);
            entity.hurt(level.damageSources().lava(), 4.0F);
        }
    }
}
