package com.axlandareal.item;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.registry.ModItems;
import com.axlandareal.util.Flags;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Hands every player one "Lore of Axl" the first time they join, and a fresh one after dying without it. */
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID)
public final class LoreGiver {
    private LoreGiver() {}

    public static void give(ServerPlayer p) {
        ItemStack stack = new ItemStack(ModItems.LORE_OF_AXL.get());
        if (!p.getInventory().add(stack)) p.drop(stack, false);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || Flags.has(p, Flags.LORE_GIVEN)) return;
        give(p);
        Flags.set(p, Flags.LORE_GIVEN);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.isEndConquered() || !(e.getEntity() instanceof ServerPlayer p)) return;
        if (!p.getInventory().contains(new ItemStack(ModItems.LORE_OF_AXL.get()))) give(p);
    }
}
