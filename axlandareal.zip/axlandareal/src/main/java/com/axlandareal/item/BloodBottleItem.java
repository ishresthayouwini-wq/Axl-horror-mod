package com.axlandareal.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** The "blood item" found in the gift chest. Does nothing, but it is still warm. */
public class BloodBottleItem extends Item {
    public BloodBottleItem() {
        super(new Item.Properties().stacksTo(16));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("It is still warm.").withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC));
    }
}
