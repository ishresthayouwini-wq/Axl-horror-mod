package com.axlandareal.world;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.entity.PlayerCloneEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;
import java.util.regex.Pattern;

/**
 * Chat behaviour of the clone (multiplayer):
 *  - whatever the ORIGINAL player says is repeated to the victim as a private whisper "<name> whispers to you: ...";
 *  - if the victim asks why it is whispering (any wording with "why"/"what"/"how come" and "whisper"), the
 *    clone whispers back "Because Axl can hear it".
 */
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID)
public final class CloneChat {
    private static final Pattern ASKS_WHY_WHISPER =
            Pattern.compile("(?i)\\b(why|how come|what)\\b.*whisp\\w*|whisp\\w*.*\\bwhy\\b");

    private CloneChat() {}

    @SubscribeEvent
    public static void onChat(ServerChatEvent e) {
        ServerPlayer sender = e.getPlayer();
        String text = e.getRawText();
        if (text == null || text.isBlank()) return;

        for (PlayerCloneEntity clone : PlayerCloneEntity.active()) {
            ServerPlayer victim = clone.getHauntTarget();
            if (victim == null) continue;
            UUID originalId = clone.getCloneOf().orElse(null);

            if (sender.getUUID().equals(originalId)) {
                // the clone "says" what the original says, but only as a whisper to the victim
                Symptoms.whisperFrom(victim, clone.getCloneName(), text);
            } else if (sender == victim && ASKS_WHY_WHISPER.matcher(text).find()) {
                String name = clone.getCloneName();
                TickScheduler.schedule(30, () -> Symptoms.whisperFrom(victim, name, "Because Axl can hear it"));
            }
        }
    }
}
