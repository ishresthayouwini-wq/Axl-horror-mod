package com.axlandareal.world;

public final class HauntTexts {
    private HauntTexts() {}

    public static final String[] RED_TEXTS = {
            "Kill me",
            "Kill your partner",
            "Why are you playing this",
            "Help me Abreal this is not a joke",
            "You assh*le"
    };

    public static final String[] SIGN_LINES = {
            "You are not safe",
            "Help Axl"
    };
}
