package com.axlandareal.world;

import com.axlandareal.entity.AxlAmbushEntity;
import com.axlandareal.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * "You are just mining and then Axl was there."
 * The director ARMS a player; the ambush then fires after they mine 3 blocks underground.
 */
public final class AxlAmbush {
    private static final Map<UUID, Long> ARMED_UNTIL = new HashMap<>();
    private static final Map<UUID, Integer> MINED = new HashMap<>();

    private AxlAmbush() {}

    private static long tick(ServerPlayer p) {
        return p.getServer() == null ? 0L : p.getServer().getTickCount();
    }

    public static boolean isArmed(ServerPlayer p) {
        Long until = ARMED_UNTIL.get(p.getUUID());
        return until != null && tick(p) < until;
    }

    public static void arm(ServerPlayer p) {
        ARMED_UNTIL.put(p.getUUID(), tick(p) + 20L * 60 * 10); // armed for 10 minutes
        MINED.put(p.getUUID(), 0);
    }

    public static void disarmAll() {
        ARMED_UNTIL.clear();
        MINED.clear();
    }

    public static void onMined(ServerPlayer p, BlockPos pos) {
        if (p.getServer() != null && HauntDirector.environmentActive(p.getServer())) return;   // nothing else during an environment change
        UUID id = p.getUUID();
        if (!isArmed(p)) {
            ARMED_UNTIL.remove(id);
            return;
        }
        if (p.serverLevel().canSeeSky(pos)) return; // surface digging doesn't count
        int n = MINED.merge(id, 1, Integer::sum);
        if (n >= 3) {
            MINED.put(id, 0);
            if (spawn(p)) {
                ARMED_UNTIL.remove(id);
                MINED.remove(id);
            }
        }
    }

    public static void onPlaced(ServerPlayer p) {
        for (AxlAmbushEntity a : p.serverLevel().getEntitiesOfClass(AxlAmbushEntity.class, p.getBoundingBox().inflate(40.0D))) {
            a.notifyPlaced();
        }
    }

    private static boolean spawn(ServerPlayer p) {
        if (!HauntDirector.jumpscareReady(p) || !HauntDirector.safeForScare(p)) return false;
        if (!p.serverLevel().getEntitiesOfClass(AxlAmbushEntity.class, p.getBoundingBox().inflate(64.0D)).isEmpty()) return false;
        return HauntSpawner.spawnInFront(p, ModEntities.AXL_AMBUSH.get(), 4, 9) != null;
    }
}
