package com.axlandareal.world;

import com.axlandareal.AxlAndAReal;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Watches what players do (mine / place) for the ambush trigger and the building whisper. */
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID)
public final class PlayerActivity {
    private PlayerActivity() {}

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (e.getPlayer() instanceof ServerPlayer sp) AxlAmbush.onMined(sp, e.getPos());
    }

    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            AxlAmbush.onPlaced(sp);
            Messages.onPlaced(sp);
        }
    }
}
