package com.axlandareal.world;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.world.HauntDirector.HauntEvent;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Arrays;
import java.util.Locale;

/** Debug helper: /axl fire <event> triggers any haunt event on yourself (op level 2). */
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID)
public final class AxlCommand {
    private AxlCommand() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("axl")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("fire")
                        .then(Commands.argument("event", StringArgumentType.word())
                                .suggests((ctx, b) -> SharedSuggestionProvider.suggest(
                                        Arrays.stream(HauntEvent.values()).map(v -> v.name().toLowerCase(Locale.ROOT)), b))
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    try {
                                        HauntDirector.fire(p, HauntEvent.valueOf(
                                                StringArgumentType.getString(ctx, "event").toUpperCase(Locale.ROOT)));
                                    } catch (IllegalArgumentException ex) {
                                        ctx.getSource().sendFailure(Component.literal("Unknown haunt event"));
                                        return 0;
                                    }
                                    return 1;
                                }))));
    }
}
