package com.axlandareal.world;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.registry.ModSounds;
import com.axlandareal.util.Flags;
import com.axlandareal.util.Sfx;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * One-time event per player: for 7 seconds they are moved into a blood-covered 7x7 room
 * high in the sky above their own position, with nausea and an ambient sting, then
 * returned to exactly where they stood. The room is erased afterwards.
 */
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID)
public final class NightmareRoom {
    private record Session(ServerPlayer player, ServerLevel level, double x, double y, double z,
                           float yRot, float xRot, boolean wasInvulnerable, int cx, int y0, int cz) {}

    private static final Map<UUID, Session> ACTIVE = new HashMap<>();
    private static final int FLAGS = 2 | 16;

    private NightmareRoom() {}

    public static boolean start(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        if (Flags.has(p, Flags.NIGHTMARE) || ACTIVE.containsKey(p.getUUID())) return false;
        if (level.dimension() != Level.OVERWORLD || p.getBlockY() > 270) return false;

        int cx = p.getBlockX();
        int cz = p.getBlockZ();
        int y0 = Math.min(level.getMaxBuildHeight() - 12, 290);

        // Whole 9x9x6 volume must be loaded and empty, or we skip (never overwrite builds).
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                if (!level.hasChunkAt(new BlockPos(cx + dx, y0, cz + dz))) return false;
                for (int dy = 0; dy <= 5; dy++) {
                    if (!level.getBlockState(new BlockPos(cx + dx, y0 + dy, cz + dz)).isAir()) return false;
                }
            }
        }

        build(level, cx, y0, cz);

        Session s = new Session(p, level, p.getX(), p.getY(), p.getZ(), p.getYRot(), p.getXRot(),
                p.isInvulnerable(), cx, y0, cz);
        ACTIVE.put(p.getUUID(), s);
        Flags.set(p, Flags.NIGHTMARE);

        p.setInvulnerable(true);
        p.teleportTo(level, cx + 0.5D, y0 + 1.0D, cz + 0.5D, p.getYRot(), 0.0F);
        p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 20 * 8, 0, false, false, false));
        Sfx.playToSelf(p, ModSounds.NIGHTMARE_AMBIENCE.get(), SoundSource.AMBIENT, 1.0F, 1.0F);

        UUID id = p.getUUID();
        TickScheduler.schedule(20 * 7, () -> end(id));
        return true;
    }

    private static void build(ServerLevel level, int cx, int y0, int cz) {
        RandomSource r = level.random;
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                for (int dy = 0; dy <= 5; dy++) {
                    boolean shell = Math.abs(dx) == 4 || Math.abs(dz) == 4 || dy == 0 || dy == 5;
                    if (!shell) continue;
                    BlockState st;
                    if (dy == 0) st = (r.nextInt(100) < 70 ? Blocks.RED_CONCRETE : Blocks.NETHER_WART_BLOCK).defaultBlockState();
                    else if (dy == 5) st = Blocks.BLACKSTONE.defaultBlockState();
                    else st = (r.nextInt(100) < 35 ? Blocks.NETHER_WART_BLOCK : Blocks.DEEPSLATE_BRICKS).defaultBlockState();
                    level.setBlock(new BlockPos(cx + dx, y0 + dy, cz + dz), st, FLAGS);
                }
            }
        }
        // dim light so the room is readable but dark
        level.setBlock(new BlockPos(cx, y0 + 4, cz), Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, 6), FLAGS);

        String a = "You are nothing";
        String b = "You deserve death";
        wallSign(level, new BlockPos(cx, y0 + 2, cz - 3), Direction.SOUTH, a);
        wallSign(level, new BlockPos(cx, y0 + 2, cz + 3), Direction.NORTH, b);
        wallSign(level, new BlockPos(cx - 3, y0 + 2, cz), Direction.EAST, b);
        wallSign(level, new BlockPos(cx + 3, y0 + 2, cz), Direction.WEST, a);
    }

    private static void wallSign(ServerLevel level, BlockPos pos, Direction facing, String line) {
        BlockState st = Blocks.CRIMSON_WALL_SIGN.defaultBlockState().setValue(WallSignBlock.FACING, facing);
        level.setBlock(pos, st, FLAGS);
        if (level.getBlockEntity(pos) instanceof SignBlockEntity sign) {
            SignText text = new SignText()
                    .setMessage(1, Component.literal(line))
                    .setColor(DyeColor.RED)
                    .setHasGlowingText(true);
            sign.setText(text, true);
            sign.setWaxed(true);
            sign.setChanged();
            level.sendBlockUpdated(pos, st, st, 3);
        }
    }

    private static void end(UUID id) {
        Session s = ACTIVE.remove(id);
        if (s == null) return;
        ServerPlayer p = s.player();

        if (Sfx.online(p)) {
            p.resetFallDistance();
            p.teleportTo(s.level(), s.x(), s.y(), s.z(), s.yRot(), s.xRot());
        }
        p.setInvulnerable(s.wasInvulnerable());

        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                for (int dy = 0; dy <= 5; dy++) {
                    s.level().setBlock(new BlockPos(s.cx() + dx, s.y0() + dy, s.cz() + dz),
                            Blocks.AIR.defaultBlockState(), FLAGS);
                }
            }
        }
    }

    /** Called on shutdown / logout so nobody is ever stranded in the sky. */
    public static void endAll() {
        for (UUID id : new ArrayList<>(ACTIVE.keySet())) end(id);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (ACTIVE.containsKey(e.getEntity().getUUID())) end(e.getEntity().getUUID());
    }
}
