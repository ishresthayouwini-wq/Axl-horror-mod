package com.axlandareal.world;

import com.axlandareal.AxlAndAReal;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Tiny "run this in N ticks" helper (server thread only). */
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID)
public final class TickScheduler {
    private record Task(long runAt, Runnable action) {}

    private static final List<Task> TASKS = new ArrayList<>();
    private static long now;

    private TickScheduler() {}

    public static void schedule(int delayTicks, Runnable action) {
        TASKS.add(new Task(now + Math.max(0, delayTicks), action));
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        now++;
        if (TASKS.isEmpty()) return;
        List<Task> due = new ArrayList<>();
        for (Iterator<Task> it = TASKS.iterator(); it.hasNext(); ) {
            Task t = it.next();
            if (t.runAt() <= now) {
                due.add(t);
                it.remove();
            }
        }
        for (Task t : due) {
            try {
                t.action().run();
            } catch (Exception ex) {
                AxlAndAReal.LOGGER.error("Scheduled haunt task failed", ex);
            }
        }
    }

    @SubscribeEvent
    public static void onStopping(ServerStoppingEvent e) {
        NightmareRoom.endAll();   // never leave a player in the sky room
        ControlledPlayers.endAll();
        EnvironmentEffects.endRetro(e.getServer());   // thaw the mobs, wash the blood away
        TASKS.clear();
    }
}
