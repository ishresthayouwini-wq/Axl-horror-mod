package com.axlandareal.world;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.entity.AbstractHauntEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Server side of the RETRO environment change:
 *  - every mob, animal and villager within 64 blocks of a player freezes (AI off) until it ends;
 *  - blood (red carpet "splatters") appears on the ground around every player and is washed away at the end.
 * Frozen mobs are tagged, so if the server dies mid-event they thaw the next time they load.
 */
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID)
public final class EnvironmentEffects {
    private static final String TAG = "axlandareal_frozen";

    private static boolean retroActive;
    private static final Map<UUID, ResourceKey<Level>> FROZEN = new HashMap<>();
    private static final Map<ResourceKey<Level>, List<BlockPos>> BLOOD = new HashMap<>();

    private EnvironmentEffects() {}

    public static void startRetro(MinecraftServer server) {
        retroActive = true;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.isSpectator()) continue;
            ServerLevel level = p.serverLevel();
            freezeAround(level, p);
            splatter(level, p);
        }
    }

    private static void freezeAround(ServerLevel level, ServerPlayer p) {
        for (Mob m : level.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(64.0D))) {
            if (m instanceof AbstractHauntEntity || m.isNoAi() || FROZEN.containsKey(m.getUUID())) continue;
            m.setNoAi(true);
            m.addTag(TAG);
            FROZEN.put(m.getUUID(), level.dimension());
        }
    }

    private static void splatter(ServerLevel level, ServerPlayer p) {
        RandomSource r = level.random;
        List<BlockPos> list = BLOOD.computeIfAbsent(level.dimension(), k -> new ArrayList<>());
        for (int i = 0; i < 90; i++) {
            double ang = r.nextDouble() * Math.PI * 2;
            double dist = 3 + r.nextDouble() * 22;
            BlockPos col = BlockPos.containing(p.getX() + Math.cos(ang) * dist, p.getY(), p.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunkAt(col)) continue;
            BlockPos pos = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, col);
            BlockPos below = pos.below();
            if (!level.getBlockState(pos).isAir() || !level.getFluidState(below).isEmpty()) continue;
            if (!level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) continue;
            level.setBlock(pos, Blocks.RED_CARPET.defaultBlockState(), 2 | 16);
            list.add(pos);
        }
    }

    public static void endRetro(MinecraftServer server) {
        if (!retroActive) return;
        retroActive = false;

        for (Map.Entry<UUID, ResourceKey<Level>> en : new ArrayList<>(FROZEN.entrySet())) {
            ServerLevel level = server.getLevel(en.getValue());
            if (level == null) continue;
            Entity e = level.getEntity(en.getKey());
            if (e instanceof Mob m) thaw(m);
        }
        FROZEN.clear();

        for (Map.Entry<ResourceKey<Level>, List<BlockPos>> en : BLOOD.entrySet()) {
            ServerLevel level = server.getLevel(en.getKey());
            if (level == null) continue;
            for (BlockPos pos : en.getValue()) {
                if (level.hasChunkAt(pos) && level.getBlockState(pos).is(Blocks.RED_CARPET)) {
                    level.setBlock(pos, Blocks.AIR.defaultBlockState(), 2 | 16);
                }
            }
        }
        BLOOD.clear();
    }

    private static void thaw(Mob m) {
        m.setNoAi(false);
        m.removeTag(TAG);
    }

    /** A frozen mob that was unloaded during the event thaws as soon as it is loaded again. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (!retroActive && e.getEntity() instanceof Mob m && m.getTags().contains(TAG)) thaw(m);
    }
}
