package com.axlandareal.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Remembers, per world, that the black-and-white and the retro environment change have already happened. */
public final class OnceState extends SavedData {
    private static final String NAME = "axlandareal_once";

    private boolean blackWhiteDone;
    private boolean retroDone;

    public static OnceState get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(OnceState::load, OnceState::new, NAME);
    }

    private static OnceState load(CompoundTag tag) {
        OnceState s = new OnceState();
        s.blackWhiteDone = tag.getBoolean("blackWhiteDone");
        s.retroDone = tag.getBoolean("retroDone");
        return s;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("blackWhiteDone", blackWhiteDone);
        tag.putBoolean("retroDone", retroDone);
        return tag;
    }

    public boolean blackWhiteDone() { return blackWhiteDone; }
    public boolean retroDone() { return retroDone; }

    public void markBlackWhite() { blackWhiteDone = true; setDirty(); }
    public void markRetro() { retroDone = true; setDirty(); }

    public void reset() {
        blackWhiteDone = false;
        retroDone = false;
        setDirty();
    }
}
