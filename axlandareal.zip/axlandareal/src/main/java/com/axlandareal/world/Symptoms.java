package com.axlandareal.world;

import com.axlandareal.network.HauntPacket;
import com.axlandareal.network.ModNetwork;
import com.axlandareal.registry.ModBlocks;
import com.axlandareal.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.StandingSignBlock;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Everything Axl does to the world itself. All placement is limited to already-loaded chunks. */
public final class Symptoms {
    private static final String TAG_INTERFERENCE = "axlandareal_interference_until";

    private Symptoms() {}

    // ---------------------------------------------------------------- signs

    public static boolean placeSign(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        RandomSource r = level.random;
        for (int attempt = 0; attempt < 10; attempt++) {
            double ang = r.nextDouble() * Math.PI * 2;
            double dist = 3 + r.nextDouble() * 5;
            BlockPos col = BlockPos.containing(p.getX() + Math.cos(ang) * dist, p.getY(), p.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunkAt(col)) continue;

            BlockPos pos = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, col);
            if (Math.abs(pos.getY() - p.getBlockY()) > 3) continue;

            BlockState state = Blocks.OAK_SIGN.defaultBlockState()
                    .setValue(StandingSignBlock.ROTATION, r.nextInt(16));
            if (!level.getBlockState(pos).isAir() || !state.canSurvive(level, pos)) continue;

            level.setBlock(pos, state, 3);
            if (level.getBlockEntity(pos) instanceof SignBlockEntity sign) {
                SignText text = new SignText()
                        .setMessage(1, Component.literal(HauntTexts.SIGN_LINES[r.nextInt(HauntTexts.SIGN_LINES.length)]))
                        .setColor(DyeColor.RED);
                sign.setText(text, true);
                sign.setWaxed(true); // can't be edited, only broken
                sign.setChanged();
                level.sendBlockUpdated(pos, state, state, 3);
            }
            return true;
        }
        return false;
    }

    // -------------------------------------------------------------- whispers

    /** Private "Axl whispers to you: ..." message, styled like a vanilla /msg. */
    public static void whisper(ServerPlayer p) {
        p.sendSystemMessage(Component.translatable("commands.message.display.incoming",
                Component.literal("Axl"), Component.literal(pickWhisper(p)))
                .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        p.playNotifySound(ModSounds.AXL_WHISPER.get(), SoundSource.AMBIENT, 0.6F, 0.8F);
    }

    /** Fake public chat line from "Axl", seen by everyone on the server. */
    public static void broadcastWhisper(ServerPlayer victim) {
        MinecraftServer server = victim.getServer();
        if (server == null) return;
        server.getPlayerList().broadcastSystemMessage(Component.literal("<Axl> " + pickWhisper(victim)), false);
    }

    private static String pickWhisper(ServerPlayer p) {
        RandomSource r = p.getRandom();
        List<String> pool = new ArrayList<>();
        pool.add("I'm watching " + p.getGameProfile().getName());
        pool.add("You are not safe even though you build a house");

        // The "betray" line needs a real friend; skipped in singleplayer.
        MinecraftServer server = p.getServer();
        if (server != null) {
            List<ServerPlayer> others = server.getPlayerList().getPlayers().stream().filter(o -> o != p).toList();
            if (!others.isEmpty()) {
                String friend = others.get(r.nextInt(others.size())).getGameProfile().getName();
                pool.add("Your friend " + friend + " is going to betray you");
            }
        }
        return pool.get(r.nextInt(pool.size()));
    }

    // ------------------------------------------------------------ brick wall

    /** Rare 6x6 (wide x tall), 1-thick brick wall in the open, 30-60 blocks from the victim. */
    public static boolean brickWall(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        RandomSource r = level.random;
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = 30 + r.nextInt(30);
        BlockPos col = BlockPos.containing(p.getX() + Math.cos(ang) * dist, p.getY(), p.getZ() + Math.sin(ang) * dist);
        if (!level.hasChunkAt(col)) return false;

        BlockPos base = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, col);
        if (!level.getFluidState(base.below()).isEmpty()) return false;

        boolean alongX = r.nextBoolean();
        // Pass 1: make sure the whole footprint is in loaded chunks.
        for (int i = 0; i < 6; i++) {
            if (!level.hasChunkAt(base.offset(alongX ? i : 0, 0, alongX ? 0 : i))) return false;
        }
        // Pass 2: build. Foundation fills gaps on uneven ground so it never floats.
        for (int i = 0; i < 6; i++) {
            BlockPos colBase = base.offset(alongX ? i : 0, 0, alongX ? 0 : i);
            for (int k = 1; k <= 8; k++) {
                BlockPos below = colBase.below(k);
                if (!level.getBlockState(below).canBeReplaced()) break;
                level.setBlock(below, Blocks.BRICKS.defaultBlockState(), 2);
            }
            for (int j = 0; j < 6; j++) {
                level.setBlock(colBase.above(j), Blocks.BRICKS.defaultBlockState(), 2);
            }
        }
        return true;
    }

    // ------------------------------------------------------------- anomalies

    /** Silently deletes 1-3 nearby farm animals (named and leashed ones are spared). */
    public static int vanishLivestock(ServerPlayer p) {
        List<Animal> list = p.serverLevel().getEntitiesOfClass(Animal.class, p.getBoundingBox().inflate(40),
                a -> (a instanceof Cow || a instanceof Sheep || a instanceof Pig || a instanceof Chicken)
                        && !a.hasCustomName() && !a.isLeashed());
        Collections.shuffle(list);
        int n = Math.min(list.size(), 1 + p.getRandom().nextInt(3));
        for (int i = 0; i < n; i++) list.get(i).discard();
        return n;
    }

    /** A lava block hovering in mid-air 3-6 blocks above the ground, gone after ~40s. */
    public static boolean floatingLava(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        RandomSource r = level.random;
        for (int i = 0; i < 8; i++) {
            double ang = r.nextDouble() * Math.PI * 2;
            double dist = 6 + r.nextDouble() * 8;
            BlockPos col = BlockPos.containing(p.getX() + Math.cos(ang) * dist, p.getY(), p.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunkAt(col)) continue;
            BlockPos ground = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, col);
            BlockPos pos = ground.above(3 + r.nextInt(4));
            if (Math.abs(pos.getY() - p.getBlockY()) > 10 || !level.getBlockState(pos).isAir()) continue;
            level.setBlock(pos, ModBlocks.FLOATING_LAVA.get().defaultBlockState(), 3);
            return true;
        }
        return false;
    }

    // ---------------------------------------------- "broken touch" interference

    public static void applyInterference(ServerPlayer p, int ticks) {
        p.getPersistentData().putLong(TAG_INTERFERENCE, p.level().getGameTime() + ticks);
    }

    public static boolean isInterfered(Player p) {
        return p.getPersistentData().getLong(TAG_INTERFERENCE) > p.level().getGameTime();
    }

    public static void sendRedText(ServerPlayer p, String text) {
        ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.RED_TEXT, text));
    }
}
