package com.axlandareal.world;

import com.axlandareal.network.HauntPacket;
import com.axlandareal.network.ModNetwork;
import com.axlandareal.registry.ModBlocks;
import com.axlandareal.registry.ModSounds;
import com.axlandareal.util.Sfx;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import com.axlandareal.registry.ModItems;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.StandingSignBlock;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Everything Axl does to the world itself. All placement is limited to already-loaded chunks. */
public final class Symptoms {
    private static final String TAG_INTERFERENCE = "axlandareal_interference_until";
    private static final int NO_UPDATES = 2 | 16; // send to clients, skip neighbour shape updates

    private Symptoms() {}

    // ---------------------------------------------------------------- signs

    public static boolean placeSign(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        RandomSource r = level.random;
        for (int attempt = 0; attempt < 10; attempt++) {
            double ang = r.nextDouble() * Math.PI * 2;
            double dist = 3 + r.nextDouble() * 5;
            BlockPos col = BlockPos.containing(p.getX() + Math.cos(ang) * dist, p.getY(), p.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunkAt(col)) continue;

            BlockPos pos = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, col);
            if (Math.abs(pos.getY() - p.getBlockY()) > 3) continue;

            BlockState state = Blocks.OAK_SIGN.defaultBlockState()
                    .setValue(StandingSignBlock.ROTATION, r.nextInt(16));
            if (!level.getBlockState(pos).isAir() || !state.canSurvive(level, pos)) continue;

            level.setBlock(pos, state, 3);
            if (level.getBlockEntity(pos) instanceof SignBlockEntity sign) {
                SignText text = new SignText()
                        .setMessage(1, Component.literal(HauntTexts.SIGN_LINES[r.nextInt(HauntTexts.SIGN_LINES.length)]))
                        .setColor(DyeColor.RED);
                sign.setText(text, true);
                sign.setWaxed(true);
                sign.setChanged();
                level.sendBlockUpdated(pos, state, state, 3);
            }
            return true;
        }
        return false;
    }

    // -------------------------------------------------------------- whispers

    /** Private "Axl whispers to you: ..." message, styled like a vanilla /msg. */
    public static void whisper(ServerPlayer p) {
        whisperText(p, pickWhisper(p));
    }

    public static void whisperText(ServerPlayer p, String text) {
        whisperFrom(p, "Axl", text);
    }

    /** "<fromName> whispers to you: text", styled like a vanilla /msg, delivered to this player only. */
    public static void whisperFrom(ServerPlayer p, String fromName, String text) {
        p.sendSystemMessage(Component.translatable("commands.message.display.incoming",
                Component.literal(fromName), Component.literal(text))
                .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        Sfx.playToSelf(p, ModSounds.AXL_WHISPER.get(), SoundSource.AMBIENT, 0.6F, 0.8F);
    }

    /** Fake public chat line from "Axl", seen by everyone on the server. */
    public static void broadcastWhisper(ServerPlayer victim) {
        MinecraftServer server = victim.getServer();
        if (server == null) return;
        server.getPlayerList().broadcastSystemMessage(Component.literal("<Axl> " + pickWhisper(victim)), false);
    }

    private static String pickWhisper(ServerPlayer p) {
        RandomSource r = p.getRandom();
        List<String> pool = new ArrayList<>();
        pool.add("I'm watching " + p.getGameProfile().getName());

        // The "betray" line needs a real friend; skipped in singleplayer.
        MinecraftServer server = p.getServer();
        if (server != null) {
            List<ServerPlayer> others = server.getPlayerList().getPlayers().stream().filter(o -> o != p).toList();
            if (!others.isEmpty()) {
                String friend = others.get(r.nextInt(others.size())).getGameProfile().getName();
                pool.add("Your friend " + friend + " is going to betray you");
            }
        }
        return pool.get(r.nextInt(pool.size()));
    }

    // ------------------------------------------------------------ structures

    /** Rare 6x6 (wide x tall), 1-thick brick wall in the open, 30-60 blocks from the victim. */
    public static boolean brickWall(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        RandomSource r = level.random;
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = 30 + r.nextInt(30);
        BlockPos col = BlockPos.containing(p.getX() + Math.cos(ang) * dist, p.getY(), p.getZ() + Math.sin(ang) * dist);
        if (!level.hasChunkAt(col)) return false;

        BlockPos base = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, col);
        if (!level.getFluidState(base.below()).isEmpty()) return false;

        boolean alongX = r.nextBoolean();
        for (int i = 0; i < 6; i++) {
            if (!level.hasChunkAt(base.offset(alongX ? i : 0, 0, alongX ? 0 : i))) return false;
        }
        for (int i = 0; i < 6; i++) {
            BlockPos colBase = base.offset(alongX ? i : 0, 0, alongX ? 0 : i);
            for (int k = 1; k <= 8; k++) {
                BlockPos below = colBase.below(k);
                if (!level.getBlockState(below).canBeReplaced()) break;
                level.setBlock(below, Blocks.BRICKS.defaultBlockState(), 2);
            }
            for (int j = 0; j < 6; j++) {
                level.setBlock(colBase.above(j), Blocks.BRICKS.defaultBlockState(), 2);
            }
        }
        return true;
    }

    /** A tall cross of red concrete (8 high, 5 wide arms) standing alone 25-50 blocks away. */
    public static boolean redCross(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        RandomSource r = level.random;
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = 25 + r.nextInt(25);
        BlockPos col = BlockPos.containing(p.getX() + Math.cos(ang) * dist, p.getY(), p.getZ() + Math.sin(ang) * dist);
        if (!level.hasChunkAt(col)) return false;

        BlockPos base = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, col);
        if (!level.getFluidState(base.below()).isEmpty()) return false;

        boolean alongX = r.nextBoolean();
        for (int i = -2; i <= 2; i++) {
            if (!level.hasChunkAt(base.offset(alongX ? i : 0, 0, alongX ? 0 : i))) return false;
        }
        BlockState red = Blocks.RED_CONCRETE.defaultBlockState();
        for (int k = 1; k <= 6; k++) {
            BlockPos below = base.below(k);
            if (!level.getBlockState(below).canBeReplaced()) break;
            level.setBlock(below, red, 2);
        }
        for (int j = 0; j < 8; j++) level.setBlock(base.above(j), red, 2);
        for (int i = -2; i <= 2; i++) {
            level.setBlock(base.offset(alongX ? i : 0, 5, alongX ? 0 : i), red, 2);
        }
        return true;
    }

    // ------------------------------------------------------------- anomalies

    /** Silently deletes 1-3 nearby farm animals (named and leashed ones are spared). */
    public static int vanishLivestock(ServerPlayer p) {
        List<Animal> list = p.serverLevel().getEntitiesOfClass(Animal.class, p.getBoundingBox().inflate(40),
                a -> (a instanceof Cow || a instanceof Sheep || a instanceof Pig || a instanceof Chicken)
                        && !a.hasCustomName() && !a.isLeashed());
        Collections.shuffle(list);
        int n = Math.min(list.size(), 1 + p.getRandom().nextInt(3));
        for (int i = 0; i < n; i++) list.get(i).discard();
        return n;
    }

    /** A lava block hovering in mid-air 3-6 blocks above the ground, gone after ~40s. */
    public static boolean floatingLava(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        RandomSource r = level.random;
        for (int i = 0; i < 8; i++) {
            double ang = r.nextDouble() * Math.PI * 2;
            double dist = 6 + r.nextDouble() * 8;
            BlockPos col = BlockPos.containing(p.getX() + Math.cos(ang) * dist, p.getY(), p.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunkAt(col)) continue;
            BlockPos ground = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, col);
            BlockPos pos = ground.above(3 + r.nextInt(4));
            if (Math.abs(pos.getY() - p.getBlockY()) > 10 || !level.getBlockState(pos).isAir()) continue;
            level.setBlock(pos, ModBlocks.FLOATING_LAVA.get().defaultBlockState(), 3);
            return true;
        }
        return false;
    }

    /**
     * Grass, ferns and flowers within 14 blocks lift off the ground and hang in the air
     * for 40 seconds, then settle back where they were.
     */
    public static int floatingPlants(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        RandomSource r = level.random;
        BlockPos c = p.blockPosition();
        List<BlockPos> found = new ArrayList<>();
        for (int dx = -14; dx <= 14; dx++) {
            for (int dz = -14; dz <= 14; dz++) {
                if (!level.hasChunkAt(c.offset(dx, 0, dz))) continue;
                for (int dy = -4; dy <= 6; dy++) {
                    BlockPos pos = c.offset(dx, dy, dz);
                    BlockState s = level.getBlockState(pos);
                    if (isPlant(s) && !(s.hasProperty(DoublePlantBlock.HALF) && s.getValue(DoublePlantBlock.HALF) == DoubleBlockHalf.UPPER)) {
                        found.add(pos);
                    }
                }
            }
        }
        Collections.shuffle(found);
        int moved = 0;
        for (BlockPos orig : found) {
            if (moved >= 30) break;
            BlockState state = level.getBlockState(orig);
            boolean dbl = state.hasProperty(DoublePlantBlock.HALF);
            BlockPos target = orig.above(2 + r.nextInt(5));
            if (!level.getBlockState(target).isAir() || (dbl && !level.getBlockState(target.above()).isAir())) continue;

            removePlant(level, orig, dbl);
            placePlant(level, target, state, dbl);
            moved++;
            TickScheduler.schedule(20 * 40, () -> {
                if (!level.hasChunkAt(target) || !level.hasChunkAt(orig)) return;
                if (level.getBlockState(target).is(state.getBlock())) removePlant(level, target, dbl);
                if (level.getBlockState(orig).isAir() && state.canSurvive(level, orig)) placePlant(level, orig, state, dbl);
            });
        }
        return moved;
    }

    private static boolean isPlant(BlockState s) {
        return s.is(Blocks.GRASS) || s.is(Blocks.TALL_GRASS) || s.is(Blocks.FERN) || s.is(Blocks.LARGE_FERN)
                || s.is(BlockTags.SMALL_FLOWERS) || s.is(BlockTags.TALL_FLOWERS);
    }

    private static void removePlant(ServerLevel level, BlockPos pos, boolean dbl) {
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), NO_UPDATES);
        if (dbl) level.setBlock(pos.above(), Blocks.AIR.defaultBlockState(), NO_UPDATES);
    }

    private static void placePlant(ServerLevel level, BlockPos pos, BlockState lowerState, boolean dbl) {
        if (dbl) DoublePlantBlock.placeAt(level, lowerState, pos, NO_UPDATES);
        else level.setBlock(pos, lowerState, NO_UPDATES);
    }

    // ------------------------------------------------------------ gift chest

    /**
     * A chest appears 6-10 blocks away with a sign in front of it saying "Gift for you". Inside: a bottle of
     * blood and the head of a random player on the server (in single player: your own). If nobody takes
     * the blood within 5 minutes the chest and sign disappear again.
     */
    public static boolean giftChest(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        MinecraftServer server = p.getServer();
        if (server == null) return false;
        RandomSource r = level.random;

        for (int attempt = 0; attempt < 12; attempt++) {
            double ang = r.nextDouble() * Math.PI * 2;
            double dist = 6 + r.nextDouble() * 4;
            BlockPos col = BlockPos.containing(p.getX() + Math.cos(ang) * dist, p.getY(), p.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunkAt(col)) continue;
            BlockPos chestPos = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, col);
            if (Math.abs(chestPos.getY() - p.getBlockY()) > 3) continue;

            Direction facing = Direction.getNearest(p.getX() - chestPos.getX(), 0.0D, p.getZ() - chestPos.getZ());
            BlockPos signPos = chestPos.relative(facing);
            BlockState chest = Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, facing);
            BlockState sign = Blocks.OAK_SIGN.defaultBlockState()
                    .setValue(StandingSignBlock.ROTATION, facing.get2DDataValue() * 4);
            if (!level.getBlockState(chestPos).isAir() || !level.getBlockState(signPos).isAir()
                    || !sign.canSurvive(level, signPos) || !level.getFluidState(chestPos.below()).isEmpty()) continue;

            level.setBlock(chestPos, chest, 3);
            level.setBlock(signPos, sign, 3);

            if (level.getBlockEntity(chestPos) instanceof ChestBlockEntity box) {
                List<ServerPlayer> everyone = server.getPlayerList().getPlayers();
                ServerPlayer owner = everyone.get(r.nextInt(everyone.size()));
                ItemStack head = new ItemStack(Items.PLAYER_HEAD);
                head.getOrCreateTag().put("SkullOwner", NbtUtils.writeGameProfile(new CompoundTag(), owner.getGameProfile()));
                box.setItem(12, new ItemStack(ModItems.BLOOD_BOTTLE.get()));
                box.setItem(14, head);
                box.setChanged();
            }
            if (level.getBlockEntity(signPos) instanceof SignBlockEntity board) {
                board.setText(new SignText().setMessage(1, Component.literal("Gift for you")).setColor(DyeColor.RED), true);
                board.setWaxed(true);
                board.setChanged();
                level.sendBlockUpdated(signPos, sign, sign, 3);
            }

            TickScheduler.schedule(20 * 300, () -> {
                if (!level.hasChunkAt(chestPos)) return;
                if (level.getBlockEntity(chestPos) instanceof ChestBlockEntity box
                        && box.countItem(ModItems.BLOOD_BOTTLE.get()) > 0) {
                    level.setBlock(chestPos, Blocks.AIR.defaultBlockState(), 2 | 16);
                    if (level.getBlockState(signPos).is(Blocks.OAK_SIGN)) {
                        level.setBlock(signPos, Blocks.AIR.defaultBlockState(), 2 | 16);
                    }
                }
            });
            return true;
        }
        return false;
    }

    // ---------------------------------------------------------------- sounds

    /** 4 seconds of rapid block-breaking noises coming from one direction nearby. */
    public static void breakSounds(ServerPlayer p) {
        SoundType[] types = {SoundType.STONE, SoundType.WOOD, SoundType.GRAVEL, SoundType.DEEPSLATE, SoundType.GRASS};
        double ang = p.getRandom().nextDouble() * Math.PI * 2;
        double ox = Math.cos(ang) * 5.0;
        double oz = Math.sin(ang) * 5.0;
        for (int i = 0; i < 40; i++) {
            TickScheduler.schedule(i * 2, () -> {
                SoundType t = types[p.getRandom().nextInt(types.length)];
                Sfx.playAt(p, t.getBreakSound(), SoundSource.BLOCKS,
                        p.getX() + ox, p.getY(), p.getZ() + oz, 1.0F, 0.8F + p.getRandom().nextFloat() * 0.4F);
            });
        }
    }

    /** Someone sprinting up from behind: 16 steps over 4 seconds, from 16 blocks away to 3. */
    public static void footsteps(ServerPlayer p) {
        double yaw = Math.toRadians(p.getYRot() + 180.0F + (p.getRandom().nextFloat() - 0.5F) * 60.0F);
        double dx = -Math.sin(yaw);
        double dz = Math.cos(yaw);
        SoundType st = p.serverLevel().getBlockState(p.blockPosition().below()).getSoundType();
        int steps = 16;
        for (int i = 0; i < steps; i++) {
            final double dist = 16.0D - 13.0D * i / (steps - 1);
            TickScheduler.schedule(i * 5, () -> Sfx.playAt(p, st.getStepSound(), SoundSource.PLAYERS,
                    p.getX() + dx * dist, p.getY(), p.getZ() + dz * dist, 0.9F, 0.9F + p.getRandom().nextFloat() * 0.2F));
        }
    }

    // ---------------------------------------------- "broken touch" interference

    public static void applyInterference(ServerPlayer p, int ticks) {
        p.getPersistentData().putLong(TAG_INTERFERENCE, p.level().getGameTime() + ticks);
    }

    public static boolean isInterfered(Player p) {
        return p.getPersistentData().getLong(TAG_INTERFERENCE) > p.level().getGameTime();
    }

    public static void sendRedText(ServerPlayer p, String text) {
        ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.RED_TEXT, text));
    }
}
