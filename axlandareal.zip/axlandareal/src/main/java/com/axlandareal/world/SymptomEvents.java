package com.axlandareal.world;

import com.axlandareal.AxlAndAReal;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** The "broken touch" anomaly: while interfered with, ~half of block interactions silently fail. */
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID)
public final class SymptomEvents {
    private SymptomEvents() {}

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (e.getPlayer() instanceof ServerPlayer sp && Symptoms.isInterfered(sp) && sp.getRandom().nextFloat() < 0.5F) {
            e.setCanceled(true);
            sp.displayClientMessage(Component.literal("..."), true);
        }
    }

    @SubscribeEvent
    public static void onUse(PlayerInteractEvent.RightClickBlock e) {
        if (e.getEntity() instanceof ServerPlayer sp && Symptoms.isInterfered(sp) && sp.getRandom().nextFloat() < 0.5F) {
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.FAIL);
        }
    }
}
