package com.axlandareal.world;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.config.AxlConfig;
import com.axlandareal.network.HauntPacket;
import com.axlandareal.network.ModNetwork;
import com.axlandareal.util.Sfx;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * "Controlled": for 50 s one player cannot steer. Their character walks by itself and attacks every
 * living thing nearby (the movement itself is done by their game client, see ControlledClient).
 * The server makes them immortal for the duration and gives that back afterwards.
 */
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID)
public final class ControlledPlayers {
    private record Session(ServerPlayer player, boolean wasInvulnerable) {}

    private static final Map<UUID, Session> ACTIVE = new HashMap<>();
    private static long untilTick;

    private ControlledPlayers() {}

    /** Only one player at a time. */
    public static boolean anyActive(MinecraftServer server) {
        return !ACTIVE.isEmpty() || server.getTickCount() < untilTick;
    }

    public static boolean isControlled(Player p) {
        return ACTIVE.containsKey(p.getUUID());
    }

    public static boolean start(ServerPlayer p) {
        MinecraftServer server = p.getServer();
        if (server == null || p.isSpectator() || anyActive(server)) return false;

        int seconds = AxlConfig.COMMON.controlledSeconds.get();
        UUID id = p.getUUID();
        ACTIVE.put(id, new Session(p, p.isInvulnerable()));
        untilTick = server.getTickCount() + 20L * seconds + 20L;

        p.setInvulnerable(true);   // immortal while controlled
        ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.CONTROLLED, Long.toString(seconds * 1000L)));
        TickScheduler.schedule(20 * seconds, () -> end(id));
        return true;
    }

    public static void end(UUID id) {
        Session s = ACTIVE.remove(id);
        if (s == null) return;
        ServerPlayer p = s.player();
        p.setInvulnerable(s.wasInvulnerable());   // mortal again
        if (Sfx.online(p)) {
            ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.CONTROL_END, ""));
            // brief hidden cushion so being handed back in the middle of a fight or in lava is survivable
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20 * 5, 1, false, false, false));
            p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 20 * 5, 0, false, false, false));
        }
    }

    public static void endAll() {
        for (UUID id : new ArrayList<>(ACTIVE.keySet())) end(id);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        end(e.getEntity().getUUID());
    }

    /** Optional safety switch (server config): the controlled player may not hit other players. */
    @SubscribeEvent
    public static void onAttack(AttackEntityEvent e) {
        if (!AxlConfig.COMMON.controlledHurtsPlayers.get() && isControlled(e.getEntity()) && e.getTarget() instanceof Player) {
            e.setCanceled(true);
        }
    }
}
