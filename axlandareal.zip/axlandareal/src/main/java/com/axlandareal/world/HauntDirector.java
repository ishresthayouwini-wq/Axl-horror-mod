package com.axlandareal.world;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.config.AxlConfig;
import com.axlandareal.entity.AxlEntity;
import com.axlandareal.entity.TallSteveEntity;
import com.axlandareal.network.HauntPacket;
import com.axlandareal.network.ModNetwork;
import com.axlandareal.registry.ModEntities;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * The scheduler. Every second it checks each player's countdown; when it hits
 * zero it rolls a weighted haunt event and resets the countdown.
 */
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID)
public final class HauntDirector {

    public enum HauntEvent {
        SIGN(18), WHISPER(22), GLOBAL_WHISPER(4), BRICK_WALL(5),
        BLACK_FIGURE(10), WHITE_FIGURE(10), AXL(8), TALL_STEVE(3),
        LIVESTOCK(6), FLOATING_LAVA(5), RED_TEXT(14),
        JUMPSCARE_HELP(3), JUMPSCARE_STEVE(1), FAKE_ALERT(2);

        final int weight;
        HauntEvent(int weight) { this.weight = weight; }
    }

    private static final Map<UUID, Long> NEXT_EVENT = new HashMap<>();
    private static final Map<UUID, Long> LAST_JUMPSCARE = new HashMap<>();

    private HauntDirector() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 20 != 0) return;

        long now = server.getTickCount();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.isSpectator() || !p.isAlive()) continue;
            long next = NEXT_EVENT.computeIfAbsent(p.getUUID(), id -> now + randomDelay(p.getRandom()));
            if (now < next) continue;
            NEXT_EVENT.put(p.getUUID(), now + randomDelay(p.getRandom()));
            fire(p, pickWeighted(p.getRandom()));
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        NEXT_EVENT.remove(e.getEntity().getUUID());
        LAST_JUMPSCARE.remove(e.getEntity().getUUID());
    }

    // ------------------------------------------------------------------ fire

    public static void fire(ServerPlayer p, HauntEvent ev) {
        var cfg = AxlConfig.COMMON;
        switch (ev) {
            case SIGN -> { if (cfg.signs.get()) Symptoms.placeSign(p); }
            case WHISPER -> { if (cfg.whispers.get()) Symptoms.whisper(p); }
            case GLOBAL_WHISPER -> { if (cfg.whispers.get()) Symptoms.broadcastWhisper(p); }
            case BRICK_WALL -> { if (cfg.brickWalls.get()) Symptoms.brickWall(p); }
            case BLACK_FIGURE -> { if (cfg.entities.get()) HauntSpawner.spawnPeripheral(p, ModEntities.BLACK_FIGURE.get(), 12, 20); }
            case WHITE_FIGURE -> { if (cfg.entities.get()) HauntSpawner.spawnPeripheral(p, ModEntities.WHITE_FIGURE.get(), 12, 20); }
            case AXL -> {
                if (cfg.entities.get() && !anyAround(p, AxlEntity.class)) {
                    HauntSpawner.spawnBehind(p, ModEntities.AXL.get(), 28, 40);
                }
            }
            case TALL_STEVE -> {
                if (cfg.entities.get() && !anyAround(p, TallSteveEntity.class)) {
                    HauntSpawner.spawnBehind(p, ModEntities.TALL_STEVE.get(), 30, 45);
                }
            }
            case LIVESTOCK -> { if (cfg.anomalies.get()) Symptoms.vanishLivestock(p); }
            case FLOATING_LAVA -> { if (cfg.anomalies.get()) Symptoms.floatingLava(p); }
            case RED_TEXT -> sendRedText(p);
            case JUMPSCARE_HELP -> tryJumpscare(p, HauntPacket.Type.JUMPSCARE_HELP, false);
            case JUMPSCARE_STEVE -> tryJumpscare(p, HauntPacket.Type.JUMPSCARE_STEVE, false);
            case FAKE_ALERT -> sendFakeAlert(p);
        }
    }

    /** Low-key events Axl himself triggers while lurking nearby. */
    public static void fireMinor(ServerPlayer p) {
        switch (p.getRandom().nextInt(3)) {
            case 0 -> fire(p, HauntEvent.WHISPER);
            case 1 -> fire(p, HauntEvent.SIGN);
            default -> fire(p, HauntEvent.RED_TEXT);
        }
    }

    public static void sendRedText(ServerPlayer p) {
        String text = HauntTexts.RED_TEXTS[p.getRandom().nextInt(HauntTexts.RED_TEXTS.length)];
        // 1 in 3 also lands in the chat log
        HauntPacket.Type type = p.getRandom().nextInt(3) == 0 ? HauntPacket.Type.RED_TEXT_CHAT : HauntPacket.Type.RED_TEXT;
        ModNetwork.sendTo(p, new HauntPacket(type, text));
    }

    public static void sendFakeAlert(ServerPlayer p) {
        HauntPacket.Type[] kinds = {
                HauntPacket.Type.FAKE_WEBCAM, HauntPacket.Type.FAKE_MALWARE,
                HauntPacket.Type.FAKE_TAUNT, HauntPacket.Type.FAKE_CRASH
        };
        ModNetwork.sendTo(p, new HauntPacket(kinds[p.getRandom().nextInt(kinds.length)], ""));
    }

    // ------------------------------------------------------------ jumpscares

    /** Applies the per-player cooldown and (for the 7s blackout) a safety check. */
    public static boolean tryJumpscare(ServerPlayer p, HauntPacket.Type type, boolean ignoreCooldown) {
        MinecraftServer server = p.getServer();
        if (server == null) return false;
        long now = server.getTickCount();
        long cooldown = 20L * AxlConfig.COMMON.jumpscareCooldownSeconds.get();
        Long last = LAST_JUMPSCARE.get(p.getUUID());
        if (!ignoreCooldown && last != null && now - last < cooldown) return false;
        if (type == HauntPacket.Type.JUMPSCARE_STEVE && !safeForBlackout(p)) return false;

        LAST_JUMPSCARE.put(p.getUUID(), now);
        ModNetwork.sendTo(p, new HauntPacket(type, ""));
        return true;
    }

    /** Never black out someone's screen while they can die from it (Hardcore!). */
    private static boolean safeForBlackout(ServerPlayer p) {
        return p.onGround()
                && !p.isInWaterOrBubble()
                && !p.isInLava()
                && !p.isOnFire()
                && p.level().getEntitiesOfClass(Monster.class, p.getBoundingBox().inflate(12)).isEmpty();
    }

    // --------------------------------------------------------------- helpers

    private static boolean anyAround(ServerPlayer p, Class<? extends Entity> cls) {
        return !p.serverLevel().getEntitiesOfClass(cls, p.getBoundingBox().inflate(128)).isEmpty();
    }

    private static long randomDelay(RandomSource r) {
        int min = AxlConfig.COMMON.minEventSeconds.get();
        int max = Math.max(min, AxlConfig.COMMON.maxEventSeconds.get());
        return 20L * (min + r.nextInt(max - min + 1));
    }

    private static HauntEvent pickWeighted(RandomSource r) {
        int total = 0;
        for (HauntEvent ev : HauntEvent.values()) total += ev.weight;
        int roll = r.nextInt(total);
        for (HauntEvent ev : HauntEvent.values()) {
            roll -= ev.weight;
            if (roll < 0) return ev;
        }
        return HauntEvent.WHISPER;
    }
}
