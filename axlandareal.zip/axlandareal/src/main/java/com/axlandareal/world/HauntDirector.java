package com.axlandareal.world;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.config.AxlConfig;
import com.axlandareal.entity.AbstractHauntEntity;
import com.axlandareal.entity.AxlEntity;
import com.axlandareal.entity.PlayerCloneEntity;
import com.axlandareal.entity.TallSteveEntity;
import com.axlandareal.network.HauntPacket;
import com.axlandareal.network.ModNetwork;
import com.axlandareal.registry.ModEntities;
import com.axlandareal.util.Flags;
import com.axlandareal.util.Sfx;
import com.axlandareal.util.TimeUtil;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The scheduler. Every second it checks each player's countdown; when it hits
 * zero it rolls a weighted haunt event (only events that are allowed right now)
 * and resets the countdown.
 */
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID)
public final class HauntDirector {

    public enum HauntEvent {
        // original events (stalkers are now much more common)
        SIGN(12), WHISPER(14), GLOBAL_WHISPER(3), BRICK_WALL(4),
        BLACK_FIGURE(16), WHITE_FIGURE(16), AXL(16), TALL_STEVE(7),
        LIVESTOCK(5), FLOATING_LAVA(4), RED_TEXT(10),
        JUMPSCARE_HELP(3), JUMPSCARE_STEVE(1), FAKE_ALERT(2),
        // new in 0.1.1
        AXL_AMBUSH(3), BREAK_SOUNDS(6), FOOTSTEPS(7), RETRO(3), RED_WATER(3), RED_CROSS(3),
        FLOATING_PLANTS(5), NIGHTMARE_ROOM(2), HEAVY_FOG(5),
        // server-wide: black and white is RARE (weight 1, like diamonds), retro is common
        ENVIRONMENT_CHANGE(1), RETRO_CHANGE(8),
        // multiplayer only: Axl clones one player and sends the clone to ANOTHER player
        PLAYER_CLONE(6),
        // new symptoms
        GIFT_CHEST(4), CONTROLLED(2),
        HALLUCINATION_RUSH(2), HALLUCINATION_EYES(3), HALLUCINATION_STARE(3);

        final int weight;
        HauntEvent(int weight) { this.weight = weight; }
    }

    private static final Map<UUID, Long> NEXT_EVENT = new HashMap<>();
    private static final Map<UUID, Long> LAST_JUMPSCARE = new HashMap<>();
    private static long environmentUntilTick;

    private HauntDirector() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 20 != 0) return;

        if (environmentActive(server)) return;   // during an environment change ONLY its own symptoms happen
        long now = server.getTickCount();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.isSpectator() || !p.isAlive()) continue;
            long next = NEXT_EVENT.computeIfAbsent(p.getUUID(), id -> now + randomDelay(p.getRandom()));
            if (now < next) continue;
            NEXT_EVENT.put(p.getUUID(), now + randomDelay(p.getRandom()));
            fire(p, pickWeighted(p, p.getRandom()), false);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        NEXT_EVENT.remove(e.getEntity().getUUID());
        LAST_JUMPSCARE.remove(e.getEntity().getUUID());
    }

    // ------------------------------------------------------------------ fire

    public static void fire(ServerPlayer p, HauntEvent ev) {
        fire(p, ev, false);
    }

    /** forced = triggered by the /axl command: ignores (and does not use up) the one-time limits. */
    public static void fire(ServerPlayer p, HauntEvent ev, boolean forced) {
        var cfg = AxlConfig.COMMON;
        boolean isEnvironment = ev == HauntEvent.ENVIRONMENT_CHANGE || ev == HauntEvent.RETRO_CHANGE;
        if (!forced && !isEnvironment && p.getServer() != null && environmentActive(p.getServer())) return;
        switch (ev) {
            case SIGN -> { if (cfg.signs.get()) Symptoms.placeSign(p); }
            case WHISPER -> { if (cfg.whispers.get()) Symptoms.whisper(p); }
            case GLOBAL_WHISPER -> { if (cfg.whispers.get()) Symptoms.broadcastWhisper(p); }
            case BRICK_WALL -> { if (cfg.brickWalls.get()) Symptoms.brickWall(p); }
            case RED_CROSS -> { if (cfg.brickWalls.get()) Symptoms.redCross(p); }
            case BLACK_FIGURE -> { if (cfg.entities.get()) HauntSpawner.spawnPeripheral(p, ModEntities.BLACK_FIGURE.get(), 12, 20); }
            case WHITE_FIGURE -> { if (cfg.entities.get()) HauntSpawner.spawnPeripheral(p, ModEntities.WHITE_FIGURE.get(), 12, 20); }
            case AXL -> {
                if (cfg.entities.get() && !anyAround(p, AxlEntity.class)) {
                    HauntSpawner.spawnBehind(p, ModEntities.AXL.get(), 28, 40);
                }
            }
            case TALL_STEVE -> {
                if (cfg.entities.get() && !anyAround(p, TallSteveEntity.class)) {
                    HauntSpawner.spawnBehind(p, ModEntities.TALL_STEVE.get(), 30, 45);
                }
            }
            case LIVESTOCK -> { if (cfg.anomalies.get()) Symptoms.vanishLivestock(p); }
            case FLOATING_LAVA -> { if (cfg.anomalies.get()) Symptoms.floatingLava(p); }
            case FLOATING_PLANTS -> { if (cfg.anomalies.get()) Symptoms.floatingPlants(p); }
            case BREAK_SOUNDS -> { if (cfg.anomalies.get()) Symptoms.breakSounds(p); }
            case FOOTSTEPS -> { if (cfg.anomalies.get()) Symptoms.footsteps(p); }
            case RED_TEXT -> sendRedText(p);
            case JUMPSCARE_HELP -> tryJumpscare(p, HauntPacket.Type.JUMPSCARE_HELP, false);
            case JUMPSCARE_STEVE -> tryJumpscare(p, HauntPacket.Type.JUMPSCARE_STEVE, false);
            case FAKE_ALERT -> sendFakeAlert(p);
            case AXL_AMBUSH -> { if (cfg.entities.get()) AxlAmbush.arm(p); }
            case NIGHTMARE_ROOM -> { if (cfg.anomalies.get()) NightmareRoom.start(p); }
            // client-only effects: only THIS player receives them, everyone else sees nothing
            case RETRO -> ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.RETRO, ""));
            case RED_WATER -> ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.RED_WATER, ""));
            case HEAVY_FOG -> ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.HEAVY_FOG, ""));
            case ENVIRONMENT_CHANGE -> {
                // black and white: happens ONE time per world
                if ((cfg.anomalies.get() || forced) && startEnvironment(p, HauntPacket.Type.ENVIRONMENT, cfg.environmentSeconds.get())
                        && !forced && p.getServer() != null) {
                    OnceState.get(p.getServer()).markBlackWhite();
                }
            }
            case RETRO_CHANGE -> {
                // retro: happens ONE time per world
                if ((cfg.anomalies.get() || forced) && startEnvironment(p, HauntPacket.Type.ENVIRONMENT_RETRO, cfg.retroEnvironmentSeconds.get())
                        && !forced && p.getServer() != null) {
                    OnceState.get(p.getServer()).markRetro();
                }
            }
            case PLAYER_CLONE -> { if (cfg.entities.get()) spawnClone(p); }
            case GIFT_CHEST -> { if (cfg.anomalies.get()) Symptoms.giftChest(p); }
            case CONTROLLED -> { if (cfg.entities.get() || forced) ControlledPlayers.start(p); }
            case HALLUCINATION_RUSH -> ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.HALLUCINATION_RUSH, ""));
            case HALLUCINATION_EYES -> ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.HALLUCINATION_EYES, ""));
            case HALLUCINATION_STARE -> ModNetwork.sendTo(p, new HauntPacket(HauntPacket.Type.HALLUCINATION_STARE, ""));
        }
    }

    /** Low-key events Axl himself triggers while lurking nearby. */
    public static void fireMinor(ServerPlayer p) {
        switch (p.getRandom().nextInt(3)) {
            case 0 -> fire(p, HauntEvent.WHISPER);
            case 1 -> fire(p, HauntEvent.SIGN);
            default -> fire(p, HauntEvent.RED_TEXT);
        }
    }

    public static void sendRedText(ServerPlayer p) {
        String text = HauntTexts.RED_TEXTS[p.getRandom().nextInt(HauntTexts.RED_TEXTS.length)];
        // 1 in 3 also lands in the chat log
        HauntPacket.Type type = p.getRandom().nextInt(3) == 0 ? HauntPacket.Type.RED_TEXT_CHAT : HauntPacket.Type.RED_TEXT;
        ModNetwork.sendTo(p, new HauntPacket(type, text));
    }

    public static void sendFakeAlert(ServerPlayer p) {
        HauntPacket.Type[] kinds = {
                HauntPacket.Type.FAKE_WEBCAM, HauntPacket.Type.FAKE_MALWARE,
                HauntPacket.Type.FAKE_TAUNT, HauntPacket.Type.FAKE_CRASH
        };
        ModNetwork.sendTo(p, new HauntPacket(kinds[p.getRandom().nextInt(kinds.length)], ""));
    }

    // ------------------------------------------------------------ jumpscares

    public static boolean jumpscareReady(ServerPlayer p) {
        if (p.getServer() == null) return false;
        long cooldown = 20L * AxlConfig.COMMON.jumpscareCooldownSeconds.get();
        Long last = LAST_JUMPSCARE.get(p.getUUID());
        return last == null || p.getServer().getTickCount() - last >= cooldown;
    }

    public static void markJumpscare(ServerPlayer p) {
        if (p.getServer() != null) LAST_JUMPSCARE.put(p.getUUID(), (long) p.getServer().getTickCount());
    }

    /** Applies the per-player cooldown and (for the 7s blackout) a safety check. */
    public static boolean tryJumpscare(ServerPlayer p, HauntPacket.Type type, boolean ignoreCooldown) {
        if (p.getServer() == null) return false;
        if (!ignoreCooldown && !jumpscareReady(p)) return false;
        if (type == HauntPacket.Type.JUMPSCARE_STEVE && !safeForScare(p)) return false;

        markJumpscare(p);
        ModNetwork.sendTo(p, new HauntPacket(type, ""));
        if (type == HauntPacket.Type.JUMPSCARE_STEVE) scheduleKick(p);
        return true;
    }

    /** Tall Steve scare lasts 7s black + 4s face; the kick lands 0.5s after it ends. */
    private static void scheduleKick(ServerPlayer p) {
        if (!AxlConfig.COMMON.kickAfterTallSteve.get()) return;
        TickScheduler.schedule(230, () -> {
            if (Sfx.online(p)) {
                p.connection.disconnect(Component.literal("The mod is trying to hack your Internet"));
            }
        });
    }

    /** Never black out or freeze someone's screen while they can die from it (Hardcore!). */
    public static boolean safeForScare(ServerPlayer p) {
        return p.onGround()
                && !p.isInWaterOrBubble()
                && !p.isInLava()
                && !p.isOnFire()
                && p.level().getEntitiesOfClass(Monster.class, p.getBoundingBox().inflate(12)).isEmpty();
    }

    /** Server-wide: EVERY online player gets the environment change at the same moment, one at a time. */
    private static boolean startEnvironment(ServerPlayer trigger, HauntPacket.Type type, int seconds) {
        MinecraftServer server = trigger.getServer();
        if (server == null || server.getTickCount() < environmentUntilTick) return false;
        environmentUntilTick = server.getTickCount() + 20L * seconds + 100L;
        purgeStalkers(server);                 // no stalkers while an environment change runs
        AxlAmbush.disarmAll();
        if (type == HauntPacket.Type.ENVIRONMENT_RETRO) {
            EnvironmentEffects.startRetro(server);   // mobs freeze, blood on the ground
            TickScheduler.schedule(20 * seconds, () -> EnvironmentEffects.endRetro(server));
        }
        String millis = Long.toString(seconds * 1000L);
        for (ServerPlayer everyone : server.getPlayerList().getPlayers()) {
            ModNetwork.sendTo(everyone, new HauntPacket(type, millis));
        }
        return true;
    }

    // ------------------------------------------------------- environment change

    /** True while a black-and-white or retro environment change is running (plus a few seconds). */
    public static boolean environmentActive(MinecraftServer server) {
        return server.getTickCount() < environmentUntilTick;
    }

    private static void purgeStalkers(MinecraftServer server) {
        for (ServerLevel level : server.getAllLevels()) {
            List<Entity> found = new java.util.ArrayList<>();
            for (Entity e : level.getAllEntities()) {
                if (e instanceof AbstractHauntEntity) found.add(e);
            }
            for (Entity e : found) e.discard();
        }
    }

    // ----------------------------------------------------------------- clone

    /** Other players (never the victim) who are far enough away, in the same dimension, to be cloned. */
    private static List<ServerPlayer> cloneOriginals(ServerPlayer victim) {
        MinecraftServer server = victim.getServer();
        if (server == null) return List.of();
        double min = AxlConfig.COMMON.cloneMinDistance.get();
        return server.getPlayerList().getPlayers().stream()
                .filter(o -> o != victim && !o.isSpectator() && o.level().dimension() == victim.level().dimension())
                .filter(o -> o.distanceTo(victim) >= min)
                .toList();
    }

    /** Clone a random OTHER player and send the clone to the victim. Single-player never has any candidate. */
    private static void spawnClone(ServerPlayer victim) {
        List<ServerPlayer> originals = cloneOriginals(victim);
        if (originals.isEmpty() || anyAround(victim, PlayerCloneEntity.class)) return;
        ServerPlayer original = originals.get(victim.getRandom().nextInt(originals.size()));
        PlayerCloneEntity clone = HauntSpawner.spawnBehind(victim, ModEntities.PLAYER_CLONE.get(), 28, 40);
        if (clone != null) clone.setCloneOf(original, victim);
    }

    // --------------------------------------------------------------- helpers

    private static boolean anyAround(ServerPlayer p, Class<? extends Entity> cls) {
        return !p.serverLevel().getEntitiesOfClass(cls, p.getBoundingBox().inflate(128)).isEmpty();
    }

    private static long randomDelay(RandomSource r) {
        int min = AxlConfig.COMMON.minEventSeconds.get();
        int max = Math.max(min, AxlConfig.COMMON.maxEventSeconds.get());
        return 20L * (min + r.nextInt(max - min + 1));
    }

    /** Day/night rules: White Figure by day only, Black Figure by night only. */
    private static boolean eligible(ServerPlayer p, HauntEvent ev) {
        boolean day = TimeUtil.isDay(p.level());
        return switch (ev) {
            case WHITE_FIGURE -> day;
            case BLACK_FIGURE -> !day;
            case NIGHTMARE_ROOM -> !Flags.has(p, Flags.NIGHTMARE) && p.level().dimension() == Level.OVERWORLD;
            case AXL_AMBUSH -> !AxlAmbush.isArmed(p);
            case ENVIRONMENT_CHANGE -> p.getServer() != null && p.getServer().getTickCount() >= environmentUntilTick
                    && !OnceState.get(p.getServer()).blackWhiteDone();
            case RETRO_CHANGE -> p.getServer() != null && p.getServer().getTickCount() >= environmentUntilTick
                    && !OnceState.get(p.getServer()).retroDone();
            case PLAYER_CLONE -> !cloneOriginals(p).isEmpty();
            case CONTROLLED -> p.getServer() != null && !ControlledPlayers.anyActive(p.getServer());
            default -> true;
        };
    }

    private static HauntEvent pickWeighted(ServerPlayer p, RandomSource r) {
        int total = 0;
        for (HauntEvent ev : HauntEvent.values()) {
            if (eligible(p, ev)) total += ev.weight;
        }
        int roll = r.nextInt(Math.max(1, total));
        for (HauntEvent ev : HauntEvent.values()) {
            if (!eligible(p, ev)) continue;
            roll -= ev.weight;
            if (roll < 0) return ev;
        }
        return HauntEvent.WHISPER;
    }
}
