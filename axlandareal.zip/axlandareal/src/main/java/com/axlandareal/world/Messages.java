package com.axlandareal.world;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.config.AxlConfig;
import com.axlandareal.util.Flags;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.StructureTags;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Two situational whispers. Each is sent at most once per player, ever. */
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID)
public final class Messages {
    private static final Map<UUID, ArrayDeque<Long>> PLACED = new HashMap<>();

    private Messages() {}

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % 100 != 0) return;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) checkHouse(p, server);
    }

    /** "Inside a house" = under a nearby roof AND (in a village OR near another player's bed). */
    private static void checkHouse(ServerPlayer p, MinecraftServer server) {
        if (!AxlConfig.COMMON.whispers.get() || Flags.has(p, Flags.MSG_HOUSE) || p.isSpectator()) return;
        if (HauntDirector.environmentActive(server)) return;
        ServerLevel level = p.serverLevel();
        BlockPos pos = p.blockPosition();

        if (level.canSeeSky(pos.above())) return;
        boolean roof = false;
        for (int i = 2; i <= 8; i++) {
            if (!level.getBlockState(pos.above(i)).isAir()) { roof = true; break; }
        }
        if (!roof) return;

        boolean villagerHouse = level.structureManager().getStructureWithPieceAt(pos, StructureTags.VILLAGE).isValid();
        boolean friendHouse = false;
        for (ServerPlayer other : server.getPlayerList().getPlayers()) {
            if (other == p) continue;
            BlockPos bed = other.getRespawnPosition();
            if (bed != null && other.getRespawnDimension() == level.dimension() && bed.distSqr(pos) < 12.0D * 12.0D) {
                friendHouse = true;
                break;
            }
        }
        if (villagerHouse || friendHouse) {
            Flags.set(p, Flags.MSG_HOUSE);
            Symptoms.whisperText(p, "Do you think you are safe when you are in a house");
        }
    }

    /** "Building" = 30 blocks placed within one minute. */
    public static void onPlaced(ServerPlayer p) {
        if (!AxlConfig.COMMON.whispers.get() || Flags.has(p, Flags.MSG_BUILD) || p.getServer() == null) return;
        if (HauntDirector.environmentActive(p.getServer())) return;
        long now = p.getServer().getTickCount();
        ArrayDeque<Long> q = PLACED.computeIfAbsent(p.getUUID(), k -> new ArrayDeque<>());
        q.addLast(now);
        while (!q.isEmpty() && now - q.peekFirst() > 1200L) q.removeFirst();
        if (q.size() >= 30) {
            Flags.set(p, Flags.MSG_BUILD);
            q.clear();
            Symptoms.whisperText(p, "building a house will never make you safe");
        }
    }
}
