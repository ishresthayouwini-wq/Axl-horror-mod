package com.axlandareal.world;

import com.axlandareal.entity.AbstractHauntEntity;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/** Picks spawn spots relative to where the victim is looking. All methods may return null. */
public final class HauntSpawner {
    private HauntSpawner() {}

    /** 62-84 degrees off the view direction: just outside the edge of the screen. */
    public static <T extends AbstractHauntEntity> T spawnPeripheral(
            ServerPlayer p, EntityType<T> type, double minDist, double maxDist) {
        float side = p.getRandom().nextBoolean() ? 1.0F : -1.0F;
        return spawnAtYawOffset(p, type, side * (62.0F + p.getRandom().nextFloat() * 22.0F), minDist, maxDist);
    }

    /** 130-180 degrees off: behind the player. */
    public static <T extends AbstractHauntEntity> T spawnBehind(
            ServerPlayer p, EntityType<T> type, double minDist, double maxDist) {
        float side = p.getRandom().nextBoolean() ? 1.0F : -1.0F;
        return spawnAtYawOffset(p, type, side * (130.0F + p.getRandom().nextFloat() * 50.0F), minDist, maxDist);
    }

    private static <T extends AbstractHauntEntity> T spawnAtYawOffset(
            ServerPlayer p, EntityType<T> type, float yawOffset, double minDist, double maxDist) {
        ServerLevel level = p.serverLevel();
        double rad = Math.toRadians(p.getYRot() + yawOffset);
        double dist = minDist + level.random.nextDouble() * (maxDist - minDist);

        // Minecraft yaw convention: forward = (-sin(yaw), cos(yaw))
        BlockPos column = BlockPos.containing(p.getX() - Math.sin(rad) * dist, p.getY(), p.getZ() + Math.cos(rad) * dist);
        if (!level.hasChunkAt(column)) return null; // never force-load chunks

        BlockPos ground = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, column);
        if (Math.abs(ground.getY() - p.getBlockY()) > 12) return null; // player in a cave/up a mountain
        if (!level.getFluidState(ground.below()).isEmpty()) return null;

        T mob = type.create(level);
        if (mob == null) return null;
        mob.moveTo(ground.getX() + 0.5D, ground.getY(), ground.getZ() + 0.5D, 0.0F, 0.0F);
        mob.lookAt(EntityAnchorArgument.Anchor.EYES, p.getEyePosition());
        mob.setHauntTarget(p);
        level.addFreshEntity(mob);
        return mob;
    }

    /** Standing spot 4-9 blocks ahead of where the player is looking, with a clear line of sight. */
    public static <T extends AbstractHauntEntity> T spawnInFront(
            ServerPlayer p, EntityType<T> type, int minDist, int maxDist) {
        ServerLevel level = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 dir = new Vec3(look.x, 0.0D, look.z);
        if (dir.lengthSqr() < 1.0E-4D) return null;
        dir = dir.normalize();

        for (int d = maxDist; d >= minDist; d--) {
            for (int dy = -1; dy <= 1; dy++) {
                BlockPos feet = BlockPos.containing(p.getX() + dir.x * d, p.getY() + dy, p.getZ() + dir.z * d);
                if (!level.hasChunkAt(feet)) continue;
                boolean free = level.getBlockState(feet).isAir() && level.getBlockState(feet.above()).isAir();
                boolean floor = level.getBlockState(feet.below()).isFaceSturdy(level, feet.below(), Direction.UP);
                if (!free || !floor) continue;

                T mob = type.create(level);
                if (mob == null) return null;
                mob.moveTo(feet.getX() + 0.5D, feet.getY(), feet.getZ() + 0.5D, 0.0F, 0.0F);
                mob.lookAt(EntityAnchorArgument.Anchor.EYES, p.getEyePosition());
                mob.setHauntTarget(p);
                level.addFreshEntity(mob);
                if (p.hasLineOfSight(mob)) return mob;
                mob.discard();
            }
        }
        return null;
    }
}
