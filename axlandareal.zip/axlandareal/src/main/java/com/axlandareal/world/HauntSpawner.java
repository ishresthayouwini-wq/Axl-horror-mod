package com.axlandareal.world;

import com.axlandareal.entity.AbstractHauntEntity;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.levelgen.Heightmap;

/** Picks spawn spots relative to where the victim is looking. All methods may return null. */
public final class HauntSpawner {
    private HauntSpawner() {}

    /** 62-84 degrees off the view direction: just outside the edge of the screen. */
    public static <T extends AbstractHauntEntity> T spawnPeripheral(
            ServerPlayer p, EntityType<T> type, double minDist, double maxDist) {
        float side = p.getRandom().nextBoolean() ? 1.0F : -1.0F;
        return spawnAtYawOffset(p, type, side * (62.0F + p.getRandom().nextFloat() * 22.0F), minDist, maxDist);
    }

    /** 130-180 degrees off: behind the player. */
    public static <T extends AbstractHauntEntity> T spawnBehind(
            ServerPlayer p, EntityType<T> type, double minDist, double maxDist) {
        float side = p.getRandom().nextBoolean() ? 1.0F : -1.0F;
        return spawnAtYawOffset(p, type, side * (130.0F + p.getRandom().nextFloat() * 50.0F), minDist, maxDist);
    }

    private static <T extends AbstractHauntEntity> T spawnAtYawOffset(
            ServerPlayer p, EntityType<T> type, float yawOffset, double minDist, double maxDist) {
        ServerLevel level = p.serverLevel();
        double rad = Math.toRadians(p.getYRot() + yawOffset);
        double dist = minDist + level.random.nextDouble() * (maxDist - minDist);

        // Minecraft yaw convention: forward = (-sin(yaw), cos(yaw))
        BlockPos column = BlockPos.containing(p.getX() - Math.sin(rad) * dist, p.getY(), p.getZ() + Math.cos(rad) * dist);
        if (!level.hasChunkAt(column)) return null; // never force-load chunks

        BlockPos ground = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, column);
        if (Math.abs(ground.getY() - p.getBlockY()) > 12) return null; // player in a cave/up a mountain
        if (!level.getFluidState(ground.below()).isEmpty()) return null;

        T mob = type.create(level);
        if (mob == null) return null;
        mob.moveTo(ground.getX() + 0.5D, ground.getY(), ground.getZ() + 0.5D, 0.0F, 0.0F);
        mob.lookAt(EntityAnchorArgument.Anchor.EYES, p.getEyePosition());
        mob.setHauntTarget(p);
        level.addFreshEntity(mob);
        return mob;
    }
}
