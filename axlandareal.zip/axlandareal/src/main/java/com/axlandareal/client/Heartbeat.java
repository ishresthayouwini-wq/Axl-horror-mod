package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.registry.ModSounds;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** A heartbeat that speeds up and gets louder: the build-up before a scare lands. */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, value = Dist.CLIENT)
public final class Heartbeat {
    private static boolean active;
    private static long startMs, durationMs, nextMs, firstInterval, lastInterval;

    private Heartbeat() {}

    public static void start(long duration, long firstIntervalMs, long lastIntervalMs) {
        active = true;
        startMs = Util.getMillis();
        durationMs = duration;
        firstInterval = firstIntervalMs;
        lastInterval = lastIntervalMs;
        nextMs = startMs;
    }

    public static void stop() {
        active = false;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !active) return;
        long now = Util.getMillis();
        if (now - startMs > durationMs) {
            active = false;
            return;
        }
        if (now >= nextMs) {
            float p = (now - startMs) / (float) durationMs;
            Minecraft.getInstance().getSoundManager().play(
                    SimpleSoundInstance.forUI(ModSounds.HEARTBEAT.get(), 1.0F, Mth.lerp(p, 0.35F, 1.0F)));
            nextMs = now + (long) Mth.lerp(p, (float) firstInterval, (float) lastInterval);
        }
    }
}
