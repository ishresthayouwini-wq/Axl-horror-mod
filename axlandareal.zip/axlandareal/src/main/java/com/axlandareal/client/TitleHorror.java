package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.config.AxlConfig;
import com.axlandareal.registry.ModSounds;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * The scary title screen (on top of the bloody-forest panorama and the red buttons):
 *  - fog drifting across in two layers, a slow fade up from black when you arrive;
 *  - pairs of red eyes appear in the dark and follow your pointer, then blink away;
 *  - blood creeping down from the top edge, a darkening vignette, brief power-flicker blackouts;
 *  - whispered words that fade in and out;
 *  - rarely (about 4 visits in 10) a split-second flash of the face with a static burst;
 *  - creepy ambience (drone + heartbeat) instead of the cheerful menu music.
 * Switch: scaryMenu. "reduceFlashing" removes the flicker, blinking, shake-like effects and the flash.
 */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, value = Dist.CLIENT)
public final class TitleHorror {
    private static final ResourceLocation FOG = new ResourceLocation(AxlAndAReal.MODID, "textures/gui/menu_fog.png");
    private static final ResourceLocation FACE = new ResourceLocation(AxlAndAReal.MODID, "textures/gui/tall_steve_face.png");
    private static final long AMBIENCE_REPEAT_MS = 38500L;   // the 40 s loop overlaps itself slightly
    private static final long FLASH_MS = 90L;
    private static final String[] WHISPERS = {
            "behind you", "abreal help me", "he can hear you", "don't look away",
            "why are you here", "it has no face", "he is not alone", "count the heads"};

    private static boolean inMenu;
    private static long openedMs, nextAmbienceMs, flashAtMs, nextWhisperMs, whisperStartMs;
    private static boolean flashPlayed;
    private static String whisper = "";
    private static int whisperX, whisperY;

    private TitleHorror() {}

    private static boolean enabled() {
        return AxlConfig.CLIENT.scaryMenu.get();
    }

    private static boolean calm() {
        return AxlConfig.CLIENT.reduceFlashing.get();
    }

    // ------------------------------------------------------------- state + sound

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        boolean now = enabled() && mc.level == null && mc.screen != null;
        long ms = Util.getMillis();

        if (now && !inMenu) {
            inMenu = true;
            openedMs = ms;
            nextAmbienceMs = ms;
            nextWhisperMs = ms + 6000L;
            flashPlayed = false;
            RandomSource r = RandomSource.create();
            flashAtMs = r.nextFloat() < 0.4F ? ms + 12000L + r.nextInt(18000) : Long.MAX_VALUE;
        } else if (!now && inMenu) {
            inMenu = false;
            mc.getSoundManager().stop(ModSounds.MENU_AMBIENCE.get().getLocation(), null);
        }
        if (inMenu && ms >= nextAmbienceMs) {
            nextAmbienceMs = ms + AMBIENCE_REPEAT_MS;
            mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.MENU_AMBIENCE.get(), 1.0F, 0.75F));
        }
    }

    /** The menu music is replaced by the ambience above. */
    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent e) {
        if (!enabled()) return;
        SoundInstance s = e.getSound();
        if (s != null && Minecraft.getInstance().level == null && s.getSource() == SoundSource.MUSIC) {
            e.setSound(null);
        }
    }

    // ------------------------------------------------------------------- drawing

    @SubscribeEvent
    public static void onRender(ScreenEvent.Render.Post e) {
        if (!enabled() || !(e.getScreen() instanceof TitleScreen)) return;
        GuiGraphics g = e.getGuiGraphics();
        int w = e.getScreen().width;
        int h = e.getScreen().height;
        long now = Util.getMillis();
        long t = now - openedMs;
        boolean calm = calm();

        fog(g, w, h, now);
        vignette(g, w, h, now);
        drips(g, w, t);
        eyes(g, w, h, e.getMouseX(), e.getMouseY(), now, calm);
        whispers(g, w, h, now);

        if (!calm) {
            long c = t % 15000L;                                   // power flicker
            if (c < 70L || (c > 170L && c < 230L)) g.fill(0, 0, w, h, 0xBB000000);
        }
        if (t < 1800L) g.fill(0, 0, w, h, ((int) (255 * (1.0F - t / 1800.0F)) << 24));   // fade up from black

        flash(g, w, h, now, calm);
    }

    private static void fog(GuiGraphics g, int w, int h, long now) {
        int th = (int) (h * 0.7F);
        int tw = th * 2;
        RenderSystem.enableBlend();
        for (int layer = 0; layer < 2; layer++) {
            float speed = layer == 0 ? 6.0F : -15.0F;               // gui pixels per second, opposite ways
            int off = Math.floorMod((int) (now / 1000.0D * speed), tw);
            int y = h - th + (layer == 0 ? 0 : th / 8);
            g.setColor(1.0F, 1.0F, 1.0F, layer == 0 ? 0.55F : 0.4F);
            for (int x = off - tw; x < w; x += tw) {
                g.blit(FOG, x, y, tw, th, 0.0F, 0.0F, 512, 256, 512, 256);
            }
        }
        g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }

    private static void vignette(GuiGraphics g, int w, int h, long now) {
        float pulse = 0.75F + 0.25F * Mth.sin(now / 900.0F);       // slow breathing
        int steps = 9;
        for (int i = 0; i < steps; i++) {
            int inset = (int) (Math.min(w, h) * 0.06F * i);
            int a = (int) (70 * pulse * (steps - i) / steps);
            int c = a << 24;
            g.fill(0, 0, w, inset + 3, c);
            g.fill(0, h - inset - 3, w, h, c);
            g.fill(0, 0, inset + 3, h, c);
            g.fill(w - inset - 3, 0, w, h, c);
        }
    }

    private static void drips(GuiGraphics g, int w, long t) {
        RandomSource r = RandomSource.create(4242L);
        for (int i = 0; i < 30; i++) {
            int x = r.nextInt(Math.max(1, w));
            int dw = 1 + r.nextInt(3);
            float speed = 0.3F + r.nextFloat() * 0.7F;
            int maxLen = 20 + r.nextInt(80);
            int len = (int) Math.min(maxLen, 6 + (t / 1000.0F) * 3.0F * speed);   // creeping down slowly
            g.fill(x, 0, x + dw, len, 0xCC7A0606);
            g.fill(x - 1, len, x + dw + 1, len + 3, 0xCC9A0A0A);
        }
    }

    /** Red eyes that open in the dark at the sides of the screen and watch the pointer. */
    private static void eyes(GuiGraphics g, int w, int h, int mouseX, int mouseY, long now, boolean calm) {
        for (int i = 0; i < 7; i++) {
            long period = 6500L + i * 1700L;
            long shifted = now + i * 2347L;
            long cycle = shifted / period;
            long phase = shifted % period;
            long show = 3200L;
            if (phase > show) continue;
            if (!calm && (phase / 140L) % 9L == 4L) continue;      // blink

            RandomSource r = RandomSource.create(i * 7919L + cycle * 104729L);
            boolean left = r.nextBoolean() || w < 420;
            int ex = left ? 12 + r.nextInt(Math.max(1, w / 2 - 150)) : w / 2 + 150 + r.nextInt(Math.max(1, w / 2 - 175));
            int ey = 14 + r.nextInt(Math.max(1, h - 40));

            float a = phase < 500L ? phase / 500.0F : (phase > show - 400L ? (show - phase) / 400.0F : 1.0F);
            int alpha = (int) (255 * Mth.clamp(a, 0.0F, 1.0F));
            if (alpha < 20) continue;

            g.fill(ex - 4, ey - 3, ex + 14, ey + 5, ((alpha / 4) << 24) | 0xFF0000);   // glow
            int c = (alpha << 24) | 0xFF2020;
            g.fill(ex, ey, ex + 3, ey + 2, c);
            g.fill(ex + 7, ey, ex + 10, ey + 2, c);
            int look = Mth.clamp((mouseX - ex) / 60, -1, 1);                          // pupils follow the pointer
            int dark = (alpha << 24) | 0x300000;
            g.fill(ex + 1 + look, ey, ex + 2 + look, ey + 2, dark);
            g.fill(ex + 8 + look, ey, ex + 9 + look, ey + 2, dark);
        }
    }

    private static void whispers(GuiGraphics g, int w, int h, long now) {
        if (now >= nextWhisperMs) {
            RandomSource r = RandomSource.create();
            whisper = WHISPERS[r.nextInt(WHISPERS.length)];
            whisperStartMs = now;
            nextWhisperMs = now + 8000L + r.nextInt(7000);
            whisperX = 8 + r.nextInt(Math.max(1, w - 130));
            whisperY = r.nextBoolean() ? h - 16 - r.nextInt(30) : 10 + r.nextInt(30);
        }
        long age = now - whisperStartMs;
        if (whisper.isEmpty() || age > 2800L) return;
        float a = age < 600L ? age / 600.0F : (age > 2000L ? (2800L - age) / 800.0F : 1.0F);
        int alpha = (int) (200 * Mth.clamp(a, 0.0F, 1.0F));
        if (alpha < 10) return;
        Font font = Minecraft.getInstance().font;
        g.drawString(font, whisper, whisperX, whisperY, (alpha << 24) | 0xA00000, false);
    }

    /** A split-second flash of the face, at most once per visit. */
    private static void flash(GuiGraphics g, int w, int h, long now, boolean calm) {
        if (calm || flashAtMs == Long.MAX_VALUE || now < flashAtMs || now >= flashAtMs + FLASH_MS) return;
        if (!flashPlayed) {
            flashPlayed = true;
            Minecraft.getInstance().getSoundManager()
                    .play(SimpleSoundInstance.forUI(ModSounds.STATIC_BURST.get(), 1.0F, 1.0F));
        }
        g.fill(0, 0, w, h, 0xFF000000);
        int size = h;
        RenderSystem.enableBlend();
        g.blit(FACE, (w - size) / 2, 0, size, size, 0.0F, 0.0F, 512, 512, 512, 512);
        RenderSystem.disableBlend();
        g.fill(0, 0, w, h, 0x55AA0000);
    }
}
