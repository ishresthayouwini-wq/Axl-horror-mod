package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Ambush camera lock: while tracking, the player's view is dragged onto the entity every
 * frame. While "frozen", movement, jumping and attack/use/place input are blocked.
 * Frozen lasts until the Axl face + video overlay finishes (hard cap: 30 s).
 */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, value = Dist.CLIENT)
public final class CameraLock {
    private static int entityId = -1;
    private static long trackStartMs;
    private static boolean frozen;
    private static long frozenSinceMs;

    private CameraLock() {}

    public static void start(int id) {
        entityId = id;
        trackStartMs = Util.getMillis();
        frozen = true;
        frozenSinceMs = trackStartMs;
        ScareVideo.preloadStart(); // warm up the video frames while the player is locked
        Heartbeat.start(3600L, 700L, 380L);   // rising heartbeat and a growing tremble
        ScareFx.shake(0.35F, 3400L);
    }

    /** Stop dragging the camera; input stays frozen if the face/video overlay is running. */
    public static void stopTracking() {
        entityId = -1;
        if (!HauntOverlay.axlActive()) frozen = false;
    }

    public static void release() {
        entityId = -1;
        frozen = false;
    }

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase != TickEvent.Phase.START) return;
        long now = Util.getMillis();
        if (frozen && now - frozenSinceMs > 30000L) release();
        if (entityId < 0) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || now - trackStartMs > 8000L) {
            entityId = -1;
            return;
        }
        Entity target = mc.level.getEntity(entityId);
        if (target == null) return;

        Vec3 from = mc.player.getEyePosition(e.renderTickTime);
        Vec3 to = target.getPosition(e.renderTickTime).add(0.0D, target.getBbHeight() * 0.6D, 0.0D);
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        float yaw = (float) (Mth.atan2(dz, dx) * 57.29578F) - 90.0F;
        float pitch = (float) -(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 57.29578F);

        float newYaw = Mth.rotLerp(0.4F, mc.player.getYRot(), yaw);
        float newPitch = Mth.clamp(Mth.rotLerp(0.4F, mc.player.getXRot(), pitch), -90.0F, 90.0F);
        mc.player.setYRot(newYaw);
        mc.player.setXRot(newPitch);
        mc.player.yRotO = newYaw;
        mc.player.xRotO = newPitch;
    }

    @SubscribeEvent
    public static void onMove(MovementInputUpdateEvent e) {
        if (!frozen) return;
        Input in = e.getInput();
        in.leftImpulse = 0.0F;
        in.forwardImpulse = 0.0F;
        in.up = false;
        in.down = false;
        in.left = false;
        in.right = false;
        in.jumping = false;
        in.shiftKeyDown = false;
    }

    @SubscribeEvent
    public static void onInteract(InputEvent.InteractionKeyMappingTriggered e) {
        if (!frozen) return;
        e.setCanceled(true);
        e.setSwingHand(false);
    }
}
