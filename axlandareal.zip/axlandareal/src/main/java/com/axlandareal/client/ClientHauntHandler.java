package com.axlandareal.client;

import com.axlandareal.client.screen.FakeAlertScreen;
import com.axlandareal.config.AxlConfig;
import com.axlandareal.network.HauntPacket;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * Receives HauntPackets on the client. Each player's own comfort settings
 * (AxlConfig.CLIENT) decide whether a scare is shown at all.
 */
@OnlyIn(Dist.CLIENT)
public final class ClientHauntHandler {
    private ClientHauntHandler() {}

    public static void handle(HauntPacket pkt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        String name = mc.player.getGameProfile().getName();
        var cfg = AxlConfig.CLIENT;

        switch (pkt.type()) {
            case RED_TEXT, RED_TEXT_CHAT -> {
                if (!cfg.floatingText.get()) return;
                HauntOverlay.addFloatingText(pkt.text());
                if (pkt.type() == HauntPacket.Type.RED_TEXT_CHAT) {
                    mc.gui.getChat().addMessage(Component.literal(pkt.text())
                            .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD));
                }
            }
            case JUMPSCARE_HELP -> { if (cfg.jumpscares.get()) HauntOverlay.startHelp(); }
            case JUMPSCARE_STEVE -> { if (cfg.jumpscares.get()) HauntOverlay.startSteve(); }
            case CAMERA_LOCK -> {
                if (!cfg.jumpscares.get()) return;
                try {
                    CameraLock.start(Integer.parseInt(pkt.text()));
                } catch (NumberFormatException ignored) { }
            }
            case CAMERA_UNLOCK -> CameraLock.stopTracking();
            case AXL_FACE -> {
                if (cfg.jumpscares.get()) HauntOverlay.startAxlFace();
                else CameraLock.release();
            }
            case RETRO -> { if (cfg.visualEffects.get()) RetroEffect.start(); }
            case RED_WATER -> { if (cfg.visualEffects.get()) RedWater.start(); }
            case ENVIRONMENT -> startEnvironment(cfg.visualEffects.get(), EnvironmentChange.Kind.BLACK_WHITE, pkt.text());
            case ENVIRONMENT_RETRO -> startEnvironment(cfg.visualEffects.get(), EnvironmentChange.Kind.RETRO, pkt.text());
            case CONTROLLED -> {
                if (!cfg.visualEffects.get()) return;
                long ms = 50000L;
                try {
                    ms = Long.parseLong(pkt.text());
                } catch (NumberFormatException ignored) { }
                ControlledClient.start(ms);
            }
            case CONTROL_END -> ControlledClient.stop();
            case HEAVY_FOG -> { if (cfg.visualEffects.get()) HeavyFog.start(90_000L); }
            case HALLUCINATION_RUSH -> { if (cfg.visualEffects.get()) HallucinationClient.start(HallucinationClient.Mode.RUSH); }
            case HALLUCINATION_EYES -> { if (cfg.visualEffects.get()) HallucinationClient.start(HallucinationClient.Mode.EYES); }
            case HALLUCINATION_STARE -> { if (cfg.visualEffects.get()) HallucinationClient.start(HallucinationClient.Mode.STARE); }
            case FAKE_WEBCAM -> openAlert(mc, FakeAlertScreen.Kind.WEBCAM, name);
            case FAKE_MALWARE -> openAlert(mc, FakeAlertScreen.Kind.MALWARE, name);
            case FAKE_TAUNT -> openAlert(mc, FakeAlertScreen.Kind.TAUNT, name);
            case FAKE_CRASH -> openAlert(mc, FakeAlertScreen.Kind.CRASH, name);
        }
    }

    private static void startEnvironment(boolean enabled, EnvironmentChange.Kind kind, String text) {
        if (!enabled) return;
        long ms = kind.defaultMs();
        try {
            ms = Long.parseLong(text);
        } catch (NumberFormatException ignored) { }
        EnvironmentChange.start(kind, ms);
    }

    /** Never interrupts an open GUI (inventory, chest, pause menu...). */
    private static void openAlert(Minecraft mc, FakeAlertScreen.Kind kind, String playerName) {
        if (!AxlConfig.CLIENT.fakeAlerts.get() || mc.screen != null) return;
        mc.setScreen(new FakeAlertScreen(kind, playerName));
    }
}
