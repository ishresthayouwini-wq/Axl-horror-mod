package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.config.AxlConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Every menu button (main menu, settings, ...) turns red while the pointer is on it. Switch: redMenu. */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, value = Dist.CLIENT)
public final class MenuStyle {
    private MenuStyle() {}

    @SubscribeEvent
    public static void onRender(ScreenEvent.Render.Post e) {
        if (!AxlConfig.CLIENT.redMenu.get()) return;
        Screen screen = e.getScreen();
        if (screen instanceof AbstractContainerScreen) return;   // not over inventories and chests

        GuiGraphics g = e.getGuiGraphics();
        for (GuiEventListener child : screen.children()) {
            if (!(child instanceof AbstractWidget w) || child instanceof EditBox) continue;
            if (!w.visible || !w.active || !w.isHoveredOrFocused()) continue;
            int x = w.getX();
            int y = w.getY();
            int x2 = x + w.getWidth();
            int y2 = y + w.getHeight();
            g.fill(x, y, x2, y2, 0x99B00000);                 // red wash over the button
            g.fill(x, y, x2, y + 1, 0xFFFF2020);              // bright red outline
            g.fill(x, y2 - 1, x2, y2, 0xFFFF2020);
            g.fill(x, y, x + 1, y2, 0xFFFF2020);
            g.fill(x2 - 1, y, x2, y2, 0xFFFF2020);
        }
    }
}
