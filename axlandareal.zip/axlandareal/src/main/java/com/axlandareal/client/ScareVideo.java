package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.config.AxlConfig;
import com.axlandareal.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Plays a video as a numbered PNG sequence (Minecraft has no video decoder):
 *   assets/axlandareal/textures/gui/video/f_0001.png, f_0002.png, ...  (264x320, 12 fps)
 * with its audio in sounds/scare_video_audio.ogg. If no frames exist (or the player turned
 * the video off in their client config) this class does nothing and the jumpscare skips it.
 */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, value = Dist.CLIENT)
public final class ScareVideo {
    private static final int FPS = 12;
    private static final int FRAME_W = 264;
    private static final int FRAME_H = 320;

    private static int frames = -1;
    private static boolean audioStarted;
    private static int preloadIndex = -1;

    private ScareVideo() {}

    private static ResourceLocation frame(int i) {
        return new ResourceLocation(AxlAndAReal.MODID, String.format("textures/gui/video/f_%04d.png", i));
    }

    private static int frameCount() {
        if (frames < 0) {
            Minecraft mc = Minecraft.getInstance();
            int n = 0;
            while (n < 900 && mc.getResourceManager().getResource(frame(n + 1)).isPresent()) n++;
            frames = n;
        }
        return frames;
    }

    public static boolean enabled() {
        return AxlConfig.CLIENT.scareVideo.get() && frameCount() > 0;
    }

    public static long durationMs() {
        return enabled() ? frameCount() * 1000L / FPS : 0L;
    }

    /** Load a few frames per tick while the player is camera-locked, so playback never stutters. */
    public static void preloadStart() {
        if (enabled()) preloadIndex = 1;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || preloadIndex < 0) return;
        Minecraft mc = Minecraft.getInstance();
        int total = frameCount();
        for (int k = 0; k < 8 && preloadIndex <= total; k++, preloadIndex++) {
            mc.getTextureManager().getTexture(frame(preloadIndex));
        }
        if (preloadIndex > total) preloadIndex = -1;
    }

    public static void begin() {
        audioStarted = false;
    }

    public static void render(GuiGraphics g, int w, int h, long t) {
        Minecraft mc = Minecraft.getInstance();
        if (!audioStarted) {
            audioStarted = true;
            mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.SCARE_VIDEO_AUDIO.get(), 1.0F, 1.0F));
        }
        int i = Mth.clamp((int) (t * FPS / 1000L), 0, frameCount() - 1) + 1;
        ResourceLocation tex = frame(i);
        g.fill(0, 0, w, h, 0xFF000000);

        // dimmed, stretched copy fills the side bars; the sharp frame sits in the middle at its own aspect ratio
        g.setColor(0.28F, 0.05F, 0.05F, 1.0F);
        g.blit(tex, 0, 0, w, h, 0.0F, 0.0F, FRAME_W, FRAME_H, FRAME_W, FRAME_H);
        g.setColor(1.0F, 1.0F, 1.0F, 1.0F);

        float scale = Math.min(w / (float) FRAME_W, h / (float) FRAME_H);
        int dw = (int) (FRAME_W * scale);
        int dh = (int) (FRAME_H * scale);
        g.blit(tex, (w - dw) / 2, (h - dh) / 2, dw, dh, 0.0F, 0.0F, FRAME_W, FRAME_H, FRAME_W, FRAME_H);
    }

    /** Removes the video from the screen and frees its textures. */
    public static void finish() {
        preloadIndex = -1;
        if (frames <= 0) return;
        Minecraft mc = Minecraft.getInstance();
        for (int i = 1; i <= frames; i++) mc.getTextureManager().release(frame(i));
    }
}
