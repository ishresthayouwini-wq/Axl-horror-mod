package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeSpecialEffects;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

/**
 * All water turns red for 20 s, for this player only. The client's own copy of every biome's
 * water colour is patched (found by value, so no obfuscated field names are needed) and
 * restored afterwards. Fails safe: any error just means no effect.
 */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, value = Dist.CLIENT)
public final class RedWater {
    private static final int WATER_RED = 0xA00000;
    private static final int FOG_RED = 0x400000;
    private static final long DURATION_MS = 20000L;

    private record Change(Object target, Field field, int oldValue) {}

    private static final List<Change> CHANGES = new ArrayList<>();
    private static long endMs;

    private RedWater() {}

    public static void start() {
        start(DURATION_MS);
    }

    public static void start(long durationMs) {
        if (!CHANGES.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        try {
            Registry<Biome> biomes = mc.level.registryAccess().registryOrThrow(Registries.BIOME);
            for (Biome biome : biomes) {
                BiomeSpecialEffects fx = biome.getSpecialEffects();
                patch(fx, fx.getWaterColor(), WATER_RED);
                patch(fx, fx.getWaterFogColor(), FOG_RED);
            }
            refresh(mc);
            endMs = Util.getMillis() + durationMs;
        } catch (Exception ex) {
            AxlAndAReal.LOGGER.warn("Red water effect failed", ex);
            stop();
        }
    }

    private static void patch(Object fx, int match, int to) {
        for (Field f : fx.getClass().getDeclaredFields()) {
            if (f.getType() != int.class || Modifier.isStatic(f.getModifiers())) continue;
            try {
                f.setAccessible(true);
                if (f.getInt(fx) == match) {
                    CHANGES.add(new Change(fx, f, match));
                    f.setInt(fx, to);
                }
            } catch (Exception ignored) { }
        }
    }

    public static void stop() {
        for (Change c : CHANGES) {
            try {
                c.field().setInt(c.target(), c.oldValue());
            } catch (Exception ignored) { }
        }
        boolean had = !CHANGES.isEmpty();
        CHANGES.clear();
        Minecraft mc = Minecraft.getInstance();
        if (had && mc.level != null) refresh(mc);
    }

    private static void refresh(Minecraft mc) {
        mc.level.clearTintCaches();
        mc.levelRenderer.allChanged();
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.END && !CHANGES.isEmpty() && Util.getMillis() >= endMs) stop();
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        stop();
    }
}
