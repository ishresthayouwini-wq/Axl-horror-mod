package com.axlandareal.client;

import com.axlandareal.entity.PlayerCloneEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.UUID;

/** Finds the skin of the player a clone is copying. Falls back to the default skin. */
@OnlyIn(Dist.CLIENT)
public final class CloneSkins {
    private CloneSkins() {}

    /** True if the copied player uses the slim (3 px arms) model; the clone then uses the slim model too. */
    public static boolean isSlim(PlayerCloneEntity clone) {
        UUID id = clone.getCloneOf().orElse(null);
        if (id == null) return false;
        ClientPacketListener conn = Minecraft.getInstance().getConnection();
        PlayerInfo info = conn == null ? null : conn.getPlayerInfo(id);
        String model = info != null ? info.getModelName() : DefaultPlayerSkin.getSkinModelName(id);
        return "slim".equals(model);
    }

    public static ResourceLocation skinOf(PlayerCloneEntity clone) {
        UUID id = clone.getCloneOf().orElse(null);
        if (id == null) return DefaultPlayerSkin.getDefaultSkin();
        ClientPacketListener conn = Minecraft.getInstance().getConnection();
        PlayerInfo info = conn == null ? null : conn.getPlayerInfo(id);
        return info != null ? info.getSkinLocation() : DefaultPlayerSkin.getDefaultSkin(id);
    }
}
