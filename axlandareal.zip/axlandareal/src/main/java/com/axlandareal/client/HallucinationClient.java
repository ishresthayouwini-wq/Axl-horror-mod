package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/**
 * Hallucinations are 100% client-side: only the player who receives the packet sees them,
 * nothing changes on the server and nobody else sees anything.
 *
 *  RUSH  (8.5 s): every nearby creature freezes in a T-pose, then runs at you; the screen goes blank red.
 *  EYES  (11 s) : every creature (animals, villagers, other players...) gets glowing red eyes.
 *  STARE (22 s) : animals and villagers turn and stare at you.
 */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, value = Dist.CLIENT)
public final class HallucinationClient {
    public enum Mode { NONE, RUSH, EYES, STARE }

    private static final ResourceLocation PHANTOM_SKIN =
            new ResourceLocation(AxlAndAReal.MODID, "textures/entity/black_figure.png");

    private static final long RUSH_STAND_MS = 1500L;
    private static final long RUSH_RUN_MS = 4000L;
    private static final long RUSH_RED_MS = 3000L;

    private static Mode mode = Mode.NONE;
    private static long startMs;
    private static HumanoidModel<LivingEntity> phantom;

    private HallucinationClient() {}

    private static long customMs;

    public static void start(Mode m) {
        if (mode != Mode.NONE) return;
        mode = m;
        startMs = Util.getMillis();
        customMs = 0L;
    }

    /** Takes over any running hallucination and lasts exactly durationMs. */
    public static void startForced(Mode m, long durationMs) {
        mode = m;
        startMs = Util.getMillis();
        customMs = durationMs;
    }

    private static long duration() {
        if (customMs > 0L) return customMs;
        return switch (mode) {
            case RUSH -> RUSH_STAND_MS + RUSH_RUN_MS + RUSH_RED_MS;
            case EYES -> 11000L;
            case STARE -> 22000L;
            default -> 0L;
        };
    }

    private static boolean running() {
        if (mode == Mode.NONE) return false;
        if (Util.getMillis() - startMs > duration()) {
            mode = Mode.NONE;
            return false;
        }
        return true;
    }

    // ------------------------------------------------------------- RUSH + STARE

    @SubscribeEvent
    public static void onPre(RenderLivingEvent.Pre<?, ?> e) {
        if (!running()) return;
        Minecraft mc = Minecraft.getInstance();
        LivingEntity le = e.getEntity();
        if (mc.player == null || le == mc.player) return;
        long t = Util.getMillis() - startMs;

        if (mode == Mode.RUSH && t < RUSH_STAND_MS + RUSH_RUN_MS) {
            renderTPose(e, le, mc, t);
            e.setCanceled(true);
        } else if (mode == Mode.STARE && (le instanceof Animal || le instanceof AbstractVillager)) {
            Vec3 eye = mc.player.getEyePosition(e.getPartialTick());
            Vec3 from = le.getEyePosition(e.getPartialTick());
            double dx = eye.x - from.x;
            double dy = eye.y - from.y;
            double dz = eye.z - from.z;
            float yaw = (float) (Mth.atan2(dz, dx) * 57.29578F) - 90.0F;
            float pitch = (float) -(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 57.29578F);
            le.yHeadRot = yaw;
            le.yHeadRotO = yaw;
            le.yBodyRot = yaw;
            le.yBodyRotO = yaw;
            le.setXRot(pitch);
            le.xRotO = pitch;
        }
    }

    private static void renderTPose(RenderLivingEvent.Pre<?, ?> e, LivingEntity le, Minecraft mc, long t) {
        if (phantom == null) {
            phantom = new HumanoidModel<>(mc.getEntityModels().bakeLayer(ModelLayers.PLAYER));
        }
        float pt = e.getPartialTick();
        PoseStack ps = e.getPoseStack();

        Vec3 toPlayer = mc.player.getPosition(pt).subtract(le.getPosition(pt));
        double dist = Math.sqrt(toPlayer.x * toPlayer.x + toPlayer.z * toPlayer.z);
        float prog = (float) Mth.clamp((t - RUSH_STAND_MS) / (double) RUSH_RUN_MS, 0.0D, 1.0D);
        float variance = 0.85F + 0.15F * ((le.getId() % 7) / 6.0F);
        double travel = dist > 1.5D ? (dist - 1.5D) / dist * prog * variance : 0.0D;

        ps.pushPose();
        ps.translate(toPlayer.x * travel, 0.0D, toPlayer.z * travel);

        float body = prog > 0.0F
                ? (float) (Mth.atan2(toPlayer.z, toPlayer.x) * 57.29578F) - 90.0F
                : Mth.rotLerp(pt, le.yBodyRotO, le.yBodyRot);
        ps.mulPose(Axis.YP.rotationDegrees(180.0F - body));

        float s = Mth.clamp(le.getBbHeight() / 1.8F, 0.6F, 1.3F);
        ps.scale(s, s, s);
        ps.scale(-1.0F, -1.0F, 1.0F);
        ps.translate(0.0D, -1.501D, 0.0D);

        HumanoidModel<LivingEntity> m = phantom;
        m.young = false;
        m.riding = false;
        m.crouching = false;
        m.attackTime = 0.0F;
        m.head.xRot = 0.0F;
        m.head.yRot = 0.0F;
        m.head.zRot = 0.0F;
        m.hat.copyFrom(m.head);
        m.rightArm.xRot = 0.0F;
        m.rightArm.yRot = 0.0F;
        m.rightArm.zRot = (float) (Math.PI / 2.0D);
        m.leftArm.xRot = 0.0F;
        m.leftArm.yRot = 0.0F;
        m.leftArm.zRot = (float) (-Math.PI / 2.0D);
        float run = (le.tickCount + pt) * 1.1F;
        boolean moving = prog > 0.0F;
        m.rightLeg.xRot = moving ? Mth.cos(run) * 1.3F : 0.0F;
        m.leftLeg.xRot = moving ? -Mth.cos(run) * 1.3F : 0.0F;

        VertexConsumer vc = e.getMultiBufferSource().getBuffer(RenderType.entityCutoutNoCull(PHANTOM_SKIN));
        m.renderToBuffer(ps, vc, e.getPackedLight(), OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
        ps.popPose();
    }

    // -------------------------------------------------------------------- EYES

    @SubscribeEvent
    public static void onPost(RenderLivingEvent.Post<?, ?> e) {
        if (mode != Mode.EYES || !running()) return;
        Minecraft mc = Minecraft.getInstance();
        LivingEntity le = e.getEntity();
        if (le == mc.player) return;

        float pt = e.getPartialTick();
        PoseStack ps = e.getPoseStack();
        double rad = Math.toRadians(Mth.rotLerp(pt, le.yHeadRotO, le.yHeadRot));
        double fx = -Math.sin(rad);
        double fz = Math.cos(rad);
        double rx = Math.cos(rad);
        double rz = Math.sin(rad);
        float w = le.getBbWidth();
        double fwd = w * 0.5D + 0.02D;
        double side = Math.max(0.07D, w * 0.14D);
        float size = Math.max(0.035F, w * 0.06F);

        VertexConsumer vc = e.getMultiBufferSource().getBuffer(RenderType.lightning());
        for (int s = -1; s <= 1; s += 2) {
            ps.pushPose();
            ps.translate(fx * fwd + rx * side * s, le.getEyeHeight(), fz * fwd + rz * side * s);
            ps.mulPose(mc.getEntityRenderDispatcher().cameraOrientation());
            quad(vc, ps.last().pose(), size);
            ps.popPose();
        }
    }

    /** Flat red billboard quad, emitted with both windings so culling can't hide it. */
    private static void quad(VertexConsumer vc, Matrix4f m, float s) {
        float h = s * 0.6F;
        vc.vertex(m, -s, -h, 0).color(255, 0, 0, 255).endVertex();
        vc.vertex(m, -s, h, 0).color(255, 0, 0, 255).endVertex();
        vc.vertex(m, s, h, 0).color(255, 0, 0, 255).endVertex();
        vc.vertex(m, s, -h, 0).color(255, 0, 0, 255).endVertex();
        vc.vertex(m, s, -h, 0).color(255, 0, 0, 255).endVertex();
        vc.vertex(m, s, h, 0).color(255, 0, 0, 255).endVertex();
        vc.vertex(m, -s, h, 0).color(255, 0, 0, 255).endVertex();
        vc.vertex(m, -s, -h, 0).color(255, 0, 0, 255).endVertex();
    }

    // ------------------------------------------------------------ red screen

    /** Rush finale: the whole screen goes blank red (no potion effects, nothing else). */
    public static void renderOverlay(GuiGraphics g, int w, int h) {
        if (mode != Mode.RUSH || !running()) return;
        long t = Util.getMillis() - startMs;
        long redStart = RUSH_STAND_MS + RUSH_RUN_MS;
        if (t < redStart) return;
        float fadeOut = Math.min(1.0F, (duration() - t) / 500.0F);
        int alpha = Mth.clamp((int) (255 * fadeOut), 0, 255);
        g.fill(0, 0, w, h, (alpha << 24) | 0x8B0000);
    }
}
