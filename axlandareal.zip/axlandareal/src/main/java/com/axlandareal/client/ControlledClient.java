package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.registry.ModSounds;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

/**
 * The "controlled" symptom, client side. For the duration the player cannot steer: their character
 * walks and sprints by itself toward the nearest living thing (mobs, animals, villagers, other players),
 * turns to face it and attacks it over and over. With nothing near, it wanders. Menus are closed and
 * the player's own movement, jump and use/attack keys are ignored. Creepy music plays.
 * The server keeps the player immortal until it ends.
 */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, value = Dist.CLIENT)
public final class ControlledClient {
    private static boolean active;
    private static long endMs;
    private static long nextAttackMs;
    private static long nextWanderMs;
    private static float wanderYaw;
    private static int retargetTicks;
    private static LivingEntity target;

    private ControlledClient() {}

    public static boolean active() {
        return active;
    }

    public static void start(long durationMs) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || active) return;
        active = true;
        endMs = Util.getMillis() + durationMs;
        target = null;
        retargetTicks = 0;
        wanderYaw = mc.player.getYRot();
        mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.CONTROL_MUSIC.get(), 1.0F, 1.0F));
    }

    public static void stop() {
        if (!active) return;
        active = false;
        target = null;
        Minecraft.getInstance().getSoundManager().stop(ModSounds.CONTROL_MUSIC.get().getLocation(), null);
    }

    private static LivingEntity nearest(Minecraft mc, Player me) {
        List<LivingEntity> list = mc.level.getEntitiesOfClass(LivingEntity.class, me.getBoundingBox().inflate(32.0D),
                e -> e != me && e.isAlive() && !(e instanceof ArmorStand) && !e.isSpectator()
                        && !(e instanceof Player p && (p.isCreative() || p.isSpectator())));
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : list) {
            double d = e.distanceToSqr(me);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !active) return;
        Minecraft mc = Minecraft.getInstance();
        Player me = mc.player;
        if (me == null || mc.level == null || mc.gameMode == null) {
            stop();
            return;
        }
        long now = Util.getMillis();
        if (now >= endMs) {
            stop();
            return;
        }
        if (mc.screen != null) mc.setScreen(null);   // no inventory, chat or menus while controlled

        if (--retargetTicks <= 0) {
            retargetTicks = 10;
            target = nearest(mc, me);
        }

        if (target != null && target.isAlive()) {
            if (me.distanceTo(target) < 3.0F && me.getAttackStrengthScale(0.5F) >= 0.95F && now >= nextAttackMs) {
                mc.gameMode.attack(me, target);
                me.swing(InteractionHand.MAIN_HAND);
                nextAttackMs = now + 120L;
            }
        } else if (now >= nextWanderMs) {
            nextWanderMs = now + 1500L;
            wanderYaw += (me.getRandom().nextFloat() - 0.5F) * 120.0F;
        }
        if (me.horizontalCollision && (target == null || !target.isAlive())) wanderYaw += 90.0F;
        me.setSprinting(true);
    }

    /** The character turns to face its target every frame; the player's mouse is ignored. */
    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase != TickEvent.Phase.START || !active) return;
        Minecraft mc = Minecraft.getInstance();
        Player me = mc.player;
        if (me == null) return;

        float yaw = wanderYaw;
        float pitch = 0.0F;
        if (target != null && target.isAlive()) {
            Vec3 from = me.getEyePosition(e.renderTickTime);
            Vec3 to = target.getPosition(e.renderTickTime).add(0.0D, target.getBbHeight() * 0.5D, 0.0D);
            double dx = to.x - from.x;
            double dy = to.y - from.y;
            double dz = to.z - from.z;
            yaw = (float) (Mth.atan2(dz, dx) * 57.29578F) - 90.0F;
            pitch = (float) -(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 57.29578F);
        }
        float newYaw = Mth.rotLerp(0.3F, me.getYRot(), yaw);
        float newPitch = Mth.clamp(Mth.lerp(0.3F, me.getXRot(), pitch), -90.0F, 90.0F);
        me.setYRot(newYaw);
        me.setXRot(newPitch);
        me.yRotO = newYaw;
        me.xRotO = newPitch;
    }

    /** Overrides the keys: always walking forward, stopping only to fight, jumping over obstacles. */
    @SubscribeEvent
    public static void onMove(MovementInputUpdateEvent e) {
        if (!active) return;
        Input in = e.getInput();
        Player me = e.getEntity();
        boolean fighting = target != null && target.isAlive() && me.distanceTo(target) < 1.6F;

        in.up = !fighting;
        in.down = false;
        in.left = false;
        in.right = false;
        in.forwardImpulse = fighting ? 0.0F : 1.0F;
        in.leftImpulse = 0.0F;
        in.shiftKeyDown = false;
        in.jumping = (me.horizontalCollision && me.onGround()) || me.isInWater() || me.isInLava();
    }

    @SubscribeEvent
    public static void onInteract(InputEvent.InteractionKeyMappingTriggered e) {
        if (!active) return;
        e.setCanceled(true);
        e.setSwingHand(false);
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        stop();
    }
}
