package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.config.AxlConfig;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.material.FogType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * The mod's heavy fog, a whole-game graphics change (client-side, per player):
 *  - BASE:  always on, in every dimension, with or without any entity nearby. Visibility is
 *           limited to "fogDistance" blocks (default 36) and the fog is a dark grey-red.
 *  - EVENT: a "fog bank" haunt event that fades in over 5 s, holds, fades out over 8 s and
 *           closes visibility down to 14 blocks.
 * Fog is only ever made thicker than vanilla (Blindness, Nether fog etc. are respected), and
 * underwater / lava fog is left alone. Turn the base fog off with permanentFog in the client config.
 */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, value = Dist.CLIENT)
public final class HeavyFog {
    private static final float EVENT_FAR = 14.0F;
    private static final float BASE_COLOR_MIX = 0.75F;

    private static long eventStartMs;
    private static long eventDurationMs;
    private static float base;    // 0..1, eased
    private static float event;   // 0..1, eased

    private HeavyFog() {}

    /** Roll in a fog bank for the given time (haunt event). */
    public static void start(long durationMs) {
        eventStartMs = Util.getMillis();
        eventDurationMs = durationMs;
    }

    private static float eventTarget() {
        long t = Util.getMillis() - eventStartMs;
        if (eventDurationMs <= 0L || t < 0L || t > eventDurationMs) return 0.0F;
        float in = Math.min(1.0F, t / 5000.0F);
        float out = Math.min(1.0F, (eventDurationMs - t) / 8000.0F);
        return Math.min(in, out);
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        boolean enabled = mc.player != null && mc.level != null && AxlConfig.CLIENT.visualEffects.get();
        float baseTarget = enabled && AxlConfig.CLIENT.permanentFog.get() && !EnvironmentChange.active() ? 1.0F : 0.0F;   // paused during an environment change
        float eventTarget = enabled ? eventTarget() : 0.0F;
        base += (baseTarget - base) * 0.05F;
        event += (eventTarget - event) * 0.1F;
        if (base < 0.005F) base = 0.0F;
        if (event < 0.005F) event = 0.0F;
    }

    @SubscribeEvent
    public static void onRenderFog(ViewportEvent.RenderFog e) {
        if ((base <= 0.0F && event <= 0.0F) || e.getMode() != FogRenderer.FogMode.FOG_TERRAIN) return;
        if (e.getCamera().getFluidInCamera() != FogType.NONE) return;

        float far = e.getFarPlaneDistance();
        float near = e.getNearPlaneDistance();

        if (base > 0.0F) {
            float baseFar = Math.min(far, AxlConfig.CLIENT.fogDistance.get());
            far = Mth.lerp(base, far, baseFar);
            near = Mth.lerp(base, near, Math.min(near, baseFar * 0.12F));
        }
        if (event > 0.0F) {
            far = Mth.lerp(event, far, Math.min(far, EVENT_FAR));
            near = Mth.lerp(event, near, 0.0F);
        }
        e.setFarPlaneDistance(far);
        e.setNearPlaneDistance(Math.min(near, far - 1.0F));
        e.setCanceled(true);   // Forge only applies custom values when the event is cancelled
    }

    /** Dark grey-red fog that keeps the brightness of the current sky, so night stays dark. */
    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor e) {
        if ((base <= 0.0F && event <= 0.0F) || e.getCamera().getFluidInCamera() != FogType.NONE) return;
        float mix = Math.max(base * BASE_COLOR_MIX, event);
        float lum = (e.getRed() + e.getGreen() + e.getBlue()) / 3.0F;
        float tr = lum * 0.55F;
        float tg = lum * 0.48F;
        float tb = lum * 0.48F;
        e.setRed(Mth.lerp(mix, e.getRed(), tr));
        e.setGreen(Mth.lerp(mix, e.getGreen(), tg));
        e.setBlue(Mth.lerp(mix, e.getBlue(), tb));
    }
}
