package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.registry.ModSounds;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.resources.sounds.AbstractSoundInstance;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * The two server-wide environment changes (every player gets them at the same moment, one at a time):
 *
 *  BLACK_WHITE (rare, 76 s = 1.27 minutes): the whole picture goes black and white, every normal game sound
 *      drops to half speed with a reversed, slowed ambience underneath, and every animal and villager stares at you.
 *  RETRO (common, 32 s): the picture becomes an old low-resolution display (about 240 lines, limited colours,
 *      scanlines) and the retro game settings are held on (fast graphics, flat light, short view distance).
 *
 * Both use their own post-processing shader (assets/minecraft/shaders/post/axl_*.json). If a shader can't load,
 * black-and-white falls back to a grey overlay; retro still has its game settings and scanlines.
 */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, value = Dist.CLIENT)
public final class EnvironmentChange {

    public enum Kind {
        BLACK_WHITE("axl_grayscale", 76000L),
        RETRO("axl_retro", 32000L);

        final ResourceLocation chain;
        final long defaultMs;

        Kind(String shader, long defaultMs) {
            this.chain = new ResourceLocation("minecraft", "shaders/post/" + shader + ".json");
            this.defaultMs = defaultMs;
        }

        public long defaultMs() {
            return defaultMs;
        }
    }

    private static final long AMBIENCE_MS = 24000L;

    private static boolean active;
    private static Kind kind = Kind.BLACK_WHITE;
    private static long startMs;
    private static long endMs;
    private static long nextAmbienceMs;
    private static PostChain chain;
    private static boolean chainFailed;
    private static int chainW, chainH;

    private EnvironmentChange() {}

    public static boolean active() {
        return active;
    }

    public static void start(Kind k, long durationMs) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || active) return;
        active = true;
        kind = k;
        chainFailed = false;
        long now = Util.getMillis();
        startMs = now;
        endMs = now + durationMs;

        if (k == Kind.BLACK_WHITE) {
            nextAmbienceMs = now + AMBIENCE_MS;
            HallucinationClient.startForced(HallucinationClient.Mode.STARE, durationMs);
            mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.ENVIRONMENT_REVERSE.get(), 1.0F, 1.0F));
            playAmbience();
        } else {
            RetroEffect.startManaged();   // fast graphics, flat light, short view distance, scanlines
            RedWater.start(durationMs);   // the water runs red
            HallucinationClient.startForced(HallucinationClient.Mode.STARE, durationMs);   // everything stares (the server freezes it)
            mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.STATIC_BURST.get(), 1.0F, 0.8F));
            mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.RETRO_MUSIC.get(), 1.0F, 1.0F));   // retro chiptune soundtrack
        }
    }

    public static void stop(boolean withSound) {
        if (!active) return;
        active = false;
        if (kind == Kind.RETRO) {
            RetroEffect.stopManaged();
            RedWater.stop();
            Minecraft.getInstance().getSoundManager().stop(ModSounds.RETRO_MUSIC.get().getLocation(), null);
        }
        closeChain();
        if (withSound) {
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.DISTORTED.get(), 1.0F, 1.0F));
        }
    }

    private static void playAmbience() {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.ENV_AMBIENCE.get(), 1.0F, 0.9F));
    }

    private static void closeChain() {
        if (chain != null) {
            chain.close();
            chain = null;
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !active) return;
        long now = Util.getMillis();
        if (now >= endMs) {
            stop(true);
        } else if (kind == Kind.BLACK_WHITE && now >= nextAmbienceMs) {
            nextAmbienceMs = now + AMBIENCE_MS;
            playAmbience();
        }
    }

    /** Runs the shader exactly where vanilla runs its own post effects: after the world, before the HUD. */
    @SubscribeEvent
    public static void onGuiPre(RenderGuiEvent.Pre e) {
        if (!active || chainFailed) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        try {
            int w = mc.getWindow().getWidth();
            int h = mc.getWindow().getHeight();
            if (chain == null) {
                chain = new PostChain(mc.getTextureManager(), mc.getResourceManager(), mc.getMainRenderTarget(), kind.chain);
                chain.resize(w, h);
                chainW = w;
                chainH = h;
            } else if (w != chainW || h != chainH) {
                chain.resize(w, h);
                chainW = w;
                chainH = h;
            }
            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.resetTextureMatrix();
            chain.process(e.getPartialTick());
            mc.getMainRenderTarget().bindWrite(true);
        } catch (Exception ex) {
            AxlAndAReal.LOGGER.warn("Environment shader failed to load, using the fallback look", ex);
            chainFailed = true;
            closeChain();
        }
    }

    /** Only used if the black-and-white shader could not be loaded. */
    public static void renderOverlay(GuiGraphics g, int w, int h) {
        if (!active) return;
        if (kind == Kind.BLACK_WHITE) {
            if (chainFailed) g.fill(0, 0, w, h, 0x80707070);
            return;
        }
        // RETRO: blood everywhere: a red cast over the screen and blood running down from the top
        float p = Mth.clamp((Util.getMillis() - startMs) / 8000.0F, 0.0F, 1.0F);
        g.fill(0, 0, w, h, 0x22A00000);
        RandomSource dr = RandomSource.create(77L);
        for (int i = 0; i < 26; i++) {
            int dx = dr.nextInt(Math.max(1, w));
            int dw = 2 + dr.nextInt(5);
            float speed = 0.3F + dr.nextFloat() * 0.7F;
            int len = (int) (h * Mth.clamp(p * speed * 1.1F + 0.03F, 0.0F, 0.8F));
            g.fill(dx, 0, dx + dw, len, 0xCC8A0808);
            g.fill(dx - 1, len, dx + dw + 1, len + 5, 0xCC8A0808);
        }
    }

    /**
     * Black-and-white change only: slows every normal game sound to half speed. (Minecraft's sound engine can't
     * play its own sounds backwards, so the reversed part is the ambience loop.) Moving sounds such as minecarts
     * and this mod's own sounds are left alone.
     */
    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent e) {
        if (!active || kind != Kind.BLACK_WHITE) return;
        SoundInstance s = e.getSound();
        if (!(s instanceof SimpleSoundInstance)) return;
        if (AxlAndAReal.MODID.equals(s.getLocation().getNamespace())) return;
        e.setSound(new SlowedSound(s, Mth.clamp(s.getPitch() * 0.5F, 0.5F, 2.0F)));
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        stop(false);
    }

    /** Copy of a sound with a lower pitch. */
    private static final class SlowedSound extends AbstractSoundInstance {
        SlowedSound(SoundInstance o, float pitch) {
            super(o.getLocation(), o.getSource(), RandomSource.create());
            this.volume = o.getVolume();
            this.pitch = pitch;
            this.x = o.getX();
            this.y = o.getY();
            this.z = o.getZ();
            this.looping = o.isLooping();
            this.delay = o.getDelay();
            this.attenuation = o.getAttenuation();
            this.relative = o.isRelative();
        }
    }
}
