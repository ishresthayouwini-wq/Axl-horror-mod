package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.config.AxlConfig;
import net.minecraft.Util;
import net.minecraft.util.RandomSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Camera effects for the jumpscares: violent shake (yaw/pitch/roll) and an FOV punch.
 * Both are switched off completely by "reduceFlashing" in the client config.
 */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, value = Dist.CLIENT)
public final class ScareFx {
    private static long shakeStart, shakeDur, fovStart, fovDur;
    private static float shakeStrength, fovAmount;

    private ScareFx() {}

    private static boolean calm() {
        return AxlConfig.CLIENT.reduceFlashing.get();
    }

    /** strength 1.0 = strong. Full strength for 70% of the time, then fades out. */
    public static void shake(float strength, long durationMs) {
        if (calm()) return;
        shakeStrength = strength;
        shakeStart = Util.getMillis();
        shakeDur = durationMs;
    }

    /** Widen (positive) or narrow (negative) the field of view, easing back to normal. */
    public static void fovPunch(float degrees, long durationMs) {
        if (calm()) return;
        fovAmount = degrees;
        fovStart = Util.getMillis();
        fovDur = durationMs;
    }

    private static float level(long start, long dur, boolean sustain) {
        long t = Util.getMillis() - start;
        if (dur <= 0L || t < 0L || t > dur) return 0.0F;
        float p = t / (float) dur;
        if (!sustain) return 1.0F - p;
        return p < 0.7F ? 1.0F : 1.0F - (p - 0.7F) / 0.3F;
    }

    @SubscribeEvent
    public static void onAngles(ViewportEvent.ComputeCameraAngles e) {
        float s = shakeStrength * level(shakeStart, shakeDur, true);
        if (s <= 0.001F) return;
        RandomSource r = RandomSource.create(Util.getMillis() / 16L);
        e.setYaw(e.getYaw() + (r.nextFloat() - 0.5F) * 6.0F * s);
        e.setPitch(e.getPitch() + (r.nextFloat() - 0.5F) * 5.0F * s);
        e.setRoll(e.getRoll() + (r.nextFloat() - 0.5F) * 10.0F * s);
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov e) {
        float l = level(fovStart, fovDur, false);
        if (l <= 0.001F) return;
        e.setFOV(e.getFOV() + fovAmount * l);
    }
}
