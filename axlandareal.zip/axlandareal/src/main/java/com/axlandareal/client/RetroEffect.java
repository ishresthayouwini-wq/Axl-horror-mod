package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.registry.ModSounds;
import net.minecraft.Util;
import net.minecraft.client.AmbientOcclusionStatus;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 6 seconds of "old Minecraft": fast graphics, flat lighting, no biome blending, short
 * render distance (fog closes in), no shadows, plus scanlines. Settings are put back
 * exactly as they were afterwards, followed by a distorted sound.
 */
@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, value = Dist.CLIENT)
public final class RetroEffect {
    private static final long DURATION_MS = 6000L;

    private static boolean active;
    private static boolean managed;   // held on by the environment change
    private static long endMs;
    private static GraphicsStatus oldGraphics;
    private static AmbientOcclusionStatus oldAo;
    private static int oldRenderDistance;
    private static int oldBlend;
    private static boolean oldShadows;

    private RetroEffect() {}

    public static boolean active() {
        return active;
    }

    public static void start() {
        if (active) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;

        oldGraphics = mc.options.graphicsMode().get();
        oldAo = mc.options.ambientOcclusion().get();
        oldRenderDistance = mc.options.renderDistance().get();
        oldBlend = mc.options.biomeBlendRadius().get();
        oldShadows = mc.options.entityShadows().get();

        mc.options.graphicsMode().set(GraphicsStatus.FAST);
        mc.options.ambientOcclusion().set(AmbientOcclusionStatus.OFF);
        mc.options.biomeBlendRadius().set(0);
        mc.options.entityShadows().set(false);
        mc.options.renderDistance().set(Math.min(oldRenderDistance, 4));
        mc.levelRenderer.allChanged();

        active = true;
        endMs = Util.getMillis() + DURATION_MS;
    }

    /** Environment change: switch retro on and keep it on until stopManaged(). */
    public static void startManaged() {
        start();
        if (!active) return;
        managed = true;
        endMs = Long.MAX_VALUE;
    }

    public static void stopManaged() {
        if (!managed) return;
        stop(false);
    }

    public static void stop(boolean withSound) {
        if (!active) return;
        active = false;
        managed = false;
        Minecraft mc = Minecraft.getInstance();

        mc.options.graphicsMode().set(oldGraphics);
        mc.options.ambientOcclusion().set(oldAo);
        mc.options.biomeBlendRadius().set(oldBlend);
        mc.options.entityShadows().set(oldShadows);
        mc.options.renderDistance().set(oldRenderDistance);
        if (mc.levelRenderer != null) mc.levelRenderer.allChanged();

        if (withSound) {
            mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.DISTORTED.get(), 1.0F, 1.0F));
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.END && active && !managed && Util.getMillis() >= endMs) stop(true);
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        stop(false);
    }

    /** Scanlines + a dark frame; called from HauntOverlay. */
    public static void renderOverlay(GuiGraphics g, int w, int h) {
        if (!active) return;
        for (int y = 0; y < h; y += 3) g.fill(0, y, w, y + 1, 0x22000000);
        g.fill(0, 0, w, h / 14, 0x44000000);
        g.fill(0, h - h / 14, w, h, 0x44000000);
    }
}
