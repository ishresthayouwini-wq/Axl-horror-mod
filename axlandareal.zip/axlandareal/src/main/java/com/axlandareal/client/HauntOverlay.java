package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.config.AxlConfig;
import com.axlandareal.registry.ModSounds;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.gui.overlay.ForgeGui;

import java.util.ArrayList;
import java.util.List;

/**
 * Full-screen scares, drawn above the HUD by a Forge GUI overlay.
 *
 *  HELP  : red tint + glitching "Help me brother", exactly 6000 ms.
 *  STEVE : 7000 ms fade-to-black, then Tall Steve's face + sting for ~1.4 s.
 *  Floating red text: short flickering phrases at random screen positions.
 *
 * Timing uses wall-clock millis (Util.getMillis) so durations are exact
 * regardless of frame rate. Loudness of the sting must be baked into the .ogg;
 * this code never touches the player's volume sliders.
 */
@OnlyIn(Dist.CLIENT)
public final class HauntOverlay {
    private static final ResourceLocation TALL_STEVE_FACE =
            new ResourceLocation(AxlAndAReal.MODID, "textures/gui/tall_steve_face.png");

    private static final long HELP_MS = 6000L;
    private static final long BLACKOUT_MS = 7000L;
    private static final long FACE_MS = 1400L;
    private static final String GLITCH_CHARS = "#%&@$?!/\\|<>~";

    private enum Mode { NONE, HELP, STEVE }

    private static Mode mode = Mode.NONE;
    private static long startMs;
    private static boolean stingPlayed;

    private record FloatingText(String text, long startMs, long durationMs, float fx, float fy, float scale) {}
    private static final List<FloatingText> FLOATING = new ArrayList<>();

    private HauntOverlay() {}

    // ------------------------------------------------------------- triggers

    public static void startHelp() {
        if (mode != Mode.NONE) return;
        mode = Mode.HELP;
        startMs = Util.getMillis();
    }

    public static void startSteve() {
        if (mode != Mode.NONE) return;
        mode = Mode.STEVE;
        startMs = Util.getMillis();
        stingPlayed = false;
    }

    public static void addFloatingText(String text) {
        RandomSource r = RandomSource.create();
        FLOATING.add(new FloatingText(text, Util.getMillis(), 600 + r.nextInt(900),
                0.08F + r.nextFloat() * 0.55F, 0.10F + r.nextFloat() * 0.70F, 2.0F + r.nextFloat() * 2.0F));
    }

    // --------------------------------------------------------------- render

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        renderFloatingTexts(g, w, h);
        switch (mode) {
            case HELP -> renderHelp(g, w, h);
            case STEVE -> renderSteve(g, w, h);
            default -> { }
        }
    }

    private static void renderHelp(GuiGraphics g, int w, int h) {
        long t = Util.getMillis() - startMs;
        if (t >= HELP_MS) { mode = Mode.NONE; return; }

        boolean calm = AxlConfig.CLIENT.reduceFlashing.get();
        RandomSource r = RandomSource.create(Util.getMillis() / 50L); // new glitch pattern 20x/second
        Font font = Minecraft.getInstance().font;

        float edge = Math.min(1.0F, Math.min(t, HELP_MS - t) / 250.0F);       // soft in/out
        float pulse = calm ? 0.6F : 0.55F + 0.15F * Mth.sin(t / 120.0F);
        int alpha = Mth.clamp((int) (255 * pulse * edge), 0, 255);
        g.fill(0, 0, w, h, (alpha << 24) | 0x8B0000);

        if (!calm) {
            for (int y = 0; y < h; y += 4) {
                if (r.nextInt(6) == 0) g.fill(0, y, w, y + 1 + r.nextInt(3), 0x66000000);
            }
        }

        String msg = calm ? "Help me brother" : glitch("Help me brother", r);
        int jx = calm ? 0 : r.nextInt(5) - 2;
        int jy = calm ? 0 : r.nextInt(5) - 2;
        int tw = font.width(msg);

        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(w / 2.0F, h / 2.0F, 0.0F);
        ps.scale(4.0F, 4.0F, 1.0F);
        int x = -tw / 2 + jx;
        int y = -4 + jy;
        if (!calm) {                                  // chromatic split
            g.drawString(font, msg, x - 2, y, 0xAA00FFFF, false);
            g.drawString(font, msg, x + 2, y, 0xAAFF0000, false);
        }
        g.drawString(font, msg, x, y, 0xFFFFFFFF, false);
        ps.popPose();
    }

    private static void renderSteve(GuiGraphics g, int w, int h) {
        long t = Util.getMillis() - startMs;

        if (t < BLACKOUT_MS) {
            float a = Math.min(1.0F, t / 1500.0F);    // fade in over 1.5 s, then hold full black
            g.fill(0, 0, w, h, ((int) (a * 255) << 24));
            return;
        }

        long f = t - BLACKOUT_MS;
        if (f >= FACE_MS) { mode = Mode.NONE; return; }

        if (!stingPlayed) {
            stingPlayed = true;
            Minecraft.getInstance().getSoundManager()
                    .play(SimpleSoundInstance.forUI(ModSounds.TALL_STEVE_STING.get(), 1.0F, 1.0F));
        }

        boolean calm = AxlConfig.CLIENT.reduceFlashing.get();
        g.fill(0, 0, w, h, 0xFF000000);

        RandomSource r = RandomSource.create(Util.getMillis() / 40L);
        float lunge = 1.0F + 0.25F * (f / (float) FACE_MS);       // face slowly lunges at the camera
        int size = (int) (h * lunge);
        int sx = calm ? 0 : r.nextInt(13) - 6;
        int sy = calm ? 0 : r.nextInt(13) - 6;

        RenderSystem.enableBlend();
        g.blit(TALL_STEVE_FACE, (w - size) / 2 + sx, (h - size) / 2 + sy, size, size,
                0.0F, 0.0F, 512, 512, 512, 512);
        if (!calm && (f / 60) % 2 == 0) g.fill(0, 0, w, h, 0x33FF0000);
        RenderSystem.disableBlend();
    }

    private static void renderFloatingTexts(GuiGraphics g, int w, int h) {
        if (FLOATING.isEmpty()) return;
        long now = Util.getMillis();
        boolean calm = AxlConfig.CLIENT.reduceFlashing.get();
        Font font = Minecraft.getInstance().font;

        FLOATING.removeIf(f -> now - f.startMs() > f.durationMs());
        for (FloatingText f : FLOATING) {
            long t = now - f.startMs();
            if (!calm && (t / 70) % 4 == 0) continue;               // flicker off-frames

            float fade = Math.min(1.0F, (f.durationMs() - t) / 200.0F);
            int alpha = (int) (255 * Mth.clamp(fade, 0.0F, 1.0F));
            if (alpha < 8) continue;                                // font treats tiny alpha as opaque

            RandomSource r = RandomSource.create(f.startMs() + t / 60);
            float jx = calm ? 0 : (r.nextFloat() - 0.5F) * 6.0F;
            float jy = calm ? 0 : (r.nextFloat() - 0.5F) * 6.0F;
            float x = Math.min(w * f.fx(), w - font.width(f.text()) * f.scale() - 4.0F);

            PoseStack ps = g.pose();
            ps.pushPose();
            ps.translate(Math.max(4.0F, x) + jx, h * f.fy() + jy, 0.0F);
            ps.scale(f.scale(), f.scale(), 1.0F);
            g.drawString(font, f.text(), 0, 0, (alpha << 24) | 0xCC0000, false);
            ps.popPose();
        }
    }

    private static String glitch(String s, RandomSource r) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c != ' ' && r.nextInt(14) == 0) sb.append(GLITCH_CHARS.charAt(r.nextInt(GLITCH_CHARS.length())));
            else sb.append(c);
        }
        return sb.toString();
    }
}
