package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.config.AxlConfig;
import com.axlandareal.registry.ModSounds;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.gui.overlay.ForgeGui;

import java.util.ArrayList;
import java.util.List;

/**
 * Full-screen scares, drawn above the HUD by a Forge GUI overlay.
 *
 *  HELP  : red tint + glitching "Help me brother" + sting + heartbeat + shake, exactly 6000 ms.
 *  STEVE : 7000 ms blackout with a rising heartbeat and 5 subliminal face flashes, then a
 *          violently distorted, bleeding Tall Steve face lunging at you, with camera shake.
 *  AXL   : Axl's distorted face + scream, then the scare video (if present), then a distorted sound.
 * Floating red text, retro scanlines and the hallucination red screen are drawn here too.
 *
 * Timing uses wall-clock millis so durations are exact regardless of frame rate. Loudness must be
 * baked into the .ogg files; this code never touches volume sliders. "reduceFlashing" removes
 * strobing, subliminal flashes, shake, drips and tearing.
 */
@OnlyIn(Dist.CLIENT)
public final class HauntOverlay {
    private static final ResourceLocation TALL_STEVE_FACE =
            new ResourceLocation(AxlAndAReal.MODID, "textures/gui/tall_steve_face.png");
    private static final ResourceLocation AXL_FACE =
            new ResourceLocation(AxlAndAReal.MODID, "textures/gui/axl_face.png");

    private static final long HELP_MS = 6000L;
    private static final long BLACKOUT_MS = 7000L;
    private static final long FACE_MS = 4000L;
    private static final long AXL_FACE_MS = 2200L;
    private static final long[] FLASH_AT = {2600L, 4300L, 5600L, 6400L, 6800L};
    private static final long FLASH_MS = 80L;
    private static final String GLITCH_CHARS = "#%&@$?!/\\|<>~";

    private enum Mode { NONE, HELP, STEVE, AXL }

    private static Mode mode = Mode.NONE;
    private static long startMs;
    private static boolean stingPlayed;
    private static final boolean[] FLASH_PLAYED = new boolean[FLASH_AT.length];

    private record FloatingText(String text, long startMs, long durationMs, float fx, float fy, float scale) {}
    private static final List<FloatingText> FLOATING = new ArrayList<>();

    private HauntOverlay() {}

    private static boolean calm() {
        return AxlConfig.CLIENT.reduceFlashing.get();
    }

    // ------------------------------------------------------------- triggers

    public static boolean axlActive() {
        return mode == Mode.AXL;
    }

    private static void playUi(SoundEvent sound, float volume) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(sound, 1.0F, volume));
    }

    public static void startHelp() {
        if (mode != Mode.NONE) return;
        mode = Mode.HELP;
        startMs = Util.getMillis();
        playUi(ModSounds.HELP_STING.get(), 1.0F);
        Heartbeat.start(HELP_MS, 800L, 420L);
        ScareFx.shake(0.5F, HELP_MS);
    }

    public static void startSteve() {
        if (mode != Mode.NONE) return;
        mode = Mode.STEVE;
        startMs = Util.getMillis();
        stingPlayed = false;
        java.util.Arrays.fill(FLASH_PLAYED, false);
        Heartbeat.start(BLACKOUT_MS, 1000L, 400L);   // gets faster and louder until the face hits
    }

    public static void startAxlFace() {
        if (mode != Mode.NONE && mode != Mode.AXL) {
            CameraLock.release();
            return;
        }
        mode = Mode.AXL;
        startMs = Util.getMillis();
        stingPlayed = false;
        Heartbeat.stop();
        ScareFx.shake(1.4F, AXL_FACE_MS);
        ScareFx.fovPunch(28.0F, 700L);
        ScareVideo.begin();
    }

    public static void addFloatingText(String text) {
        RandomSource r = RandomSource.create();
        FLOATING.add(new FloatingText(text, Util.getMillis(), 600 + r.nextInt(900),
                0.08F + r.nextFloat() * 0.55F, 0.10F + r.nextFloat() * 0.70F, 2.0F + r.nextFloat() * 2.0F));
    }

    // --------------------------------------------------------------- render

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        renderFloatingTexts(g, w, h);
        RetroEffect.renderOverlay(g, w, h);
        EnvironmentChange.renderOverlay(g, w, h);
        HallucinationClient.renderOverlay(g, w, h);
        switch (mode) {
            case HELP -> renderHelp(g, w, h);
            case STEVE -> renderSteve(g, w, h);
            case AXL -> renderAxl(g, w, h);
            default -> { }
        }
    }

    private static void renderHelp(GuiGraphics g, int w, int h) {
        long t = Util.getMillis() - startMs;
        if (t >= HELP_MS) { mode = Mode.NONE; return; }

        boolean calm = calm();
        RandomSource r = RandomSource.create(Util.getMillis() / 50L); // new glitch pattern 20x/second
        Font font = Minecraft.getInstance().font;

        float edge = Math.min(1.0F, Math.min(t, HELP_MS - t) / 250.0F);       // soft in/out
        float pulse = calm ? 0.6F : 0.55F + 0.15F * Mth.sin(t / 120.0F);
        int alpha = Mth.clamp((int) (255 * pulse * edge), 0, 255);
        g.fill(0, 0, w, h, (alpha << 24) | 0x8B0000);

        if (!calm) {
            for (int y = 0; y < h; y += 4) {
                if (r.nextInt(6) == 0) g.fill(0, y, w, y + 1 + r.nextInt(3), 0x66000000);
            }
            if (r.nextInt(22) == 0) g.fill(0, 0, w, h, 0x88FF0000);              // red strobe cut
            if (r.nextInt(30) == 0) g.fill(0, 0, w, h, 0xAA000000);              // black cut
            vignette(g, w, h, 0.35F + 0.4F * (t / (float) HELP_MS));
        }

        String msg = calm ? "Help me brother" : glitch("Help me brother", r);
        int jx = calm ? 0 : r.nextInt(9) - 4;
        int jy = calm ? 0 : r.nextInt(9) - 4;
        int tw = font.width(msg);
        float zoom = calm ? 4.0F : 4.0F + 2.5F * (t / (float) HELP_MS);         // the text creeps toward you

        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(w / 2.0F, h / 2.0F, 0.0F);
        ps.scale(zoom, zoom, 1.0F);
        int x = -tw / 2 + jx;
        int y = -4 + jy;
        if (!calm) {                                  // chromatic split
            g.drawString(font, msg, x - 2, y, 0xAA00FFFF, false);
            g.drawString(font, msg, x + 2, y, 0xAAFF0000, false);
        }
        g.drawString(font, msg, x, y, 0xFFFFFFFF, false);
        ps.popPose();
    }

    private static void renderSteve(GuiGraphics g, int w, int h) {
        long t = Util.getMillis() - startMs;
        boolean calm = calm();

        if (t < BLACKOUT_MS) {
            float a = Math.min(1.0F, t / 1500.0F);    // fade in over 1.5 s, then hold full black
            g.fill(0, 0, w, h, ((int) (a * 255) << 24));
            if (!calm) {
                for (int i = 0; i < FLASH_AT.length; i++) {   // subliminal face flashes in the dark
                    if (t >= FLASH_AT[i] && t < FLASH_AT[i] + FLASH_MS) {
                        if (!FLASH_PLAYED[i]) {
                            FLASH_PLAYED[i] = true;
                            playUi(ModSounds.STATIC_BURST.get(), 0.8F);
                            ScareFx.shake(0.9F, 300L);
                        }
                        renderDistortedFace(g, w, h, TALL_STEVE_FACE, 900L + i * 500L, FACE_MS, false);
                    }
                }
            }
            return;
        }

        long f = t - BLACKOUT_MS;
        if (f >= FACE_MS) { mode = Mode.NONE; return; }

        if (!stingPlayed) {
            stingPlayed = true;
            Heartbeat.stop();
            playUi(ModSounds.TALL_STEVE_STING.get(), 1.0F);
            playUi(ModSounds.DISTORTED.get(), 0.7F);   // layered under the scream
            ScareFx.shake(1.5F, FACE_MS);
            ScareFx.fovPunch(30.0F, 800L);
        }
        renderDistortedFace(g, w, h, TALL_STEVE_FACE, f, FACE_MS, true);
    }

    private static void renderAxl(GuiGraphics g, int w, int h) {
        long t = Util.getMillis() - startMs;
        long videoMs = ScareVideo.durationMs();

        if (t >= AXL_FACE_MS + videoMs) {
            // video is removed from the screen, then the distorted sound plays
            mode = Mode.NONE;
            ScareVideo.finish();
            CameraLock.release();
            playUi(ModSounds.DISTORTED.get(), 1.0F);
            return;
        }
        if (t < AXL_FACE_MS) {
            if (!stingPlayed) {
                stingPlayed = true;
                playUi(ModSounds.AXL_SCREAM.get(), 1.0F);
            }
            renderDistortedFace(g, w, h, AXL_FACE, t, AXL_FACE_MS, true);
        } else {
            ScareVideo.render(g, w, h, t - AXL_FACE_MS);
        }
    }

    /**
     * The "distorted" look: face drawn in 24 horizontal strips that tear sideways, a heavy
     * red/cyan colour split, static blocks, scanlines, blood running down the screen, a closing
     * vignette, strobe cuts and a fast lunge at the camera (1.0x -> 1.8x).
     */
    private static void renderDistortedFace(GuiGraphics g, int w, int h, ResourceLocation tex,
                                            long t, long total, boolean full) {
        boolean calm = calm();
        float p = Mth.clamp(t / (float) total, 0.0F, 1.0F);
        RandomSource r = RandomSource.create(Util.getMillis() / 33L);

        g.fill(0, 0, w, h, 0xFF000000);
        if (!calm && full && r.nextInt(7) == 0) return;               // strobe: a black frame now and then

        float lunge = 1.0F + 0.8F * p * p;
        int size = (int) (h * lunge);
        int x0 = (w - size) / 2 + (calm ? 0 : r.nextInt(25) - 12);
        int y0 = (h - size) / 2 + (calm ? 0 : r.nextInt(25) - 12);

        int strips = 24;
        int[] tear = new int[strips];
        for (int i = 0; i < strips; i++) {
            tear[i] = calm ? 0 : (r.nextInt(4) == 0 ? r.nextInt(161) - 80 : r.nextInt(9) - 4);
        }

        RenderSystem.enableBlend();
        int passes = calm ? 1 : 3;
        for (int pass = 0; pass < passes; pass++) {
            if (calm || pass == 2) g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
            else if (pass == 0) g.setColor(1.0F, 0.1F, 0.1F, 0.9F);
            else g.setColor(0.1F, 1.0F, 1.0F, 0.6F);
            int shift = calm ? 0 : (pass == 0 ? -16 : pass == 1 ? 16 : 0);

            for (int i = 0; i < strips; i++) {
                int sy0 = i * size / strips;
                int sy1 = (i + 1) * size / strips;
                g.blit(tex, x0 + shift + tear[i], y0 + sy0, size, sy1 - sy0,
                        0.0F, (float) (i * 512 / strips), 512, 512 / strips, 512, 512);
            }
        }
        g.setColor(1.0F, 1.0F, 1.0F, 1.0F);

        if (!calm) {
            for (int i = 0; i < 45; i++) {                             // static blocks
                int bx = r.nextInt(w);
                int by = r.nextInt(h);
                g.fill(bx, by, bx + 8 + r.nextInt(80), by + 2 + r.nextInt(8), 0x66000000 | (r.nextInt(2) == 0 ? 0xFF0000 : 0xFFFFFF));
            }
            for (int y = 0; y < h; y += 3) g.fill(0, y, w, y + 1, 0x55000000);

            if (full) {                                                // blood running down the screen
                RandomSource dr = RandomSource.create(1234L);
                for (int i = 0; i < 18; i++) {
                    int dx = dr.nextInt(Math.max(1, w));
                    int dw = 2 + dr.nextInt(5);
                    float speed = 0.35F + dr.nextFloat() * 0.65F;
                    int len = (int) (h * Mth.clamp(p * 1.5F * speed + 0.04F, 0.0F, 1.0F));
                    g.fill(dx, 0, dx + dw, len, 0xCC9A0A0A);
                    g.fill(dx - 1, len, dx + dw + 1, len + 5, 0xCC9A0A0A);
                }
                vignette(g, w, h, 0.4F + 0.6F * p);
            }
            if (r.nextInt(6) == 0) g.fill(0, 0, w, h, 0x55FFFFFF);       // white flash
            else if ((t / 55) % 2 == 0) g.fill(0, 0, w, h, 0x33FF0000);
        }
        RenderSystem.disableBlend();
    }

    /** Dark frame closing in from the edges; strength 0..1. */
    private static void vignette(GuiGraphics g, int w, int h, float strength) {
        int steps = 8;
        for (int i = 0; i < steps; i++) {
            int inset = (int) (Math.min(w, h) * 0.07F * i * strength);
            int a = (int) (60 * strength * (steps - i) / steps);
            if (a <= 0) continue;
            int c = a << 24;
            g.fill(0, 0, w, inset + 4, c);
            g.fill(0, h - inset - 4, w, h, c);
            g.fill(0, 0, inset + 4, h, c);
            g.fill(w - inset - 4, 0, w, h, c);
        }
    }

    private static void renderFloatingTexts(GuiGraphics g, int w, int h) {
        if (FLOATING.isEmpty()) return;
        long now = Util.getMillis();
        boolean calm = calm();
        Font font = Minecraft.getInstance().font;

        FLOATING.removeIf(f -> now - f.startMs() > f.durationMs());
        for (FloatingText f : FLOATING) {
            long t = now - f.startMs();
            if (!calm && (t / 70) % 4 == 0) continue;               // flicker off-frames

            float fade = Math.min(1.0F, (f.durationMs() - t) / 200.0F);
            int alpha = (int) (255 * Mth.clamp(fade, 0.0F, 1.0F));
            if (alpha < 8) continue;                                // font treats tiny alpha as opaque

            RandomSource r = RandomSource.create(f.startMs() + t / 60);
            float jx = calm ? 0 : (r.nextFloat() - 0.5F) * 6.0F;
            float jy = calm ? 0 : (r.nextFloat() - 0.5F) * 6.0F;
            float x = Math.min(w * f.fx(), w - font.width(f.text()) * f.scale() - 4.0F);

            PoseStack ps = g.pose();
            ps.pushPose();
            ps.translate(Math.max(4.0F, x) + jx, h * f.fy() + jy, 0.0F);
            ps.scale(f.scale(), f.scale(), 1.0F);
            g.drawString(font, f.text(), 0, 0, (alpha << 24) | 0xCC0000, false);
            ps.popPose();
        }
    }

    private static String glitch(String s, RandomSource r) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c != ' ' && r.nextInt(14) == 0) sb.append(GLITCH_CHARS.charAt(r.nextInt(GLITCH_CHARS.length())));
            else sb.append(c);
        }
        return sb.toString();
    }
}
