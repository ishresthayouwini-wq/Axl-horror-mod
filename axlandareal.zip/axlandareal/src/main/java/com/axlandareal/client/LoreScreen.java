package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.glfw.GLFW;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Reader for the "Lore of Axl" item. The story lives in assets/axlandareal/lore/lore_of_axl.txt:
 *   "# text"  -> big red heading (starts a new page)
 *   "> text"  -> chat-log line
 *   blank     -> small gap
 *   anything else -> body text
 * Pages are built to fit the current window; < > buttons, arrow keys and the mouse wheel turn them.
 */
@OnlyIn(Dist.CLIENT)
public class LoreScreen extends Screen {
    private static final ResourceLocation TEXT = new ResourceLocation(AxlAndAReal.MODID, "lore/lore_of_axl.txt");
    private static final float HEAD_SCALE = 1.8F;
    private static final int PAD = 10;

    private enum Kind { HEADING, BODY, CHAT, SPACER }
    private record Line(Kind kind, FormattedCharSequence text, int height) {}

    private final List<List<Line>> pages = new ArrayList<>();
    private int page;
    private int panelX, panelY, panelW, panelH;
    private Button prev, next;

    private LoreScreen() {
        super(Component.literal("Lore of Axl"));
    }

    public static void open() {
        Minecraft.getInstance().setScreen(new LoreScreen());
    }

    @Override
    protected void init() {
        panelW = Math.min(width - 16, 340);
        panelH = height - 24;
        panelX = (width - panelW) / 2;
        panelY = 12;
        layoutPages();
        page = Mth.clamp(page, 0, pages.size() - 1);

        int by = panelY + panelH - 24;
        prev = addRenderableWidget(Button.builder(Component.literal("<"), b -> turn(-1))
                .bounds(panelX + PAD, by, 40, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(width / 2 - 30, by, 60, 20).build());
        next = addRenderableWidget(Button.builder(Component.literal(">"), b -> turn(1))
                .bounds(panelX + panelW - PAD - 40, by, 40, 20).build());
        updateButtons();
    }

    private void layoutPages() {
        pages.clear();
        int contentW = panelW - PAD * 2;
        int contentH = panelH - PAD * 2 - 44;
        List<Line> current = new ArrayList<>();
        int y = 0;

        for (String raw : readLines()) {
            String line = raw.strip();
            boolean heading = line.startsWith("# ");
            List<Line> built = new ArrayList<>();

            if (line.isEmpty()) {
                built.add(new Line(Kind.SPACER, null, 5));
            } else if (heading) {
                Component c = Component.literal(line.substring(2)).withStyle(Style.EMPTY.withColor(0xDD1111).withBold(true));
                for (FormattedCharSequence s : font.split(c, (int) (contentW / HEAD_SCALE))) {
                    built.add(new Line(Kind.HEADING, s, (int) (9 * HEAD_SCALE) + 3));
                }
            } else if (line.startsWith("> ")) {
                for (FormattedCharSequence s : font.split(chat(line.substring(2)), contentW - 8)) {
                    built.add(new Line(Kind.CHAT, s, 10));
                }
            } else {
                Component c = Component.literal(line).withStyle(Style.EMPTY.withColor(0xD8D8D8));
                for (FormattedCharSequence s : font.split(c, contentW)) {
                    built.add(new Line(Kind.BODY, s, 11));
                }
            }

            if (heading && !current.isEmpty()) {          // every section starts on a fresh page
                pages.add(current);
                current = new ArrayList<>();
                y = 0;
            }
            for (Line l : built) {
                if (y + l.height() > contentH && !current.isEmpty()) {
                    pages.add(current);
                    current = new ArrayList<>();
                    y = 0;
                    if (l.kind() == Kind.SPACER) continue;
                }
                current.add(l);
                y += l.height();
            }
        }
        if (!current.isEmpty() || pages.isEmpty()) pages.add(current);
    }

    private static MutableComponent chat(String s) {
        int end = s.indexOf('>');
        if (s.startsWith("<") && end > 0) {
            String name = s.substring(0, end + 1);
            int color = name.startsWith("<Axl") ? 0x55E5FF : 0xFFE055;
            return Component.literal(name).withStyle(Style.EMPTY.withColor(color))
                    .append(Component.literal(s.substring(end + 1)).withStyle(Style.EMPTY.withColor(0xFFFFFF)));
        }
        return Component.literal(s).withStyle(Style.EMPTY.withColor(0xBBBBBB));
    }

    private static List<String> readLines() {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                Minecraft.getInstance().getResourceManager().open(TEXT), StandardCharsets.UTF_8))) {
            return r.lines().toList();
        } catch (IOException e) {
            return List.of("# The pages are blank");
        }
    }

    private void turn(int delta) {
        page = Mth.clamp(page + delta, 0, pages.size() - 1);
        updateButtons();
    }

    private void updateButtons() {
        if (prev != null) prev.active = page > 0;
        if (next != null) next.active = page < pages.size() - 1;
    }

    @Override
    public boolean keyPressed(int key, int scancode, int modifiers) {
        if (key == GLFW.GLFW_KEY_RIGHT) { turn(1); return true; }
        if (key == GLFW.GLFW_KEY_LEFT) { turn(-1); return true; }
        return super.keyPressed(key, scancode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        turn(delta < 0 ? 1 : -1);
        return true;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.fill(panelX - 2, panelY - 2, panelX + panelW + 2, panelY + panelH + 2, 0xFF7A0000);
        g.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xFF0B0505);

        int x = panelX + PAD;
        int y = panelY + PAD;
        for (Line l : pages.get(page)) {
            if (l.text() != null) {
                switch (l.kind()) {
                    case HEADING -> {
                        PoseStack ps = g.pose();
                        ps.pushPose();
                        ps.translate(x, y, 0);
                        ps.scale(HEAD_SCALE, HEAD_SCALE, 1.0F);
                        g.drawString(font, l.text(), 0, 0, 0xFFFFFFFF, false);
                        ps.popPose();
                    }
                    case CHAT -> {
                        g.fill(x, y - 1, x + 2, y + l.height() - 1, 0xFF550000);   // red bar beside chat lines
                        g.drawString(font, l.text(), x + 6, y, 0xFFFFFFFF, false);
                    }
                    default -> g.drawString(font, l.text(), x, y, 0xFFFFFFFF, false);
                }
            }
            y += l.height();
        }
        g.drawCenteredString(font, "Page " + (page + 1) + " / " + pages.size(), width / 2, panelY + panelH - 38, 0xFF888888);
        super.render(g, mouseX, mouseY, partialTick);   // buttons
    }
}
