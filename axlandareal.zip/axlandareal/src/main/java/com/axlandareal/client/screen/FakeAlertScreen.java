package com.axlandareal.client.screen;

import com.axlandareal.registry.ModSounds;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * Meta-horror screens. EVERYTHING here is drawn inside the Minecraft window and
 * does nothing real: no webcam access, no files, no process exit. ESC always closes.
 * isPauseScreen() is false so singleplayer worlds keep ticking underneath.
 */
@OnlyIn(Dist.CLIENT)
public class FakeAlertScreen extends Screen {

    public enum Kind { WEBCAM, MALWARE, TAUNT, CRASH }

    private static final int CRASH_TICKS = 140;   // 7 s, then returns to the game
    private static final int ALERT_TICKS = 600;   // auto-dismiss after 30 s

    private final Kind kind;
    private final String playerName;
    private int age;

    public FakeAlertScreen(Kind kind, String playerName) {
        super(Component.literal(titleFor(kind)));
        this.kind = kind;
        this.playerName = playerName;
    }

    private static String titleFor(Kind k) {
        return switch (k) {
            case WEBCAM -> "Permission Request";
            case MALWARE -> "Security Alert";
            case TAUNT -> "Axl";
            case CRASH -> "Minecraft";
        };
    }

    private String body() {
        return switch (kind) {
            case WEBCAM -> "The mod is trying to get access to your webcam";
            case MALWARE -> "A file named AXL.EXE is trying to hack your Computer/mobile";
            case TAUNT -> "Why are you scared " + playerName;
            case CRASH -> "";
        };
    }

    @Override
    protected void init() {
        if (minecraft != null) {
            minecraft.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.STATIC_BURST.get(), 1.0F, 0.6F));
        }
        int cx = width / 2;
        int y = height / 2 + 15;
        switch (kind) {
            case WEBCAM -> {
                addButton("Allow", cx - 105, y, 100, b -> next());
                addButton("Deny", cx + 5, y, 100, b -> next());
            }
            case MALWARE -> {
                addButton("Block", cx - 105, y, 100, b -> next());
                addButton("Allow", cx + 5, y, 100, b -> next());
            }
            case TAUNT -> addButton("...", cx - 50, y, 100, b -> onClose());
            case CRASH -> { }
        }
    }

    private void addButton(String label, int x, int y, int w, Button.OnPress action) {
        addRenderableWidget(Button.builder(Component.literal(label), action).bounds(x, y, w, 20).build());
    }

    /** Whatever you press, it answers the same way. */
    private void next() {
        if (minecraft != null) minecraft.setScreen(new FakeAlertScreen(Kind.TAUNT, playerName));
    }

    @Override
    public void tick() {
        age++;
        if (age > (kind == Kind.CRASH ? CRASH_TICKS : ALERT_TICKS)) onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        if (kind == Kind.CRASH) {
            renderCrash(g);
            return;
        }
        renderBackground(g);

        int pw = 260, ph = 110;
        int x = (width - pw) / 2;
        int y = height / 2 - 65;
        g.fill(x - 2, y - 2, x + pw + 2, y + ph + 2, 0xFFAA0000);   // red border
        g.fill(x, y, x + pw, y + ph, 0xFF101010);                   // panel
        g.drawCenteredString(font, title, width / 2, y + 8, 0xFFFF5555);

        int ly = y + 30;
        for (FormattedCharSequence line : font.split(Component.literal(body()), pw - 20)) {
            g.drawCenteredString(font, line, width / 2, ly, 0xFFFFFFFF);
            ly += 12;
        }
        super.render(g, mouseX, mouseY, partialTick);               // buttons
    }

    private void renderCrash(GuiGraphics g) {
        String[] lines = {
                "---- Minecraft Crash Report ----",
                "// You shouldn't have looked away.",
                "",
                "Description: Ticking entity",
                "",
                "java.lang.IllegalStateException: Axl is already in the room",
                "\tat com.axlandareal.entity.AxlEntity.tick(AxlEntity.java:666)",
                "\tat net.minecraft.world.level.Level.guardEntityTick(Level.java:466)",
                "",
                "-- Affected player --",
                "Details:",
                "\tName: " + playerName,
                "\tStatus: still watching",
        };
        g.fill(0, 0, width, height, 0xFF000000);
        int visible = Math.min(lines.length, age / 6);
        for (int i = 0; i < visible; i++) {
            g.drawString(font, lines[i], 10, 10 + i * 10, i == 1 ? 0xFFFF5555 : 0xFFAAAAAA, false);
        }
    }
}
