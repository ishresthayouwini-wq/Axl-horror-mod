package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.entity.AbstractHauntEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/**
 * One renderer for all four entities: the vanilla player model with a custom
 * 64x64 skin (textures/entity/<name>.png) and an optional width/height stretch.
 */
public class HauntRenderer<T extends AbstractHauntEntity> extends HumanoidMobRenderer<T, HumanoidModel<T>> {
    private final ResourceLocation texture;
    private final float widthScale, heightScale;

    public HauntRenderer(EntityRendererProvider.Context ctx, String name, float widthScale, float heightScale) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5F);
        this.texture = new ResourceLocation(AxlAndAReal.MODID, "textures/entity/" + name + ".png");
        this.widthScale = widthScale;
        this.heightScale = heightScale;
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }

    @Override
    protected void scale(T entity, PoseStack poseStack, float partialTick) {
        // the player model is 1.8 tall (vanilla players use 0.9375); both scales are absolute
        poseStack.scale(widthScale, heightScale, widthScale);
    }
}
