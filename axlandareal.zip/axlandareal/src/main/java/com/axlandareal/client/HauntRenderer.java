package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.entity.AbstractHauntEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

/**
 * One renderer for all haunt entities: the vanilla player model with a custom
 * 64x64 skin (textures/entity/<name>.png) and an optional width/height stretch.
 * Entities flagged isTPose() hold their arms straight out to the sides.
 */
public class HauntRenderer<T extends AbstractHauntEntity> extends HumanoidMobRenderer<T, HumanoidModel<T>> {
    private final ResourceLocation texture;
    private final float widthScale, heightScale;

    public HauntRenderer(EntityRendererProvider.Context ctx, String name, float widthScale, float heightScale) {
        this(ctx, name, widthScale, heightScale, false);
    }

    /** glowingEyes = true adds the fullbright layer from textures/entity/<name>_eyes.png */
    public HauntRenderer(EntityRendererProvider.Context ctx, String name, float widthScale, float heightScale,
                         boolean glowingEyes) {
        super(ctx, tPoseCapable(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5F);
        this.texture = new ResourceLocation(AxlAndAReal.MODID, "textures/entity/" + name + ".png");
        this.widthScale = widthScale;
        this.heightScale = heightScale;
        if (glowingEyes) {
            ResourceLocation eyes = new ResourceLocation(AxlAndAReal.MODID, "textures/entity/" + name + "_eyes.png");
            this.addLayer(new EyesLayer<T, HumanoidModel<T>>(this) {
                @Override
                public RenderType renderType() {
                    return RenderType.eyes(eyes);
                }
            });
        }
    }

    private static <T extends AbstractHauntEntity> HumanoidModel<T> tPoseCapable(ModelPart root) {
        return new HumanoidModel<T>(root) {
            @Override
            public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch) {
                super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
                if (entity.isTPose()) {
                    // if the arms ever point into the body, flip the two signs
                    this.rightArm.xRot = 0.0F;
                    this.rightArm.yRot = 0.0F;
                    this.rightArm.zRot = (float) (Math.PI / 2.0D);
                    this.leftArm.xRot = 0.0F;
                    this.leftArm.yRot = 0.0F;
                    this.leftArm.zRot = (float) (-Math.PI / 2.0D);
                    this.rightLeg.xRot = 0.0F;
                    this.leftLeg.xRot = 0.0F;
                }
            }
        };
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }

    @Override
    protected void scale(T entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(widthScale, heightScale, widthScale);
    }
}
