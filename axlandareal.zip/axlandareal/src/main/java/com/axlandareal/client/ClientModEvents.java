package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.entity.PlayerCloneEntity;
import com.axlandareal.registry.ModEntities;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.AXL.get(), c -> new HauntRenderer<>(c, "axl", 0.9375F, 1.0F));
        // the clone wears the skin, model and armor of the player it copies
        e.registerEntityRenderer(ModEntities.PLAYER_CLONE.get(), PlayerCloneRenderer::new);
        e.registerEntityRenderer(ModEntities.AXL_AMBUSH.get(), c -> new HauntRenderer<>(c, "axl", 0.9375F, 1.0F));
        e.registerEntityRenderer(ModEntities.BLACK_FIGURE.get(), c -> new HauntRenderer<>(c, "black_figure", 0.9375F, 1.0F));
        e.registerEntityRenderer(ModEntities.WHITE_FIGURE.get(), c -> new HauntRenderer<>(c, "white_figure", 0.9375F, 1.0F));
        // Tall Steve: thinner and ~2.1x taller than a normal player model, with glowing red eyes
        e.registerEntityRenderer(ModEntities.TALL_STEVE.get(), c -> new HauntRenderer<>(c, "tall_steve", 0.8F, 2.1F, true));
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("haunt", HauntOverlay::render);
    }
}
