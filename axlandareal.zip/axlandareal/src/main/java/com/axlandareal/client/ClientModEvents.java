package com.axlandareal.client;

import com.axlandareal.AxlAndAReal;
import com.axlandareal.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AxlAndAReal.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.AXL.get(), c -> new HauntRenderer<>(c, "axl", 0.9375F, 1.0F));
        e.registerEntityRenderer(ModEntities.BLACK_FIGURE.get(), c -> new HauntRenderer<>(c, "black_figure", 0.9375F, 1.0F));
        e.registerEntityRenderer(ModEntities.WHITE_FIGURE.get(), c -> new HauntRenderer<>(c, "white_figure", 0.9375F, 1.0F));
        // Tall Steve: thinner and ~1.9x taller than a normal player model
        e.registerEntityRenderer(ModEntities.TALL_STEVE.get(), c -> new HauntRenderer<>(c, "tall_steve", 0.85F, 1.9F));
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("haunt", HauntOverlay::render);
    }
}
