package com.axlandareal.client;

import com.axlandareal.entity.PlayerCloneEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * Draws the clone exactly like the player it copies: that player's skin, the right arm width (wide or slim,
 * so no glitchy arms), the skin's second layer (jacket, sleeves, pants) and the armor.
 */
@OnlyIn(Dist.CLIENT)
public class PlayerCloneRenderer extends HauntRenderer<PlayerCloneEntity> {
    private final PlayerModel<PlayerCloneEntity> wide;
    private final PlayerModel<PlayerCloneEntity> slim;

    public PlayerCloneRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, "axl", 0.9375F, 1.0F);
        this.wide = new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false);
        this.slim = new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER_SLIM), true);
        this.model = this.wide;
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                ctx.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(PlayerCloneEntity entity) {
        return CloneSkins.skinOf(entity);
    }

    @Override
    public void render(PlayerCloneEntity entity, float entityYaw, float partialTicks, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        this.model = CloneSkins.isSlim(entity) ? this.slim : this.wide;   // layers read this.model live
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }
}
