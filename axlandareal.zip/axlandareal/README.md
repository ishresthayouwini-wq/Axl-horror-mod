# Axl and Abreal 0.1.1 — Forge 1.20.1 (47.x), Mojang mappings
Builds `Axl and Abreal-0.1.1.jar` (if a launcher dislikes spaces, set `archivesName` in build.gradle to `Axl-and-Abreal`). Mod id stays `axlandareal` (the zip you upload to GitHub must stay named `axlandareal.zip`).

## New in 0.1.1
- **Axl ambush** (mining): arm -> mine 3 blocks underground -> Axl appears. Once you have SEEN him, moving / placing a block / looking away springs it: camera locks, T-pose, flies up, dives, face + scream, video, distorted sound.
- **Symptoms:** fast block-breaking sounds (4 s), retro graphics (6 s), running footsteps, red water (20 s), red cross, floating grass/flowers (40 s), one-time sky room (7x7, 7 s, nausea 8 s).
- **Hallucinations (only the target player sees them):** T-pose rush + red screen, red eyes (11 s), animals/villagers stare (22 s).
- **Improvements:** sound on "Help me brother", more distorted Tall Steve jumpscare + kick ("The mod is trying to hack your Internet"), stalkers far more frequent, White Figure day only, Black Figure night only.
- **Messages:** "You are not safe even though you build a house" removed. New one-time whispers: in a friend's/villager's house, and while building.
- **Heavy fog** (client-side graphics change): ALWAYS on, everywhere, even with nothing nearby: you can see about 36 blocks (`fogDistance`, 12-96). A 90 s fog bank event (`/axl fire heavy_fog`) closes it to 14. `permanentFog=false` or `visualEffects=false` in the client config turns it off.
- **Scarier jumpscares:** camera shake and FOV punch, rising heartbeat build-up, subliminal face flashes during the Tall Steve blackout, bleeding/tearing/strobing faces that lunge at you, closing vignette. `reduceFlashing` removes all of it.
- Black and White Figures no longer give Blindness / Weakness.
- **Two server-wide environment changes** (every player gets them at the same moment, one at a time; client switch `visualEffects`):
  - **Black and white** (`/axl fire environment_change`): RARE (weight 1, like diamonds), lasts 76 s = 1.27 minutes (`environmentSeconds`). The picture goes black and white (own shader; grey-overlay fallback), every normal game sound drops to half speed with a reversed, slowed ambience underneath, and every animal and villager stares at you.
  - **Retro** (`/axl fire retro_change`): common (weight 8), lasts 32 s (`retroEnvironmentSeconds`). The picture becomes an old low-resolution screen (about 240 lines, limited colours, scanlines) and the retro game settings are held on (fast graphics, flat light, short view distance).
  - BOTH happen only ONE time per world (remembered in the save). `/axl fire ...` always works for testing and does not use the one time up; `/axl reset_once` re-enables them.
  - **Retro symptoms:** every mob, animal and villager near a player freezes (AI off) and stares at you; blood everywhere (red splatters on the ground, red water, blood running down the screen, red-tinted retro picture); a retro chiptune soundtrack (`retro_music.ogg`, an original loop, replace it with your own if you like).
  - **During either environment change NOTHING else happens:** the director pauses, stalkers/clones/ambush are removed or disarmed, whispers and the permanent fog are paused. Only that change's own symptoms show.
  - The older per-player 6 s retro event (`/axl fire retro`) is unchanged.
- **Clone (multiplayer only):** when two players are at least 64 blocks apart (`cloneMinDistance`), Axl clones one of them and sends the clone toward a DIFFERENT player, never to the player it copies. The clone copies that player's skin (wide or slim arms), name tag, armor, held items, pace (it stops when the original stops), sneaking, sprinting and arm swings. Whatever the original says in chat is repeated to the victim as a whisper from the clone, and if the victim asks why it is whispering (any wording with why/what/how come + whisper) it whispers back "Because Axl can hear it". It only moves while you are not looking, vanishes when stared at or reached (with the "Your friend <name> is going to betray you" whisper) and disappears if the two players get close. Never happens in single player. `/axl fire player_clone`.
- **Gift chest** (`/axl fire gift_chest`): a chest appears near a random player with a sign "Gift for you". Inside: a bottle of blood (new item) and the head of a random player on the server (in single player: your own). Disappears after 5 minutes if the blood is not taken.
- **Controlled** (`/axl fire controlled`, rare): for 50 s (`controlledSeconds`) one player cannot steer; their character walks by itself and attacks every living thing near it (mobs, animals, villagers, other players). Creepy music plays (`control_music.ogg` is your music, 50.8 s), the player is immortal until it ends, then mortal again (with 5 s of hidden damage resistance). `controlledHurtsPlayers=false` spares other players.
- **Main menu (scary, switch `scaryMenu`; red buttons: `redMenu`):** the panorama is a night forest of bloody trees in heavy fog with a blood moon, bloody Steve heads, glowing eyes in the trees and two tall figures with red eyes in the fog (files `assets/minecraft/textures/gui/title/background/panorama_0-5.png`; delete them for the normal panorama). On the title screen: fog drifting in two layers, red eyes that open in the dark and follow the pointer, blood creeping down from the top, a breathing vignette, power flickers, whispered words, a slow fade up from black, and about 4 visits in 10 a split-second face flash with a static burst. The cheerful menu music is replaced by creepy ambience (drone + heartbeat), and the yellow splash texts are creepy lines (`assets/minecraft/texts/splashes.txt`). `reduceFlashing` removes flicker, blinking and the flash.
- New icon + description.
- **Lore of Axl** (item): given automatically the first time a player joins (and again after dying without it). Right-click to read the story in a book screen with big red headings. `/axl lore` gives another copy; it is also in the Tools & Utilities creative tab. The story is a plain text file you can edit: `assets/axlandareal/lore/lore_of_axl.txt` (`# ` = big red heading, `> ` = chat line).

## Testing
`/axl fire <event>` (tab-complete): `jumpscare_help`, `jumpscare_steve`, `retro`, `red_water`, `hallucination_rush`, `hallucination_eyes`, `hallucination_stare`, `nightmare_room`, `floating_plants`, `footsteps`, `break_sounds`, `red_cross`, `axl_ambush` (arms it, then mine 3 blocks underground).
Instant ambush: `/summon axlandareal:axl_ambush ~ ~ ~6`, then look at him and take a step.
Black Figure only lives at night and White Figure only by day (`/time set night`).
Config files are new: `axlandareal-0.1.1-common.toml` / `-client.toml` (events every 45-150 s by default).

## Assets
- Skins: Black Figure, White Figure and Axl are the ones you supplied (check their creators allow reuse before publishing; credit them). Tall Steve is an original drawing: bloody, with glowing red eyes (`tall_steve_eyes.png`) and a taller body. My blue-hoodie Axl is kept in `extras/axl_hoodie_alternative.png` (copy it over `textures/entity/axl.png` to use it).
- Included: Tall Steve face and Axl face (cropped from their new skins), the Tall Steve scream (`tall_steve_sting.ogg`), the room ambience (`nightmare_ambience.ogg`, your breathing recording), Axl scream (`axl_scream.ogg`) and the meat grinder video (41 frames in `textures/gui/video/`, silent).
- PLACEHOLDERS to replace with your own .ogg (same names, mono): `distorted`, `help_sting`, `axl_whisper`, `static_burst`, `scare_video_audio`.
- To swap the video: frames `textures/gui/video/f_0001.png ...` (264x320, 12 fps) + `sounds/scare_video_audio.ogg`. No frames = the video step is skipped.

## Comfort settings (client config)
`jumpscares`, `fakeAlerts`, `floatingText`, `visualEffects`, `scareVideo`, `reduceFlashing`. Server config: `kickAfterTallSteve` and per-symptom toggles.
