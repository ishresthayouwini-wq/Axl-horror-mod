# Axl and A real — Forge 1.20.1 (47.x), Mojang mappings

Drop `src/` into a fresh Forge 1.20.1 MDK (set `mod_id=axlandareal`).

## Assets (included)
- `textures/entity/{axl,black_figure,white_figure,tall_steve}.png` — your 64x64 skins
- `textures/gui/tall_steve_face.png` — head + hat layer of the Tall Steve skin, 512x512 (swap in any square image)
- `sounds/tall_steve_sting.ogg` — your scream, trimmed to 3.85s, +8 dB, mono
- `sounds/static_burst.ogg`, `sounds/axl_whisper.ogg` — generated PLACEHOLDERS, replace with your own

## Structure
- `AxlAndAReal` — entry point, registers everything
- `registry/` — entities, items (spawn eggs), blocks, sounds, attributes
- `entity/` — `AbstractHauntEntity` + Axl, Black/White Figure, Tall Steve; `entity/goal/` — freeze-when-watched, stalk, mirror
- `world/` — `HauntDirector` (scheduler), `Symptoms` (signs, whispers, brick wall, anomalies), `HauntSpawner`, `/axl fire <event>`
- `network/` — one S2C packet that tells the client which scare to show
- `client/` — `HauntOverlay` (6s red, 7s blackout + face, floating text), `FakeAlertScreen` (webcam / AXL.EXE / taunt / crash)

## Testing
`/axl fire jumpscare_help`, `/axl fire jumpscare_steve`, `/axl fire fake_alert`, `/axl fire black_figure` ...
or use the spawn eggs. Set `minEventSeconds` low in the common config to see the director work.

## Fabric
Same architecture. Swap DeferredRegister -> Registry.register, Forge events -> Fabric API callbacks,
SimpleChannel -> ServerPlayNetworking/ClientPlayNetworking, GUI overlay -> HudRenderCallback.
